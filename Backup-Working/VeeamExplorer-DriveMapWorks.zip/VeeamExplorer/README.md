# Veeam Backup Explorer

A PowerShell WPF application for exploring and mapping Veeam backup repositories and network drives with credential management.

## Features

- **Modern WPF GUI**: Clean, responsive interface with gradient backgrounds and Veeam branding
- **Veeam Repository Access**: Specifically designed for accessing Veeam backup repositories
- **Secure Credential Storage**: Encrypted password storage in Windows registry
- **Drive Letter Management**: Automatic detection of available drive letters with V: preference
- **Real-time Validation**: UNC path and connectivity testing with fast 5-second timeouts
- **Explorer Integration**: Automatically opens mapped drives in Windows Explorer
- **Sound Feedback**: Audio notifications for success/failure operations
- **Comprehensive Logging**: Detailed activity logging with timestamps and emoji indicators
- **Backup Repository Focus**: Optimized for Veeam backup file exploration and recovery
- **Smart Error Handling**: Graceful handling of network timeouts and connection issues

## Requirements

- Windows 10/11
- PowerShell 5.1 or later
- .NET Framework 4.7.2 or later

## Project Structure

```
├── src/
│   ├── MainWindow.xaml          # Main WPF window XAML
│   ├── VeeamBackupExplorer.ps1  # Main application script
│   ├── Modules/
│   │   ├── RegistryManager.psm1 # Registry operations module
│   │   ├── DriveUtils.psm1      # Drive management utilities
│   │   └── Crypto.psm1          # Encryption/decryption utilities
│   └── Assets/
│       ├── success.wav          # Success sound effect
│       └── error.wav            # Error sound effect
```

## Usage

### General Network Drive Mapping
1. Run the `VeeamBackupExplorer.ps1` script
2. Enter UNC path (e.g., `\\server\share` or `\\192.168.1.100\VeeamBackup`)
3. Enter network credentials (username and password)
4. Select desired drive letter (V: is pre-selected for Veeam repositories)
5. Click Connect to map the drive

### Veeam Backup Repository Access
- **Typical Veeam repository paths**: `\\backup-server\VeeamBackup$` or `\\192.168.1.100\d$`
- **Common credentials**: Domain admin or backup service account credentials
- **Recommended drive**: V: drive (automatically selected when available)
- **Post-connection**: Explorer opens automatically to browse backup files

## Security

- Credentials are stored encrypted in the registry
- Password is never stored in plain text
- All sensitive operations are logged 