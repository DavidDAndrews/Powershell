#Requires -Version 5.1

Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# Import required modules
$ScriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path
Import-Module "$ScriptPath\Modules\RegistryManager.psm1" -Force
Import-Module "$ScriptPath\Modules\DriveUtils.psm1" -Force
Import-Module "$ScriptPath\Modules\Crypto.psm1" -Force

# Registry keys
$script:RegPath = "HKCU:\Software\VeeamBackupExplorer"
$script:RegKeyCredentials = "Credentials"
$script:RegKeySettings = "Settings"

# Track mapped drive for cleanup on exit
$script:MappedDrive = $null

# XAML for the main window
[xml]$xaml = @"
<Window
    xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
    xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
    Title="Veeam Backup Explorer" Height="1080" Width="1080" MinHeight="1080" MinWidth="1080"
    WindowStartupLocation="CenterScreen" 
    FontFamily="Segoe UI">
    
    <Window.Background>
        <LinearGradientBrush StartPoint="0,0" EndPoint="1,1">
            <GradientStop Color="#FF1E3A8A" Offset="0"/>
            <GradientStop Color="#FF3B82F6" Offset="0.5"/>
            <GradientStop Color="#FF6366F1" Offset="1"/>
        </LinearGradientBrush>
    </Window.Background>
    
    <Grid Margin="25">
        <Grid.RowDefinitions>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="2*"/>
            <RowDefinition Height="Auto"/>
        </Grid.RowDefinitions>

        <!-- Header Section -->
        <Border Grid.Row="0" Background="White" CornerRadius="15" Margin="0,0,0,20" Padding="25">
            <Border.Effect>
                <DropShadowEffect Color="Black" Opacity="0.2" ShadowDepth="5" BlurRadius="15"/>
            </Border.Effect>
            
            <StackPanel>
                <!-- Title with modern styling -->
                                    <TextBlock Text="🔍 Veeam Backup Explorer" FontSize="28" FontWeight="Bold" 
                          Foreground="#1E40AF" HorizontalAlignment="Center" Margin="0,0,0,25"/>
                
                <!-- UNC Path Section -->
                <Grid Margin="0,0,0,15">
                    <Grid.ColumnDefinitions>
                        <ColumnDefinition Width="150"/>
                        <ColumnDefinition Width="*"/>
                    </Grid.ColumnDefinitions>
                    <Label Content="📁 UNC Path:" VerticalAlignment="Center" FontWeight="SemiBold" 
                           Foreground="#374151" FontSize="14"/>
                    <Border Grid.Column="1" BorderThickness="2" BorderBrush="#E5E7EB" CornerRadius="8" Background="#F9FAFB">
                        <TextBox x:Name="txtUNCPath" Height="35" BorderThickness="0" 
                                 Padding="10" FontSize="13" Background="Transparent"/>
                    </Border>
                </Grid>
                
                <!-- Username Section -->
                <Grid Margin="0,0,0,15">
                    <Grid.ColumnDefinitions>
                        <ColumnDefinition Width="150"/>
                        <ColumnDefinition Width="*"/>
                    </Grid.ColumnDefinitions>
                    <Label Content="👤 Username:" VerticalAlignment="Center" FontWeight="SemiBold" 
                           Foreground="#374151" FontSize="14"/>
                    <Border Grid.Column="1" BorderThickness="2" BorderBrush="#E5E7EB" CornerRadius="8" Background="#F9FAFB">
                        <TextBox x:Name="txtUsername" Height="35" BorderThickness="0" 
                                 Padding="10" FontSize="13" Background="Transparent"/>
                    </Border>
                </Grid>
                
                <!-- Password Section -->
                <Grid Margin="0,0,0,15">
                    <Grid.ColumnDefinitions>
                        <ColumnDefinition Width="150"/>
                        <ColumnDefinition Width="*"/>
                    </Grid.ColumnDefinitions>
                    <Label Content="🔒 Password:" VerticalAlignment="Center" FontWeight="SemiBold" 
                           Foreground="#374151" FontSize="14"/>
                    <Border Grid.Column="1" BorderThickness="2" BorderBrush="#E5E7EB" CornerRadius="8" Background="#F9FAFB">
                        <PasswordBox x:Name="txtPassword" Height="35" BorderThickness="0" 
                                     Padding="10" FontSize="13" Background="Transparent" PasswordChar="●"/>
                    </Border>
                </Grid>
                
                <!-- Drive Letter Section -->
                <Grid Margin="0,0,0,15">
                    <Grid.ColumnDefinitions>
                        <ColumnDefinition Width="150"/>
                        <ColumnDefinition Width="*"/>
                    </Grid.ColumnDefinitions>
                    <Label Content="💾 Drive Letter:" VerticalAlignment="Center" FontWeight="SemiBold" 
                           Foreground="#374151" FontSize="14"/>
                    <Border Grid.Column="1" BorderThickness="2" BorderBrush="#E5E7EB" CornerRadius="8" Background="#F9FAFB">
                        <ComboBox x:Name="cmbDriveLetter" Height="35" BorderThickness="0" 
                                  Padding="8" FontSize="13" Background="Transparent"/>
                    </Border>
                </Grid>
                
                <!-- Remember Checkbox -->
                <CheckBox x:Name="chkRemember" Content="💾 Remember these settings" 
                          FontWeight="SemiBold" Foreground="#6366F1" FontSize="14" Margin="150,10,0,0"/>
            </StackPanel>
        </Border>

        <!-- Log Section -->
        <Border Grid.Row="1" Background="White" CornerRadius="15" Margin="0,0,0,20" MinHeight="300">
            <Border.Effect>
                <DropShadowEffect Color="Black" Opacity="0.2" ShadowDepth="5" BlurRadius="15"/>
            </Border.Effect>
            
            <Grid>
                <Grid.RowDefinitions>
                    <RowDefinition Height="Auto"/>
                    <RowDefinition Height="*"/>
                </Grid.RowDefinitions>
                
                <!-- Log Header -->
                <Border Grid.Row="0" Background="#F3F4F6" CornerRadius="15,15,0,0" Padding="15,10">
                    <TextBlock Text="📋 Activity Log" FontWeight="Bold" FontSize="16" 
                               Foreground="#374151"/>
                </Border>
                
                <!-- Log Content -->
                <ScrollViewer Grid.Row="1" Margin="15">
                    <TextBox x:Name="txtLog" IsReadOnly="True" TextWrapping="Wrap" 
                             Background="Transparent" BorderThickness="0" Padding="5" 
                             MinHeight="250" FontFamily="Consolas" FontSize="12"
                             Foreground="#1F2937"/>
                </ScrollViewer>
            </Grid>
        </Border>

        <!-- Bottom Section -->
        <Border Grid.Row="2" Background="White" CornerRadius="15" Padding="20">
            <Border.Effect>
                <DropShadowEffect Color="Black" Opacity="0.2" ShadowDepth="5" BlurRadius="15"/>
            </Border.Effect>
            
            <Grid>
                <Grid.ColumnDefinitions>
                    <ColumnDefinition Width="*"/>
                    <ColumnDefinition Width="Auto"/>
                </Grid.ColumnDefinitions>
                
                <!-- Progress Bar -->
                <Border Grid.Column="0" CornerRadius="12" Background="#E5E7EB" Height="25" Margin="0,5,15,5">
                    <ProgressBar x:Name="progressBar" Background="Transparent" BorderThickness="0">
                        <ProgressBar.Foreground>
                            <LinearGradientBrush StartPoint="0,0" EndPoint="1,0">
                                <GradientStop Color="#10B981" Offset="0"/>
                                <GradientStop Color="#059669" Offset="1"/>
                            </LinearGradientBrush>
                        </ProgressBar.Foreground>
                    </ProgressBar>
                </Border>
                
                <!-- Connect Button -->
                <Border Grid.Column="1" CornerRadius="18" Width="130" Height="35">
                    <Border.Background>
                        <LinearGradientBrush StartPoint="0,0" EndPoint="1,0">
                            <GradientStop Color="#8B5CF6" Offset="0"/>
                            <GradientStop Color="#7C3AED" Offset="1"/>
                        </LinearGradientBrush>
                    </Border.Background>
                    <Border.Effect>
                        <DropShadowEffect Color="#7C3AED" Opacity="0.4" ShadowDepth="3" BlurRadius="10"/>
                    </Border.Effect>
                    <Button x:Name="btnConnect" Content="🚀 Connect" 
                            FontSize="14" FontWeight="Bold" Foreground="White"
                            Background="Transparent" BorderThickness="0"/>
                </Border>
            </Grid>
        </Border>
    </Grid>
</Window>
"@

# Create the window
$reader = New-Object System.Xml.XmlNodeReader $xaml
$window = [Windows.Markup.XamlReader]::Load($reader)

# Get controls
$script:txtUNCPath = $window.FindName("txtUNCPath")
$script:txtUsername = $window.FindName("txtUsername")
$script:txtPassword = $window.FindName("txtPassword")
$script:cmbDriveLetter = $window.FindName("cmbDriveLetter")
$script:chkRemember = $window.FindName("chkRemember")
$script:btnConnect = $window.FindName("btnConnect")
$script:txtLog = $window.FindName("txtLog")
$script:progressBar = $window.FindName("progressBar")

# Function to log messages
function Write-Log {
    param([string]$Message)
    $script:txtLog.AppendText("$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'): $Message`r`n")
    $script:txtLog.ScrollToEnd()
}

# Function to play sound
function Play-Sound {
    param(
        [Parameter(Mandatory=$true)]
        [bool]$Success
    )
    
    $soundFile = if ($Success) {
        Join-Path $ScriptPath "Assets\success.wav"
    } else {
        Join-Path $ScriptPath "Assets\error.wav"
    }
    
    if (Test-Path $soundFile) {
        $player = New-Object System.Media.SoundPlayer $soundFile
        $player.Play()
    }
}

# Function to populate available drive letters
function Update-DriveLetters {
    $script:cmbDriveLetter.Items.Clear()
    
    # Get used drive letters from multiple sources
    $allUsedDrives = @()
    
    try {
        # Get PowerShell drives that are single letters (actual drive letters)
        $psDrives = Get-PSDrive -PSProvider FileSystem | Where-Object { $_.Name.Length -eq 1 } | ForEach-Object { $_.Name }
        $allUsedDrives += $psDrives
        Write-Log "PowerShell drives found: $($psDrives -join ', ')"
    }
    catch {
        Write-Log "Error getting PowerShell drives: $_"
    }
    
    try {
        # Get WMI drives with robust null handling
        $wmiDisks = Get-WmiObject -Class Win32_LogicalDisk -ErrorAction SilentlyContinue
        if ($wmiDisks) {
            $wmiDrives = $wmiDisks | Where-Object { 
                $_.DeviceName -ne $null -and 
                $_.DeviceName -ne "" -and 
                $_.DeviceName.Length -ge 2 
            } | ForEach-Object { 
                $_.DeviceName.Substring(0,1) 
            }
            $allUsedDrives += $wmiDrives
            Write-Log "WMI drives found: $($wmiDrives -join ', ')"
        }
    }
    catch {
        Write-Log "Error getting WMI drives: $_"
    }
    
    # Filter to only valid single letter drives and remove duplicates
    $allUsedDrives = $allUsedDrives | Where-Object { $_ -match '^[A-Z]$' } | Sort-Object -Unique
    
    Write-Log "Currently used physical drives: $($allUsedDrives -join ', ')"
    
    # Generate all possible drive letters (A-Z)
    $allDrives = 65..90 | ForEach-Object { [char]$_ }
    $vDriveFound = $false
    
    foreach ($drive in $allDrives) {
        if ($drive -notin $allUsedDrives) {
            $driveOption = "${drive}:"
            $script:cmbDriveLetter.Items.Add($driveOption) | Out-Null
            
            # Check if this is V: drive and mark it for selection
            if ($driveOption -eq "V:") {
                $vDriveFound = $true
                Write-Log "V: drive is available and will be pre-selected"
            }
        }
    }
    
    # Set V: as default if available, otherwise use first available
    if ($vDriveFound) {
        $script:cmbDriveLetter.SelectedItem = "V:"
        Write-Log "V: drive set as default selection"
    }
    elseif ($script:cmbDriveLetter.Items.Count -gt 0) {
        $script:cmbDriveLetter.SelectedIndex = 0
        Write-Log "V: drive not available, selected first available: $($script:cmbDriveLetter.SelectedItem)"
    }
    else {
        Write-Log "No available drive letters found!"
    }
    
    Write-Log "Available drive letters: $($script:cmbDriveLetter.Items -join ', ')"
}

# Function to load saved settings
function Load-SavedSettings {
    try {
        $savedSettings = Get-RegistrySettings
        if ($savedSettings) {
            $script:txtUNCPath.Text = $savedSettings.UNCPath
            $script:txtUsername.Text = $savedSettings.Username
            $script:txtPassword.Password = ConvertFrom-EncryptedString $savedSettings.Password
            $script:chkRemember.IsChecked = $true
            Write-Log "Loaded saved settings successfully"
        }
    }
    catch {
        Write-Log "Error loading saved settings: $_"
    }
}

# Function to mask password in command strings for logging
function Mask-PasswordInCommand {
    param([string]$Command)
    
    # Replace password in net use commands with asterisks
    # Handle patterns like: net use X: "\\path" /user:"username" "password"
    $maskedCommand = $Command -replace '(/user:"[^"]*")\s+"[^"]*"', '$1 "******"'
    
    # Handle patterns like: net use X: "\\path" "password" /user:"username"
    $maskedCommand = $maskedCommand -replace '("\\\\[^"]*")\s+"[^"]*"\s+(/user:)', '$1 "******" $2'
    
    # Handle any other password-like parameters after /user:
    $maskedCommand = $maskedCommand -replace '(/user:[^\s]+)\s+"[^"]*"', '$1 "******"'
    
    return $maskedCommand
}

# Function to execute command with timeout
function Invoke-CommandWithTimeout {
    param(
        [string]$Command,
        [int]$TimeoutSeconds = 5
    )
    
    try {
        $maskedCommand = Mask-PasswordInCommand -Command $Command
        Write-Log "Executing with $TimeoutSeconds second timeout: $maskedCommand"
        
        # Create a job to run the command
        $job = Start-Job -ScriptBlock {
            param($cmd)
            try {
                $result = Invoke-Expression $cmd 2>&1
                return $result
            }
            catch {
                return $_.Exception.Message
            }
        } -ArgumentList $Command
        
        # Wait for the job to complete or timeout
        $completed = Wait-Job -Job $job -Timeout $TimeoutSeconds
        
        if ($completed) {
            $result = Receive-Job -Job $job
            $exitCode = $job.ChildJobs[0].JobStateInfo.State -eq 'Completed' ? 0 : 1
            Remove-Job -Job $job -Force
            return @{
                Success = ($exitCode -eq 0)
                Output = $result
                TimedOut = $false
            }
        }
        else {
            # Timeout occurred
            Stop-Job -Job $job
            Remove-Job -Job $job -Force
            Write-Log "✗ Command timed out after $TimeoutSeconds seconds"
            return @{
                Success = $false
                Output = "Operation timed out after $TimeoutSeconds seconds"
                TimedOut = $true
            }
        }
    }
    catch {
        Write-Log "✗ Error executing command with timeout: $_"
        return @{
            Success = $false
            Output = $_.Exception.Message
            TimedOut = $false
        }
    }
}

# Function to test UNC path accessibility with credentials and timeout
function Test-UNCPath {
    param(
        [string]$UNCPath,
        [string]$Username = "",
        [string]$Password = "",
        [int]$TimeoutSeconds = 5
    )
    
    if ([string]::IsNullOrWhiteSpace($UNCPath)) {
        return $false
    }
    
    # Ensure path starts with \\
    if (-not $UNCPath.StartsWith("\\")) {
        Write-Log "Invalid UNC path format: $UNCPath (must start with \\)"
        return $false
    }
    
    try {
        Write-Log "Testing UNC path accessibility: $UNCPath (timeout: $TimeoutSeconds seconds)"
        
        # If we have credentials, try to test with authentication
        if (-not [string]::IsNullOrWhiteSpace($Username) -and -not [string]::IsNullOrWhiteSpace($Password)) {
            Write-Log "Testing with provided credentials..."
            
            # Find an available temporary drive letter
            $tempDrive = $null
            for ($i = 90; $i -ge 65; $i--) {  # Start from Z and work backwards
                $testLetter = [char]$i
                if (-not (Test-Path "${testLetter}:")) {
                    $tempDrive = "${testLetter}:"
                    break
                }
            }
            
            if ($tempDrive) {
                Write-Log "Using temporary drive $tempDrive for testing..."
                
                # Try to map temporarily using net use with timeout
                $testCmd = "net use $tempDrive `"$UNCPath`" /user:`"$Username`" `"$Password`""
                $result = Invoke-CommandWithTimeout -Command $testCmd -TimeoutSeconds $TimeoutSeconds
                
                if ($result.TimedOut) {
                    Write-Log "✗ Connection attempt timed out after $TimeoutSeconds seconds"
                    return $false
                }
                elseif ($result.Success) {
                    Write-Log "✓ UNC path is accessible with credentials"
                    
                    # Clean up temporary mapping (also with timeout)
                    $cleanupCmd = "net use $tempDrive /delete /yes"
                    Invoke-CommandWithTimeout -Command $cleanupCmd -TimeoutSeconds 3 | Out-Null
                    
                    return $true
                }
                else {
                    Write-Log "✗ Authentication failed or path not accessible: $($result.Output)"
                    return $false
                }
            }
            else {
                Write-Log "No temporary drive letter available for testing"
                return $false
            }
        }
        else {
            # No credentials provided - try basic connectivity test with timeout
            Write-Log "Testing basic connectivity (no credentials provided)..."
            
            # Extract server name for basic connectivity test
            $serverName = $UNCPath.Split('\')[2]
            Write-Log "Testing connectivity to server: $serverName"
            
            # Test DNS resolution with timeout
            try {
                $dnsJob = Start-Job -ScriptBlock {
                    param($server)
                    [System.Net.Dns]::GetHostAddresses($server)
                } -ArgumentList $serverName
                
                $dnsCompleted = Wait-Job -Job $dnsJob -Timeout $TimeoutSeconds
                
                if ($dnsCompleted) {
                    $resolved = Receive-Job -Job $dnsJob
                    Remove-Job -Job $dnsJob -Force
                    
                    if ($resolved.Count -gt 0) {
                        Write-Log "✓ Server name resolves to: $($resolved[0].IPAddressToString)"
                        
                        # Try basic Test-Path without credentials (with timeout)
                        $pathTestJob = Start-Job -ScriptBlock {
                            param($path)
                            Test-Path -Path "FileSystem::$path" -ErrorAction SilentlyContinue
                        } -ArgumentList $UNCPath
                        
                        $pathTestCompleted = Wait-Job -Job $pathTestJob -Timeout $TimeoutSeconds
                        
                        if ($pathTestCompleted) {
                            $isReachable = Receive-Job -Job $pathTestJob
                            Remove-Job -Job $pathTestJob -Force
                            
                            if ($isReachable) {
                                Write-Log "✓ UNC path is accessible (no authentication required)"
                                return $true
                            }
                            else {
                                Write-Log "⚠ Server is reachable but share may require authentication"
                                return $null  # Indeterminate - need credentials to test properly
                            }
                        }
                        else {
                            Stop-Job -Job $pathTestJob
                            Remove-Job -Job $pathTestJob -Force
                            Write-Log "✗ Path test timed out after $TimeoutSeconds seconds"
                            return $false
                        }
                    }
                    else {
                        Write-Log "✗ Cannot resolve server name: $serverName"
                        return $false
                    }
                }
                else {
                    Stop-Job -Job $dnsJob
                    Remove-Job -Job $dnsJob -Force
                    Write-Log "✗ DNS resolution timed out after $TimeoutSeconds seconds"
                    return $false
                }
            }
            catch {
                Write-Log "✗ DNS resolution failed for $serverName`: $_"
                return $false
            }
        }
    }
    catch {
        Write-Log "✗ Error testing UNC path: $_"
        return $false
    }
}

# Function to unmap drive safely
function Unmap-Drive {
    param([string]$DriveLetter)
    
    if ([string]::IsNullOrEmpty($DriveLetter)) {
        return
    }
    
    Write-Log "Attempting to unmap drive $DriveLetter"
    
    try {
        # Method 1: Use net use command
        $unmapCmd = "net use $DriveLetter /delete /yes"
        $result = Invoke-Expression $unmapCmd 2>&1
        
        if ($LASTEXITCODE -eq 0) {
            Write-Log "Successfully unmapped $DriveLetter using net use"
        }
        else {
            Write-Log "net use unmap failed: $result"
            
            # Method 2: Try WScript.Network as fallback
            try {
                $net = New-Object -ComObject WScript.Network
                $net.RemoveNetworkDrive($DriveLetter, $true, $true)
                Write-Log "Successfully unmapped $DriveLetter using WScript.Network"
            }
            catch {
                Write-Log "WScript.Network unmap also failed: $_"
            }
        }
    }
    catch {
        Write-Log "Error during drive unmapping: $_"
    }
}

# Function to clear all form fields securely
function Clear-FormFields {
    param([bool]$ClearAll = $false)
    
    if ($ClearAll) {
        $script:txtUNCPath.Clear()
        $script:txtUsername.Clear()
        Write-Log "Cleared UNC path and username fields"
    }
    
    # Always clear password for security
    $script:txtPassword.Clear()
    Write-Log "Password field cleared"
}

# Function to save settings
function Save-Settings {
    if ($script:chkRemember.IsChecked) {
        try {
            $settings = @{
                UNCPath = $script:txtUNCPath.Text
                Username = $script:txtUsername.Text
                Password = ConvertTo-EncryptedString $script:txtPassword.Password
            }
            Set-RegistrySettings $settings
            Write-Log "Settings saved successfully (encrypted)"
        }
        catch {
            Write-Log "Error saving settings: $_"
        }
    }
    else {
        try {
            Clear-RegistrySettings
            Write-Log "Settings cleared from registry (Remember unchecked)"
        }
        catch {
            Write-Log "Error clearing settings: $_"
        }
    }
}

# UNC Path basic format validation when user tabs out (no connectivity test)
$script:txtUNCPath.Add_LostFocus({
    $uncPath = $script:txtUNCPath.Text.Trim()
    if (-not [string]::IsNullOrWhiteSpace($uncPath)) {
        # Only validate format, not connectivity
        if ($uncPath.StartsWith("\\")) {
            Write-Log "UNC path format is valid: $uncPath"
            # Reset to neutral color - will test connectivity when Connect is pressed
            $script:txtUNCPath.Parent.BorderBrush = "#E5E7EB"
        }
        else {
            Write-Log "Invalid UNC path format: $uncPath (must start with \\)"
            $script:txtUNCPath.Parent.BorderBrush = "Red"
        }
    }
    else {
        # Reset border color if field is empty
        $script:txtUNCPath.Parent.BorderBrush = "#E5E7EB"
    }
})

# Remember checkbox event handler
$script:chkRemember.Add_Unchecked({
    try {
        Write-Log "Remember checkbox unchecked - clearing saved settings"
        Clear-RegistrySettings
        Clear-FormFields -ClearAll $true
        Write-Log "Registry settings and form fields cleared"
    }
    catch {
        Write-Log "Error clearing settings: $_"
    }
})

# Window closing event handler
$window.Add_Closing({
    param($sender, $e)
    
    try {
        Write-Log "Application closing - performing cleanup..."
        
        # Unmap the drive if one was mapped during this session
        if ($script:MappedDrive) {
            Write-Log "Unmapping drive $($script:MappedDrive) before exit"
            try {
                Unmap-Drive -DriveLetter $script:MappedDrive
            }
            catch {
                Write-Log "Drive unmapping completed (may have already been unmapped)"
            }
        }
        else {
            Write-Log "No drive was mapped during this session"
        }
        
        # Handle registry settings based on Remember checkbox
        if (-not $script:chkRemember.IsChecked) {
            Write-Log "Remember checkbox is unchecked - clearing all saved settings on exit"
            Clear-RegistrySettings
            Write-Log "Registry settings cleared on exit"
        }
        else {
            Write-Log "Remember checkbox is checked - preserving saved settings"
        }
        
        # Always clear password from memory for security
        $script:txtPassword.Clear()
        Write-Log "Password cleared from memory"
        
        Write-Log "Application cleanup completed"
    }
    catch {
        Write-Log "Error during window closing: $_"
    }
})

# Connect button click handler
$script:btnConnect.Add_Click({
    # Start progress bar immediately
    Write-Log "🚀 Starting connection process..."
    $script:btnConnect.IsEnabled = $false
    $script:progressBar.IsIndeterminate = $true
    
    # Force UI update to show progress bar immediately
    [System.Windows.Forms.Application]::DoEvents()
    
    try {
        # Validate inputs
        Write-Log "📋 Validating input fields..."
        if ([string]::IsNullOrWhiteSpace($script:txtUNCPath.Text)) {
            throw "UNC Path is required"
        }
        if ([string]::IsNullOrWhiteSpace($script:txtUsername.Text)) {
            throw "Username is required"
        }
        if ([string]::IsNullOrWhiteSpace($script:txtPassword.Password)) {
            throw "Password is required"
        }
        if ($script:cmbDriveLetter.SelectedItem -eq $null) {
            throw "Drive letter must be selected"
        }

        Write-Log "✅ All input fields validated successfully"
        
        # Update progress bar to show validation phase
        [System.Windows.Forms.Application]::DoEvents()

        # Test UNC path accessibility with credentials before attempting to map
        Write-Log "🔍 Validating UNC path with credentials before mapping..."
        $uncPathValid = Test-UNCPath -UNCPath $script:txtUNCPath.Text.Trim() -Username $script:txtUsername.Text -Password $script:txtPassword.Password
        
        if ($uncPathValid -eq $false) {
            $script:txtUNCPath.Parent.BorderBrush = "Red"
            throw "UNC Path is not accessible with the provided credentials. Please verify the path, username, and password."
        }
        elseif ($uncPathValid -eq $null) {
            Write-Log "⚠️ UNC path validation indeterminate - proceeding with mapping attempt"
            $script:txtUNCPath.Parent.BorderBrush = "Orange"
        }
        else {
            Write-Log "✅ UNC path validation successful"
            $script:txtUNCPath.Parent.BorderBrush = "Green"
        }
        
        # Update progress bar to show mapping phase
        Write-Log "💾 Starting drive mapping process..."
        [System.Windows.Forms.Application]::DoEvents()

        # Map the drive
        $driveLetter = $script:cmbDriveLetter.SelectedItem
        $uncPath = $script:txtUNCPath.Text
        $username = $script:txtUsername.Text
        $password = $script:txtPassword.Password

        Write-Log "Attempting to map $uncPath to $driveLetter"
        
        # Method 1: Use net use command with timeout (most reliable for Explorer integration)
        Write-Log "🔗 Attempting mapping using net use command with 5-second timeout..."
        
        # Update progress bar for mapping phase
        [System.Windows.Forms.Application]::DoEvents()
        
        try {
            # First, ensure any existing mapping is removed (with timeout)
            Write-Log "🧹 Cleaning up any existing mappings..."
            $removeCmd = "net use $driveLetter /delete /yes"
            $cleanupResult = Invoke-CommandWithTimeout -Command $removeCmd -TimeoutSeconds 3
            if ($cleanupResult.Success) {
                Write-Log "Previous mapping cleaned up successfully"
            } else {
                Write-Log "No existing mapping to clean up (this is normal)"
            }
            
            # Update progress bar
            [System.Windows.Forms.Application]::DoEvents()
            
            # Map the drive using net use with timeout
            $netUseCmd = "net use $driveLetter `"$uncPath`" /user:`"$username`" `"$password`" /persistent:yes"
            $maskedCmd = Mask-PasswordInCommand -Command $netUseCmd
            Write-Log "⚡ Executing with timeout: $maskedCmd"
            $result = Invoke-CommandWithTimeout -Command $netUseCmd -TimeoutSeconds 5
            
            if ($result.TimedOut) {
                throw "Drive mapping timed out after 5 seconds. The server may be unreachable or credentials may be incorrect."
            }
            elseif ($result.Success) {
                Write-Log "Successfully mapped using net use command"
                Write-Log "Command result: $($result.Output)"
            } 
            else {
                throw "net use command failed. Error: $($result.Output)"
            }
        }
        catch {
            Write-Log "net use method failed: $_"
            
            # Method 2: Fallback to WScript.Network with timeout
            Write-Log "🔄 Trying WScript.Network method as fallback with timeout..."
            
            # Update progress bar for fallback method
            [System.Windows.Forms.Application]::DoEvents()
            
            try {
                # Create a job for the WScript.Network operation
                $wscriptJob = Start-Job -ScriptBlock {
                    param($drive, $path, $user, $pass)
                    $net = New-Object -ComObject WScript.Network
                    $net.MapNetworkDrive($drive, $path, $true, $user, $pass)
                } -ArgumentList $driveLetter, $uncPath, $username, $password
                
                $wscriptCompleted = Wait-Job -Job $wscriptJob -Timeout 5
                
                if ($wscriptCompleted) {
                    Remove-Job -Job $wscriptJob -Force
                    Write-Log "✅ Network drive mapped using WScript.Network"
                }
                else {
                    Stop-Job -Job $wscriptJob
                    Remove-Job -Job $wscriptJob -Force
                    throw "WScript.Network mapping timed out after 5 seconds"
                }
            }
            catch {
                throw "Both mapping methods failed or timed out. Last error: $_"
            }
        }
        
        # Verify the mapping worked
        Start-Sleep -Seconds 2  # Give Windows time to register the drive
        if (Test-Path $driveLetter) {
            Write-Log "Drive mapping verified - $driveLetter is accessible"
        } else {
            Write-Log "Warning: Drive mapping may have succeeded but $driveLetter is not immediately accessible"
        }
        
        # Force Explorer to refresh and recognize the new drive
        Write-Log "Refreshing Windows Explorer..."
        try {
            # Method 1: Send F5 to all Explorer windows
            Add-Type -AssemblyName System.Windows.Forms
            [System.Windows.Forms.SendKeys]::SendWait("{F5}")
            
            # Method 2: Restart Explorer if needed (commented out as it's disruptive)
            # Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue
            # Start-Sleep -Seconds 1
            # Start-Process explorer
            
            # Method 3: Use Shell.Application to refresh
            $shell = New-Object -ComObject Shell.Application
            $shell.Windows() | ForEach-Object { $_.Refresh() }
            
            Write-Log "Explorer refresh commands sent"
        }
        catch {
            Write-Log "Error refreshing Explorer: $_"
        }
        
        # Save settings if requested
        Save-Settings

        # Final verification and Explorer launch
        Write-Log "🔍 Performing final verification..."
        
        # Update progress bar for verification phase
        [System.Windows.Forms.Application]::DoEvents()
        
        # Wait a moment for Windows to fully register the drive
        Start-Sleep -Seconds 3
        
        # Check if drive appears in WMI (indicating Explorer should see it)
        Write-Log "🔎 Checking drive registration in Windows..."
        $wmiCheck = Get-WmiObject -Class Win32_LogicalDisk | Where-Object { $_.DeviceName -eq $driveLetter }
        if ($wmiCheck) {
            Write-Log "✅ Drive verified in WMI - should be visible in Explorer"
        } else {
            Write-Log "⚠️ Warning: Drive not found in WMI - may not be visible in Explorer"
            Write-Log "You may need to restart Explorer or refresh manually"
        }
        
        # Update progress bar for completion phase
        Write-Log "🎉 Finalizing connection..."
        [System.Windows.Forms.Application]::DoEvents()
        
        # Play success sound and open Explorer
        Play-Sound -Success $true
        
        # Try to open Explorer with the mapped drive
        try {
            Start-Process "explorer.exe" -ArgumentList $driveLetter -ErrorAction Stop
            Write-Log "📂 Opened Explorer window for $driveLetter"
        }
        catch {
            Write-Log "⚠️ Failed to open Explorer for $driveLetter, opening general Explorer window"
            Start-Process "explorer.exe"
        }
        
        # Track the mapped drive for cleanup on exit
        $script:MappedDrive = $driveLetter
        
        Write-Log "🎯 Successfully mapped $uncPath to $driveLetter"
        Write-Log "🔧 Drive will be automatically unmapped when application exits"
        Write-Log "💡 If drive is not visible in Explorer, try pressing F5 to refresh"
    }
    catch {
        Write-Log "Error: $_"
        Play-Sound -Success $false
        [System.Windows.MessageBox]::Show($_.Exception.Message, "Error", [System.Windows.MessageBoxButton]::OK, [System.Windows.MessageBoxImage]::Error)
    }
    finally {
        $script:btnConnect.IsEnabled = $true
        $script:progressBar.IsIndeterminate = $false
    }
})

# Initialize
Update-DriveLetters
Load-SavedSettings

# Show the window
$window.ShowDialog() 