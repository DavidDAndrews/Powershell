# Veeam Backup Explorer

A comprehensive PowerShell application for exploring, analyzing, and reporting on Veeam backup repositories.

## Application Structure

### Main Application: `VeeamBackupExplorer.ps1`
This is the **entry point** of the application. It provides:
- Network drive mapping interface
- Credential management with encryption
- Automatic launch of the Report Generator upon successful connection

### Report Generator: `VeeamReportGenerator.ps1`
This is the **second window** that opens after drive mapping. It provides:
- Repository scanning and analysis
- Interactive backup exploration
- HTML report generation

## Quick Start

1. **Run the main application:**
   ```powershell
   .\src\VeeamBackupExplorer.ps1
   ```

2. **Map a network drive:**
   - Enter the UNC path to your Veeam repository (e.g., `\\server\VeeamBackup`)
   - Enter your credentials
   - Select a drive letter (V: is pre-selected for Veeam)
   - Click "Connect"

3. **Analyze backups:**
   - The Report Generator window opens automatically
   - Click "Start Scan" to analyze the repository
   - View results in the Repository Overview and Storage Analysis tabs
   - Click "Generate Report" to create an HTML report

## Features

### Drive Mapping (VeeamBackupExplorer.ps1)
- 🔐 **Secure Credential Storage**: Encrypted password storage in Windows registry
- ⚡ **Fast Timeouts**: 5-second timeout for network operations
- 🎯 **Smart Drive Selection**: Automatically suggests V: drive for Veeam
- 🔒 **Password Protection**: Passwords masked in all logs
- 🧹 **Auto Cleanup**: Drives unmapped on application exit

### Report Generation (VeeamReportGenerator.ps1)
- 📁 **Auto-Discovery**: Automatically finds Veeam backup folders
- 📊 **Comprehensive Analysis**: 
  - Storage usage per machine
  - Backup counts and retention periods
  - Schedule estimation
  - Missing backup detection
- 📈 **Visual Reports**: Beautiful HTML reports with charts and recommendations
- 💡 **AI Insights**: Intelligent recommendations for backup optimization

## Project Structure

```
VeeamExplorer/
├── src/
│   ├── VeeamBackupExplorer.ps1  # Main application (drive mapping)
│   ├── VeeamReportGenerator.ps1  # Report generator window
│   ├── Modules/
│   │   ├── RegistryManager.psm1  # Registry operations
│   │   ├── DriveUtils.psm1       # Drive management
│   │   ├── Crypto.psm1           # Encryption utilities
│   │   ├── BackupAnalyzer.psm1   # Backup analysis engine
│   │   └── ReportGenerator.psm1  # HTML report generation
│   └── Assets/
│       ├── success.wav           # Success sound
│       └── error.wav             # Error sound
└── README.md                     # This file
```

## Requirements

- Windows 10/11
- PowerShell 5.1 or later
- .NET Framework 4.7.2 or later
- Network access to Veeam backup repositories

## Security

- Credentials are encrypted using Windows Data Protection API (DPAPI)
- Passwords are never logged or displayed in plain text
- Registry settings are stored in user-specific hive (HKCU)

## Workflow

```mermaid
graph TD
    A[Launch VeeamBackupExplorer.ps1] --> B[Enter Credentials]
    B --> C[Map Network Drive]
    C --> D[Launch VeeamReportGenerator.ps1]
    D --> E[Scan Repository]
    E --> F[Analyze Backups]
    F --> G[Generate HTML Report]
```

## Future Enhancements

- Veeam API integration for job configuration details
- Automated scheduling with Windows Task Scheduler
- Email report delivery
- Advanced predictive analytics
- Multi-repository support

## License

This project is proprietary software for internal use only. 