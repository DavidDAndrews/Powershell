#Requires -Version 5.1

param(
    [Parameter(Mandatory=$true)]
    [string]$MappedDrive,
    
    [Parameter(Mandatory=$true)]
    [string]$UNCPath
)

Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# Import required modules
$ScriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path
Import-Module "$ScriptPath\Modules\BackupAnalyzer.psm1" -Force -DisableNameChecking
Import-Module "$ScriptPath\Modules\ReportGenerator.psm1" -Force -DisableNameChecking

# Script-level variables
# Ensure the mapped drive has a colon
if ($MappedDrive -notmatch ':$') {
    $MappedDrive = "${MappedDrive}:"
}
$script:MappedDrive = $MappedDrive
$script:UNCPath = $UNCPath

# Extract server name from UNC path and convert to uppercase
$script:ServerName = if ($UNCPath -match '^\\\\([^\\]+)') { 
    $matches[1].ToUpper() 
} else { 
    $env:COMPUTERNAME.ToUpper() 
}

$script:BackupRootPath = $null
$script:BackupInventory = @{}
$script:StorageMetrics = $null
$script:IsInitialScan = $true  # Track if this is the first scan

# XAML for the Report Generator window
[xml]$xaml = @"
<Window
    xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
    xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
    Title="Veeam Report Generator" WindowState="Maximized" MinHeight="700" MinWidth="1000"
    WindowStartupLocation="CenterScreen" 
    FontFamily="Segoe UI">
    
    <Window.Background>
        <LinearGradientBrush StartPoint="0,0" EndPoint="1,1">
            <GradientStop Color="#FF0B5394" Offset="0"/>
            <GradientStop Color="#FF1E88E5" Offset="0.5"/>
            <GradientStop Color="#FF42A5F5" Offset="1"/>
        </LinearGradientBrush>
    </Window.Background>
    
    <Grid Margin="25">
        <Grid.RowDefinitions>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="*"/>
            <RowDefinition Height="Auto"/>
        </Grid.RowDefinitions>

        <!-- Header Section -->
        <Border Grid.Row="0" Background="White" CornerRadius="15" Margin="0,0,0,20" Padding="25">
            <Border.Effect>
                <DropShadowEffect Color="Black" Opacity="0.2" ShadowDepth="5" BlurRadius="15"/>
            </Border.Effect>
            
            <StackPanel>
                <!-- Centered Title Section -->
                <StackPanel HorizontalAlignment="Center">
                    <TextBlock FontSize="32" FontWeight="Bold" 
                              Foreground="#0B5394" HorizontalAlignment="Center" TextAlignment="Center">
                        <Run Text="📊 Veeam Report Generator - "/>
                        <Run x:Name="runServerName" Text="" FontWeight="ExtraBold"/>
                    </TextBlock>
                    
                    <TextBlock FontSize="16" HorizontalAlignment="Center" TextAlignment="Center" 
                               Foreground="#546E7A" Margin="0,5,0,0">
                        <Run Text="{Binding ElementName=window, Path=Tag}" FontWeight="Bold" Foreground="#1565C0"/>
                    </TextBlock>
                </StackPanel>
            </StackPanel>
        </Border>



        <!-- Main Content Area -->
        <Border Grid.Row="1" Background="White" CornerRadius="15" Margin="0,0,0,20">
            <Border.Effect>
                <DropShadowEffect Color="Black" Opacity="0.2" ShadowDepth="5" BlurRadius="15"/>
            </Border.Effect>
            
            <TabControl x:Name="tabControl" Background="Transparent" BorderThickness="0" Margin="10">
                <!-- Scan Log Tab -->
                <TabItem>
                    <TabItem.Header>
                        <TextBlock Text="📋 Scan Log" FontWeight="SemiBold" FontSize="14"/>
                    </TabItem.Header>
                    
                    <ScrollViewer Margin="10">
                        <TextBox x:Name="txtScanLog" IsReadOnly="True" TextWrapping="Wrap" 
                                 Background="#F5F5F5" BorderThickness="0" Padding="10" 
                                 FontFamily="Consolas" FontSize="12" Foreground="#1F2937"/>
                    </ScrollViewer>
                </TabItem>
                
                <!-- Repository Overview Tab -->
                <TabItem>
                    <TabItem.Header>
                        <TextBlock Text="📊 Repository Overview" FontWeight="SemiBold" FontSize="14"/>
                    </TabItem.Header>
                    
                    <Grid Margin="10">
                        <Grid.RowDefinitions>
                            <RowDefinition Height="Auto"/>
                            <RowDefinition Height="*"/>
                        </Grid.RowDefinitions>
                        
                        <TextBlock Grid.Row="0" Text="Backup repository analysis will appear here after scan completes" 
                                   FontStyle="Italic" Foreground="#757575" HorizontalAlignment="Center" 
                                   VerticalAlignment="Center" Margin="0,20"/>
                        
                        <TreeView x:Name="treeBackups" Grid.Row="1" Visibility="Collapsed" 
                                  Background="#F5F5F5" BorderThickness="1" BorderBrush="#E0E0E0"/>
                    </Grid>
                </TabItem>
                
                <!-- Storage Analysis Tab -->
                <TabItem>
                    <TabItem.Header>
                        <TextBlock Text="💾 Storage Analysis" FontWeight="SemiBold" FontSize="14"/>
                    </TabItem.Header>
                    
                    <ScrollViewer Margin="10">
                        <StackPanel x:Name="panelStorageAnalysis">
                            <TextBlock Text="Storage analysis will appear here after scan completes" 
                                       FontStyle="Italic" Foreground="#757575" HorizontalAlignment="Center" 
                                       Margin="0,20"/>
                        </StackPanel>
                    </ScrollViewer>
                </TabItem>
            </TabControl>
        </Border>

        <!-- Bottom Action Bar -->
        <Border Grid.Row="2" Background="White" CornerRadius="15" Padding="20">
            <Border.Effect>
                <DropShadowEffect Color="Black" Opacity="0.2" ShadowDepth="5" BlurRadius="15"/>
            </Border.Effect>
            
            <Grid>
                <Grid.ColumnDefinitions>
                    <ColumnDefinition Width="*"/>
                    <ColumnDefinition Width="Auto"/>
                    <ColumnDefinition Width="Auto"/>
                    <ColumnDefinition Width="Auto"/>
                    <ColumnDefinition Width="Auto"/>
                </Grid.ColumnDefinitions>
                
                <TextBlock Grid.Column="0" x:Name="txtSummary" Text="Ready to scan backup repository" 
                           VerticalAlignment="Center" FontSize="14" Foreground="#546E7A"/>
                
                <Button x:Name="btnScanNow" Grid.Column="1" Content="🔄 Rescan" 
                        Width="120" Height="35" Margin="0,0,10,0"
                        FontWeight="Bold" Foreground="White">
                    <Button.Template>
                        <ControlTemplate TargetType="Button">
                            <Border CornerRadius="18" Background="#4CAF50">
                                <Border.Effect>
                                    <DropShadowEffect Color="#4CAF50" Opacity="0.4" ShadowDepth="3" BlurRadius="10"/>
                                </Border.Effect>
                                <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
                            </Border>
                        </ControlTemplate>
                    </Button.Template>
                </Button>
                
                <Button x:Name="btnGenerateReport" Grid.Column="2" Content="📄 Generate Report" 
                        Width="140" Height="35" Margin="0,0,10,0" IsEnabled="False"
                        FontWeight="Bold" Foreground="White">
                    <Button.Template>
                        <ControlTemplate TargetType="Button">
                            <Border CornerRadius="18">
                                <Border.Style>
                                    <Style TargetType="Border">
                                        <Setter Property="Background" Value="#9E9E9E"/>
                                        <Style.Triggers>
                                            <DataTrigger Binding="{Binding IsEnabled, RelativeSource={RelativeSource AncestorType=Button}}" Value="True">
                                                <Setter Property="Background" Value="#2196F3"/>
                                            </DataTrigger>
                                        </Style.Triggers>
                                    </Style>
                                </Border.Style>
                                <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
                            </Border>
                        </ControlTemplate>
                    </Button.Template>
                </Button>
                
                <Button x:Name="btnSchedule" Grid.Column="3" Content="🕒 Schedule" 
                        Width="100" Height="35" Margin="0,0,10,0" IsEnabled="False"
                        FontWeight="Bold" Foreground="White">
                    <Button.Template>
                        <ControlTemplate TargetType="Button">
                            <Border CornerRadius="18">
                                <Border.Style>
                                    <Style TargetType="Border">
                                        <Setter Property="Background" Value="#9E9E9E"/>
                                        <Style.Triggers>
                                            <DataTrigger Binding="{Binding IsEnabled, RelativeSource={RelativeSource AncestorType=Button}}" Value="True">
                                                <Setter Property="Background" Value="#FF9800"/>
                                            </DataTrigger>
                                        </Style.Triggers>
                                    </Style>
                                </Border.Style>
                                <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
                            </Border>
                        </ControlTemplate>
                    </Button.Template>
                </Button>
                
                <Button x:Name="btnClose" Grid.Column="4" Content="❌ Close" 
                        Width="100" Height="35"
                        FontWeight="Bold" Foreground="White">
                    <Button.Template>
                        <ControlTemplate TargetType="Button">
                            <Border CornerRadius="18" Background="#F44336">
                                <Border.Effect>
                                    <DropShadowEffect Color="#F44336" Opacity="0.4" ShadowDepth="3" BlurRadius="10"/>
                                </Border.Effect>
                                <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
                            </Border>
                        </ControlTemplate>
                    </Button.Template>
                </Button>
            </Grid>
        </Border>
    </Grid>
</Window>
"@

# Function to log messages
function Write-Log {
    param(
        [string]$Message,
        [string]$Level = "INFO"
    )
    
    # Convert text levels to emojis
    $levelIcon = switch ($Level) {
        "INFO" { "ℹ️" }
        "STATUS" { "📋" }
        "ERROR" { "❌" }
        "WARNING" { "⚠️" }
        "SUCCESS" { "✅" }
        default { "ℹ️" }
    }
    
    $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $logEntry = "$timestamp $levelIcon $Message"
    
    if ($script:txtScanLog) {
        $script:txtScanLog.AppendText("$logEntry`r`n")
        $script:txtScanLog.ScrollToEnd()
    }
    
    # Also update summary for important messages
    if ($Level -eq "STATUS" -and $script:txtSummary) {
        $script:txtSummary.Text = $Message
    }
}

# Create the window
$reader = New-Object System.Xml.XmlNodeReader $xaml
$window = [Windows.Markup.XamlReader]::Load($reader)
$window.Tag = $script:UNCPath

# Get controls with null checking
$script:btnScanNow = $window.FindName("btnScanNow")
$script:txtScanLog = $window.FindName("txtScanLog")
$script:tabControl = $window.FindName("tabControl")
$script:treeBackups = $window.FindName("treeBackups")
$script:panelStorageAnalysis = $window.FindName("panelStorageAnalysis")
$script:txtSummary = $window.FindName("txtSummary")
$script:btnGenerateReport = $window.FindName("btnGenerateReport")
$script:btnSchedule = $window.FindName("btnSchedule")
$script:btnClose = $window.FindName("btnClose")
$script:runServerName = $window.FindName("runServerName")


# Log control initialization status
Write-Log "Initializing UI controls..."
if (-not $script:txtScanLog) { Write-Log "Warning: txtScanLog control not found" }
if (-not $script:runServerName) { Write-Log "Warning: runServerName control not found" }
if (-not $script:txtSummary) { Write-Log "Warning: txtSummary control not found" }

# Set the server name in the header and window title
if ($script:runServerName) {
    $script:runServerName.Text = $script:ServerName
}
$window.Title = "Veeam Report Generator - $script:ServerName"

# Update initial status to include server context
if ($script:txtSummary) {
    $script:txtSummary.Text = "Ready to scan backup repository on $script:ServerName"
}



# Function to find backup root folder
function Find-BackupRootFolder {
    param([string]$RootPath)
    
    Write-Log "Starting search for Veeam backup folder in $RootPath" -Level "STATUS"
    
    # Validate that the root path exists
    if (-not (Test-Path $RootPath)) {
        Write-Log "❌ Error: Root path '$RootPath' does not exist or is not accessible" -Level "ERROR"
        return $null
    }
    
    $backupFolderNames = @("Backup", "Backups", "VeeamBackup", "VeeamBackups", "Veeam")
    $foundPath = $null
    
    # First check root level
    foreach ($folderName in $backupFolderNames) {
        $testPath = Join-Path $RootPath $folderName
        if (Test-Path $testPath) {
            Write-Log "Found potential backup folder: $testPath"
            
            # Verify it contains VBK or VIB files in subdirectories
            $backupFiles = Get-ChildItem -Path $testPath -Recurse -Include "*.vbk", "*.vib" -ErrorAction SilentlyContinue | Select-Object -First 1
            
            if ($backupFiles) {
                $foundPath = $testPath
                Write-Log "✅ Confirmed Veeam backup folder: $testPath" -Level "STATUS"
                break
            }
        }
    }
    
    # If not found at root, search one level deeper
    if (-not $foundPath) {
        Write-Log "Backup folder not found at root level, searching subdirectories..."
        
        try {
            $subFolders = Get-ChildItem -Path $RootPath -Directory -ErrorAction Stop
        }
        catch {
            Write-Log "❌ Error accessing subdirectories in ${RootPath}: $_" -Level "ERROR"
            return $null
        }
        
        foreach ($subFolder in $subFolders) {
            foreach ($folderName in $backupFolderNames) {
                $testPath = Join-Path $subFolder.FullName $folderName
                if (Test-Path $testPath) {
                    Write-Log "Found potential backup folder: $testPath"
                    
                    $backupFiles = Get-ChildItem -Path $testPath -Recurse -Include "*.vbk", "*.vib" -ErrorAction SilentlyContinue | Select-Object -First 1
                    
                    if ($backupFiles) {
                        $foundPath = $testPath
                        Write-Log "✅ Confirmed Veeam backup folder: $testPath" -Level "STATUS"
                        break
                    }
                }
            }
            if ($foundPath) { break }
        }
    }
    
    return $foundPath
}

# Function to scan backup repository
function Scan-BackupRepository {
    param([string]$BackupPath)
    
    Write-Log "Scanning backup repository: $BackupPath" -Level "STATUS"
    $script:BackupInventory = @{}
    
    try {
        # Get all VM/Machine folders
        $machineFolders = Get-ChildItem -Path $BackupPath -Directory -ErrorAction Stop
        
        Write-Log "Found $($machineFolders.Count) machine folders"
        
        foreach ($machineFolder in $machineFolders) {
            Write-Log "Scanning machine: $($machineFolder.Name)"
            
            $machineData = @{
                Name = $machineFolder.Name
                Path = $machineFolder.FullName
                FullBackups = @()
                IncrementalBackups = @()
                TotalSize = 0
                LastBackupDate = $null
            }
            
            # Get all backup files
            $vbkFiles = Get-ChildItem -Path $machineFolder.FullName -Filter "*.vbk" -ErrorAction SilentlyContinue
            $vibFiles = Get-ChildItem -Path $machineFolder.FullName -Filter "*.vib" -ErrorAction SilentlyContinue
            
            # Process full backups
            foreach ($vbk in $vbkFiles) {
                $backupInfo = @{
                    FileName = $vbk.Name
                    Size = $vbk.Length
                    SizeGB = [math]::Round($vbk.Length / 1GB, 2)
                    CreationTime = $vbk.CreationTime
                    LastWriteTime = $vbk.LastWriteTime
                }
                $machineData.FullBackups += $backupInfo
                $machineData.TotalSize += $vbk.Length
                
                Write-Log "  - Full backup: $($vbk.Name) ($($backupInfo.SizeGB) GB)"
            }
            
            # Process incremental backups
            foreach ($vib in $vibFiles) {
                $backupInfo = @{
                    FileName = $vib.Name
                    Size = $vib.Length
                    SizeGB = [math]::Round($vib.Length / 1GB, 2)
                    CreationTime = $vib.CreationTime
                    LastWriteTime = $vib.LastWriteTime
                }
                $machineData.IncrementalBackups += $backupInfo
                $machineData.TotalSize += $vib.Length
                
                Write-Log "  - Incremental: $($vib.Name) ($($backupInfo.SizeGB) GB)"
            }
            
            # Calculate total size and last backup date
            $machineData.TotalSizeGB = [math]::Round($machineData.TotalSize / 1GB, 2)
            
            $allBackups = $machineData.FullBackups + $machineData.IncrementalBackups
            if ($allBackups.Count -gt 0) {
                $machineData.LastBackupDate = ($allBackups | Sort-Object LastWriteTime -Descending | Select-Object -First 1).LastWriteTime
                
                Write-Log "  Total size: $($machineData.TotalSizeGB) GB, Last backup: $($machineData.LastBackupDate)"
                
                # Only add to inventory if there are actual backup files
                $script:BackupInventory[$machineFolder.Name] = $machineData
            }
            else {
                Write-Log "  No backup files found - skipping this folder"
            }
        }
        
        Write-Log "✅ Repository scan completed successfully"
        return $true
    }
    catch {
        Write-Log "❌ Error scanning repository: $_" -Level "ERROR"
        return $false
    }
}

# Button click handlers
$script:btnScanNow.Add_Click({
    if ($script:IsInitialScan) {
        Write-Log "🚀 Starting initial repository scan..." -Level "STATUS"
    } else {
        Write-Log "🔄 Starting repository rescan..." -Level "STATUS"
    }
    
    $script:btnScanNow.IsEnabled = $false
    $script:btnScanNow.Content = "⏳ Scanning..."
    
    # Clear previous results to ensure fresh scan
    $script:BackupInventory = @{}
    $script:StorageMetrics = $null
    
    # Clear UI elements
    if ($script:treeBackups) {
        $script:treeBackups.Items.Clear()
        $script:treeBackups.Visibility = "Collapsed"
    }
    if ($script:panelStorageAnalysis) {
        $script:panelStorageAnalysis.Children.Clear()
    }
    
    # Disable other buttons during scan
    $script:btnGenerateReport.IsEnabled = $false
    $script:btnSchedule.IsEnabled = $false
    
    try {
        # Find backup root folder
        $script:BackupRootPath = Find-BackupRootFolder -RootPath $script:MappedDrive
        
        if ($script:BackupRootPath) {
            # Scan the repository
            $scanSuccess = Scan-BackupRepository -BackupPath $script:BackupRootPath
            
            if ($scanSuccess) {
                # Update UI with results
                Update-UIWithResults
                
                # Enable report generation
                $script:btnGenerateReport.IsEnabled = $true
                $script:btnSchedule.IsEnabled = $true
                
                $totalMachines = $script:BackupInventory.Count
                $totalSize = ($script:BackupInventory.Values | Measure-Object -Property TotalSizeGB -Sum).Sum
                
                # Update summary text based on scan type
                if ($script:IsInitialScan) {
                    $script:txtSummary.Text = "Repository Initial Scan Completed Successfully"
                    Write-Log "Repository Initial Scan Completed Successfully" -Level "STATUS"
                    $script:IsInitialScan = $false  # Mark that initial scan is done
                } else {
                    $script:txtSummary.Text = "Repository Re-Scan Completed Successfully"
                    Write-Log "Repository Re-Scan Completed Successfully" -Level "STATUS"
                }
            }
        }
        else {
            Write-Log "❌ Could not find Veeam backup folder in $script:MappedDrive" -Level "ERROR"
            [System.Windows.MessageBox]::Show(
                "Could not find a Veeam backup folder in the mapped drive. Please ensure the drive contains Veeam backup files.",
                "Backup Folder Not Found",
                [System.Windows.MessageBoxButton]::OK,
                [System.Windows.MessageBoxImage]::Warning
            )
        }
    }
    finally {
        $script:btnScanNow.IsEnabled = $true
        $script:btnScanNow.Content = "🔄 Rescan"
    }
})

$script:btnGenerateReport.Add_Click({
    Write-Log "Generating HTML report..." -Level "STATUS"
    
    try {
        $reportPath = New-HTMLReport -BackupInventory $script:BackupInventory -StorageMetrics $script:StorageMetrics -BackupRootPath $script:BackupRootPath -ServerName $script:ServerName
        if ($reportPath -and (Test-Path $reportPath)) {
                    Write-Log "✅ Report generated successfully for $script:ServerName`: $reportPath" -Level "STATUS"
        
        # Automatically launch the report
        try {
            Start-Process $reportPath
            Write-Log "🚀 HTML report opened in default browser" -Level "STATUS"
            }
            catch {
                Write-Log "⚠️ Failed to open report automatically: $_" -Level "WARNING"
                Write-Log "Report location: $reportPath" -Level "STATUS"
            }
        }
    }
    catch {
        Write-Log "❌ Error generating report: $_" -Level "ERROR"
        [System.Windows.MessageBox]::Show(
            "Failed to generate report: $_",
            "Error",
            [System.Windows.MessageBoxButton]::OK,
            [System.Windows.MessageBoxImage]::Error
        )
    }
})

$script:btnSchedule.Add_Click({
    Write-Log "Opening schedule configuration..." -Level "STATUS"
    # This will be implemented in the next phase
    [System.Windows.MessageBox]::Show(
        "Schedule configuration will be implemented in the next phase.",
        "Coming Soon",
        [System.Windows.MessageBoxButton]::OK,
        [System.Windows.MessageBoxImage]::Information
    )
})

$script:btnClose.Add_Click({
    $window.Close()
})

# Function to disconnect drive safely
function Disconnect-Drive {
    param([string]$DriveLetter)
    
    if ([string]::IsNullOrEmpty($DriveLetter)) {
        return
    }
    
    Write-Log "Attempting to disconnect drive $DriveLetter"
    
    try {
        # Method 1: Use net use command
        $unmapCmd = "net use $DriveLetter /delete /yes"
        $result = Invoke-Expression $unmapCmd 2>&1
        
        if ($LASTEXITCODE -eq 0) {
            Write-Log "Successfully disconnected $DriveLetter using net use"
        }
        else {
            Write-Log "net use disconnect failed: $result"
            
            # Method 2: Try WScript.Network as fallback
            try {
                $net = New-Object -ComObject WScript.Network
                $net.RemoveNetworkDrive($DriveLetter, $true, $true)
                Write-Log "Successfully disconnected $DriveLetter using WScript.Network"
            }
            catch {
                Write-Log "WScript.Network disconnect also failed: $_"
            }
        }
    }
    catch {
        Write-Log "Error during drive disconnection: $_"
    }
}

# Window closing event handler to cleanup mapped drive
$window.Add_Closing({
    param($source, $eventData)
    
    try {
        Write-Log "Report Generator closing - performing cleanup..."
        
        # Disconnect the drive that was mapped by VeeamBackupExplorer
        if ($script:MappedDrive) {
            Write-Log "Disconnecting drive $($script:MappedDrive) before exit"
            Disconnect-Drive -DriveLetter $script:MappedDrive
        }
        else {
            Write-Log "No drive to disconnect"
        }
        
        Write-Log "Report Generator cleanup completed"
    }
    catch {
        Write-Log "Error during Report Generator cleanup: $_"
    }
})

# Function to update UI with scan results
function Update-UIWithResults {
    Write-Log "Updating UI with scan results..." -Level "STATUS"
    
    # Calculate storage metrics
            $script:StorageMetrics = Measure-StorageMetrics -BackupInventory $script:BackupInventory
    
    # Update Repository Overview tab
    Update-RepositoryTreeView
    
    # Update Storage Analysis tab
    Update-StorageAnalysis
    
    # Get recommendations
    $recommendations = Get-StorageRecommendations -StorageMetrics $script:StorageMetrics
    
    # Log recommendations
    if ($recommendations.Count -gt 0) {
        Write-Log "=== Storage Recommendations ===" -Level "STATUS"
        foreach ($rec in $recommendations) {
            $prefix = switch ($rec.Severity) {
                "High" { "❗" }
                "Medium" { "⚠️" }
                "Low" { "ℹ️" }
                default { "•" }
            }
            Write-Log "$prefix [$($rec.Machine)] $($rec.Message)"
        }
    }
}

# Function to update the repository tree view
function Update-RepositoryTreeView {
    $script:treeBackups.Items.Clear()
    $script:treeBackups.Visibility = "Visible"
    
    # Create root node
    $rootNode = New-Object System.Windows.Controls.TreeViewItem
    $rootNode.Header = "📁 $($script:BackupRootPath) ($($script:StorageMetrics.TotalMachines) machines, $([math]::Round($script:StorageMetrics.TotalStorageGB, 2)) GB)"
    $rootNode.IsExpanded = $true
    
    # Add machine nodes
    foreach ($machineName in ($script:BackupInventory.Keys | Sort-Object)) {
        $machineData = $script:BackupInventory[$machineName]
        $machineMetric = $script:StorageMetrics.MachineMetrics[$machineName]
        
        # Create machine node
        $machineNode = New-Object System.Windows.Controls.TreeViewItem
        $statusIcon = if ($machineMetric.LastBackupAge -and $machineMetric.LastBackupAge.Days -gt 7) { "⚠️" } else { "✅" }
        $lastBackupText = if ($machineData.LastBackupDate) { $machineData.LastBackupDate.ToString('yyyy-MM-dd') } else { "No backups" }
        $machineNode.Header = "$statusIcon $machineName ($($machineMetric.TotalSizeGB) GB, Last: $lastBackupText)"
        $machineNode.IsExpanded = $false
        
        # Add summary node
        $summaryNode = New-Object System.Windows.Controls.TreeViewItem
        $summaryNode.Header = "📊 Summary: $($machineMetric.FullBackupCount) full, $($machineMetric.IncrementalBackupCount) incremental backups"
        $machineNode.Items.Add($summaryNode)
        
        # Add retention info
        $retentionNode = New-Object System.Windows.Controls.TreeViewItem
        $retentionNode.Header = "📅 Retention: $($machineMetric.RetentionAnalysis.RetentionPoints) backup points ($($machineMetric.RetentionAnalysis.EstimatedSchedule) schedule)"
        $machineNode.Items.Add($retentionNode)
        
        # Add full backups folder
        if ($machineData.FullBackups.Count -gt 0) {
            $fullBackupsNode = New-Object System.Windows.Controls.TreeViewItem
            $fullBackupsNode.Header = "💾 Full Backups ($($machineData.FullBackups.Count) files, $([math]::Round($machineMetric.FullBackupSizeGB, 2)) GB)"
            
            foreach ($backup in ($machineData.FullBackups | Sort-Object LastWriteTime -Descending)) {
                $backupNode = New-Object System.Windows.Controls.TreeViewItem
                $backupNode.Header = "• $($backup.FileName) ($($backup.SizeGB) GB) - $($backup.LastWriteTime.ToString('yyyy-MM-dd HH:mm'))"
                $fullBackupsNode.Items.Add($backupNode)
            }
            
            $machineNode.Items.Add($fullBackupsNode)
        }
        
        # Add incremental backups folder
        if ($machineData.IncrementalBackups.Count -gt 0) {
            $incrementalNode = New-Object System.Windows.Controls.TreeViewItem
            $incrementalNode.Header = "📈 Incremental Backups ($($machineData.IncrementalBackups.Count) files, $([math]::Round($machineMetric.IncrementalBackupSizeGB, 2)) GB)"
            
            foreach ($backup in ($machineData.IncrementalBackups | Sort-Object LastWriteTime -Descending)) {
                $backupNode = New-Object System.Windows.Controls.TreeViewItem
                $backupNode.Header = "• $($backup.FileName) ($($backup.SizeGB) GB) - $($backup.LastWriteTime.ToString('yyyy-MM-dd HH:mm'))"
                $incrementalNode.Items.Add($backupNode)
            }
            
            $machineNode.Items.Add($incrementalNode)
        }
        
        $rootNode.Items.Add($machineNode)
    }
    
    $script:treeBackups.Items.Add($rootNode)
}

# Function to update storage analysis panel
function Update-StorageAnalysis {
    $script:panelStorageAnalysis.Children.Clear()
    
    # Title
    $titleBlock = New-Object System.Windows.Controls.TextBlock
    $titleBlock.Text = "Storage Analysis Report"
    $titleBlock.FontSize = 20
    $titleBlock.FontWeight = "Bold"
    $titleBlock.Margin = "0,0,0,20"
    $titleBlock.HorizontalAlignment = "Center"
    $script:panelStorageAnalysis.Children.Add($titleBlock)
    
    # Overall summary card
    $summaryBorder = New-Object System.Windows.Controls.Border
    $summaryBorder.Background = "#E3F2FD"
    $summaryBorder.CornerRadius = "10"
    $summaryBorder.Padding = "20"
    $summaryBorder.Margin = "0,0,0,20"
    
    $summaryStack = New-Object System.Windows.Controls.StackPanel
    
    $summaryTitle = New-Object System.Windows.Controls.TextBlock
    $summaryTitle.Text = "📊 Repository Summary"
    $summaryTitle.FontSize = 16
    $summaryTitle.FontWeight = "Bold"
    $summaryTitle.Margin = "0,0,0,10"
    $summaryStack.Children.Add($summaryTitle)
    
    $summaryItems = @(
        "Total Machines: $($script:StorageMetrics.TotalMachines)",
        "Total Storage Used: $([math]::Round($script:StorageMetrics.TotalStorageGB, 2)) GB",
        "Full Backups: $([math]::Round($script:StorageMetrics.TotalFullBackupsGB, 2)) GB",
        "Incremental Backups: $([math]::Round($script:StorageMetrics.TotalIncrementalBackupsGB, 2)) GB",
        "Average per Machine: $($script:StorageMetrics.AverageBackupSizeGB) GB",
        "Largest Machine: $($script:StorageMetrics.LargestMachine.Name) ($($script:StorageMetrics.LargestMachine.SizeGB) GB)"
    )
    
    foreach ($item in $summaryItems) {
        $itemBlock = New-Object System.Windows.Controls.TextBlock
        $itemBlock.Text = "• $item"
        $itemBlock.FontSize = 14
        $itemBlock.Margin = "10,2,0,2"
        $summaryStack.Children.Add($itemBlock)
    }
    
    $summaryBorder.Child = $summaryStack
    $script:panelStorageAnalysis.Children.Add($summaryBorder)
    
    # Machine details
    $machineTitle = New-Object System.Windows.Controls.TextBlock
    $machineTitle.Text = "💻 Machine Details"
    $machineTitle.FontSize = 18
    $machineTitle.FontWeight = "Bold"
    $machineTitle.Margin = "0,20,0,10"
    $script:panelStorageAnalysis.Children.Add($machineTitle)
    
    # Sort machines by size descending
    $sortedMachines = $script:StorageMetrics.MachineMetrics.Keys | Sort-Object { $script:StorageMetrics.MachineMetrics[$_].TotalSizeGB } -Descending
    
    foreach ($machineName in $sortedMachines) {
        $metric = $script:StorageMetrics.MachineMetrics[$machineName]
        
        # Machine card
        $machineBorder = New-Object System.Windows.Controls.Border
        $machineBorder.Background = "#F5F5F5"
        $machineBorder.BorderBrush = "#E0E0E0"
        $machineBorder.BorderThickness = "1"
        $machineBorder.CornerRadius = "8"
        $machineBorder.Padding = "20"
        $machineBorder.Margin = "0,0,0,15"
        
        $machineStack = New-Object System.Windows.Controls.StackPanel
        
        # Machine name and status
        $machineHeader = New-Object System.Windows.Controls.TextBlock
        $statusIcon = if ($metric.LastBackupAge -and $metric.LastBackupAge.Days -gt 7) { "⚠️" } else { "✅" }
        $machineHeader.Text = "$statusIcon $machineName"
        $machineHeader.FontSize = 16
        $machineHeader.FontWeight = "Bold"
        $machineStack.Children.Add($machineHeader)
        
        # Create detailed backup statistics sections
        $detailsPanel = New-Object System.Windows.Controls.StackPanel
        $detailsPanel.Margin = "0,10,0,0"
        
        # Overall machine stats
        $overallText = "📊 Total Size: $($metric.TotalSizeGB) GB | 📅 Retention: $($metric.RetentionAnalysis.RetentionPoints) backup points | 🕒 Schedule: $($metric.RetentionAnalysis.EstimatedSchedule)"
        $overallBlock = New-Object System.Windows.Controls.TextBlock
        $overallBlock.Text = $overallText
        $overallBlock.FontSize = 13
        $overallBlock.FontWeight = "SemiBold"
        $overallBlock.Margin = "0,0,0,15"
        $overallBlock.TextWrapping = "Wrap"
        $detailsPanel.Children.Add($overallBlock)
        
        # Create a grid for side-by-side backup type details
        $backupGrid = New-Object System.Windows.Controls.Grid
        $backupGrid.Margin = "0,0,0,10"
        
        # Define two columns
        $col1 = New-Object System.Windows.Controls.ColumnDefinition
        $col1.Width = "*"
        $col2 = New-Object System.Windows.Controls.ColumnDefinition  
        $col2.Width = "*"
        $backupGrid.ColumnDefinitions.Add($col1)
        $backupGrid.ColumnDefinitions.Add($col2)
        
        # Incremental Backups section (left column)
        $incrementalPanel = New-Object System.Windows.Controls.StackPanel
        $incrementalPanel.Margin = "0,0,10,0"
        
        $incrementalHeader = New-Object System.Windows.Controls.TextBlock
        $incrementalHeader.Text = "🔴 Incremental Backups (.vib)"
        $incrementalHeader.FontWeight = "Bold"
        $incrementalHeader.FontSize = 14
        $incrementalHeader.Foreground = "#D32F2F"
        $incrementalHeader.Margin = "0,0,0,8"
        $incrementalPanel.Children.Add($incrementalHeader)
        
        # Get incremental backup stats
        $machineData = $script:BackupInventory[$machineName]
        $incrementalStats = @()
        if ($machineData.IncrementalBackups.Count -gt 0) {
            $lastIncremental = ($machineData.IncrementalBackups | Sort-Object LastWriteTime -Descending | Select-Object -First 1).LastWriteTime
            $smallestIncremental = ($machineData.IncrementalBackups | Sort-Object SizeGB | Select-Object -First 1).SizeGB
            $largestIncremental = ($machineData.IncrementalBackups | Sort-Object SizeGB -Descending | Select-Object -First 1).SizeGB
            $avgIncremental = [math]::Round(($machineData.IncrementalBackups | Measure-Object -Property SizeGB -Average).Average, 2)
            
            $incrementalStats = @(
                "Count: $($metric.IncrementalBackupCount) files",
                "Last Run: $($lastIncremental.ToString('ddd yyyy-MM-dd HH:mm:ss'))",
                "Smallest: $smallestIncremental GB",
                "Largest: $largestIncremental GB", 
                "Average: $avgIncremental GB",
                "Std Dev: $($metric.IncrementalBackupStdDev) GB",
                "Total Size: $([math]::Round($metric.IncrementalBackupSizeGB, 2)) GB"
            )
        } else {
            $incrementalStats = @("No incremental backups found")
        }
        
        foreach ($stat in $incrementalStats) {
            $statBlock = New-Object System.Windows.Controls.TextBlock
            $statBlock.Text = $stat
            $statBlock.FontSize = 12
            $statBlock.Margin = "0,2,0,2"
            $incrementalPanel.Children.Add($statBlock)
        }
        
        [System.Windows.Controls.Grid]::SetColumn($incrementalPanel, 0)
        $backupGrid.Children.Add($incrementalPanel)
        
        # Full Backups section (right column)
        $fullPanel = New-Object System.Windows.Controls.StackPanel
        $fullPanel.Margin = "10,0,0,0"
        
        $fullHeader = New-Object System.Windows.Controls.TextBlock
        $fullHeader.Text = "🟢 Full Backups (.vbk)"
        $fullHeader.FontWeight = "Bold"
        $fullHeader.FontSize = 14
        $fullHeader.Foreground = "#2E7D32"
        $fullHeader.Margin = "0,0,0,8"
        $fullPanel.Children.Add($fullHeader)
        
        # Get full backup stats
        $fullStats = @()
        if ($machineData.FullBackups.Count -gt 0) {
            $lastFull = ($machineData.FullBackups | Sort-Object LastWriteTime -Descending | Select-Object -First 1).LastWriteTime
            $smallestFull = ($machineData.FullBackups | Sort-Object SizeGB | Select-Object -First 1).SizeGB
            $largestFull = ($machineData.FullBackups | Sort-Object SizeGB -Descending | Select-Object -First 1).SizeGB
            $avgFull = [math]::Round(($machineData.FullBackups | Measure-Object -Property SizeGB -Average).Average, 2)
            
            $fullStats = @(
                "Count: $($metric.FullBackupCount) files",
                "Last Run: $($lastFull.ToString('ddd yyyy-MM-dd HH:mm:ss'))",
                "Smallest: $smallestFull GB",
                "Largest: $largestFull GB",
                "Average: $avgFull GB",
                "Std Dev: $($metric.FullBackupStdDev) GB", 
                "Total Size: $([math]::Round($metric.FullBackupSizeGB, 2)) GB"
            )
        } else {
            $fullStats = @("No full backups found")
        }
        
        foreach ($stat in $fullStats) {
            $statBlock = New-Object System.Windows.Controls.TextBlock
            $statBlock.Text = $stat
            $statBlock.FontSize = 12
            $statBlock.Margin = "0,2,0,2"
            $fullPanel.Children.Add($statBlock)
        }
        
        [System.Windows.Controls.Grid]::SetColumn($fullPanel, 1)
        $backupGrid.Children.Add($fullPanel)
        
        $detailsPanel.Children.Add($backupGrid)
        $machineStack.Children.Add($detailsPanel)
        
        # Add warnings if any
        if ($metric.LastBackupAge -and $metric.LastBackupAge.Days -gt 7) {
            $warningBlock = New-Object System.Windows.Controls.TextBlock
            $warningBlock.Text = "⚠️ No backup for $($metric.LastBackupAge.Days) days"
            $warningBlock.FontSize = 12
            $warningBlock.Foreground = "#D32F2F"
            $warningBlock.Margin = "0,10,0,0"
            $machineStack.Children.Add($warningBlock)
        }
        
        if ($metric.RetentionAnalysis.MissingBackupDates.Count -gt 0) {
            $missingBlock = New-Object System.Windows.Controls.TextBlock
            $missingBlock.Text = "📅 Missing backups on $($metric.RetentionAnalysis.MissingBackupDates.Count) days"
            $missingBlock.FontSize = 12
            $missingBlock.Foreground = "#F57C00"
            $missingBlock.Margin = "0,5,0,0"
            $machineStack.Children.Add($missingBlock)
        }
        
        $machineBorder.Child = $machineStack
        $script:panelStorageAnalysis.Children.Add($machineBorder)
    }
}

# Initialize
Write-Log "Veeam Report Generator initialized"
Write-Log "Backup path: $script:UNCPath on drive $script:MappedDrive"

# Automatically perform the first scan
Write-Log "🚀 Starting initial backup repository scan..." -Level "STATUS"

# Start auto-scan in background using a timer to let UI load first
$autoScanTimer = New-Object System.Windows.Threading.DispatcherTimer
$autoScanTimer.Interval = [TimeSpan]::FromMilliseconds(500)  # Wait 500ms for UI to be ready
$autoScanTimer.Add_Tick({
    $autoScanTimer.Stop()
    
    # Trigger the scan button click event
    try {
        $script:btnScanNow.RaiseEvent([System.Windows.RoutedEventArgs]::new([System.Windows.Controls.Primitives.ButtonBase]::ClickEvent))
    }
    catch {
        Write-Log "Auto-scan failed to trigger: $_" -Level "ERROR"
    }
})
$autoScanTimer.Start()

# Show the window
$window.ShowDialog()
