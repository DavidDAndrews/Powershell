# Registry Manager Module
$script:RegPath = "HKCU:\Software\VeeamBackupExplorer"
$script:RegKeySettings = "Settings"

function Initialize-RegistryPath {
    if (-not (Test-Path $script:RegPath)) {
        New-Item -Path $script:RegPath -Force | Out-Null
    }
}

function Get-RegistrySettings {
    Initialize-RegistryPath
    
    try {
        $uncPath = (Get-ItemProperty -Path $script:RegPath -Name "UNCPath" -ErrorAction SilentlyContinue).UNCPath
        $username = (Get-ItemProperty -Path $script:RegPath -Name "Username" -ErrorAction SilentlyContinue).Username
        $password = (Get-ItemProperty -Path $script:RegPath -Name "Password" -ErrorAction SilentlyContinue).Password
        
        if ($uncPath -and $username -and $password) {
            $settingsObj = @{
                UNCPath = $uncPath
                Username = $username
                Password = $password
            }
            return $settingsObj
        }
    }
    catch {
        Write-Warning "Failed to read registry settings: $_"
    }
    return $null
}

function Set-RegistrySettings {
    param (
        [Parameter(Mandatory=$true)]
        [hashtable]$Settings
    )
    
    Initialize-RegistryPath
    
    try {
        New-ItemProperty -Path $script:RegPath -Name "UNCPath" -Value $Settings.UNCPath -PropertyType String -Force | Out-Null
        New-ItemProperty -Path $script:RegPath -Name "Username" -Value $Settings.Username -PropertyType String -Force | Out-Null
        New-ItemProperty -Path $script:RegPath -Name "Password" -Value $Settings.Password -PropertyType String -Force | Out-Null
    }
    catch {
        Write-Error "Failed to save registry settings: $_"
        throw
    }
}

function Clear-RegistrySettings {
    if (Test-Path $script:RegPath) {
        try {
            Remove-ItemProperty -Path $script:RegPath -Name "UNCPath" -ErrorAction SilentlyContinue
            Remove-ItemProperty -Path $script:RegPath -Name "Username" -ErrorAction SilentlyContinue
            Remove-ItemProperty -Path $script:RegPath -Name "Password" -ErrorAction SilentlyContinue
        }
        catch {
            Write-Warning "Failed to clear registry settings: $_"
        }
    }
}

Export-ModuleMember -Function Get-RegistrySettings, Set-RegistrySettings, Clear-RegistrySettings 