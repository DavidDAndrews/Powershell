# Drive Utilities Module

function Get-AvailableDriveLetters {
    # Get all possible drive letters (A-Z)
    $allLetters = 65..90 | ForEach-Object { [char]$_ }
    
    # Get currently used drive letters
    $usedLetters = (Get-PSDrive -PSProvider FileSystem).Name
    
    # Return available letters
    $availableLetters = $allLetters | Where-Object { $_ -notin $usedLetters }
    return $availableLetters
}

function Test-UNCPath {
    param(
        [Parameter(Mandatory=$true)]
        [string]$Path
    )
    
    if (-not $Path.StartsWith("\\")) {
        throw "Invalid UNC path format. Path must start with \\"
    }
    
    $parts = $Path.Split('\') | Where-Object { $_ }
    if ($parts.Count -lt 2) {
        throw "Invalid UNC path. Must include server name and share name"
    }
}

function Remove-NetworkDrive {
    param(
        [Parameter(Mandatory=$true)]
        [string]$DriveLetter
    )
    
    try {
        # Remove : from drive letter if present
        $driveLetter = $DriveLetter.TrimEnd(':')
        
        # Check if drive exists
        if (Test-Path "${driveLetter}:") {
            # Try to remove any existing connections
            Remove-PSDrive -Name $driveLetter -Force -ErrorAction Stop
            
            # Also remove any persistent mappings
            $net = New-Object -ComObject WScript.Network
            $net.RemoveNetworkDrive("${driveLetter}:", $true, $true)
        }
        return $true
    }
    catch {
        Write-Error "Failed to remove network drive $DriveLetter`: $_"
        return $false
    }
}

function Test-NetworkConnection {
    param(
        [Parameter(Mandatory=$true)]
        [string]$UNCPath
    )
    
    try {
        # Extract server name from UNC path
        $server = $UNCPath.Split('\')[2]
        
        # Test connection to server
        $testResult = Test-Connection -ComputerName $server -Count 1 -Quiet
        
        if (-not $testResult) {
            throw "Cannot reach server $server"
        }
        
        # Test if share exists
        if (-not (Test-Path -Path $UNCPath -ErrorAction Stop)) {
            throw "Cannot access share $UNCPath"
        }
        
        return $true
    }
    catch {
        Write-Error "Network connection test failed: $_"
        return $false
    }
}

Export-ModuleMember -Function Get-AvailableDriveLetters, Test-UNCPath, Remove-NetworkDrive, Test-NetworkConnection 