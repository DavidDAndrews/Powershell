# Report Generator Module for Veeam Backup Explorer

function New-HTMLReport {
    param(
        [Parameter(Mandatory=$true)]
        [hashtable]$BackupInventory,
        
        [Parameter(Mandatory=$true)]
        [hashtable]$StorageMetrics,
        
        [Parameter(Mandatory=$true)]
        [hashtable]$BackupLocations,
        
        [Parameter(Mandatory=$false)]
        [string]$ServerName = $env:COMPUTERNAME.ToUpper(),
        
        [string]$OutputPath = ""
    )
    
    # Generate output filename in the specified format: ServerName-DayName-YYYY-MMM-DD-VeeamExplorerReport
    if ([string]::IsNullOrWhiteSpace($OutputPath)) {
        $currentDate = Get-Date
        $dayName = $currentDate.ToString("ddd").ToUpper()  # MON, TUE, WED, etc.
        $year = $currentDate.ToString("yyyy")           # 2025
        $month = $currentDate.ToString("MMM")           # Jan, Feb, Mar, etc.
        $day = $currentDate.ToString("dd")              # 01, 02, etc.
        
        $filename = "VeeamExplorer-$year-$month-$day-$dayName.html"
        $downloadsPath = Join-Path $env:USERPROFILE "Downloads"
        $OutputPath = Join-Path $downloadsPath $filename
    }
    
    # Calculate total counts for dashboard
    $totalVMs = $StorageMetrics.TotalMachines
    $totalIncrementals = ($StorageMetrics.MachineMetrics.Values | Measure-Object -Property IncrementalBackupCount -Sum).Sum
    $totalFullBackups = ($StorageMetrics.MachineMetrics.Values | Measure-Object -Property FullBackupCount -Sum).Sum
    
    # Get actual disk space information from the first repository or ADHOC location
    $backupDrive = $null
    if ($BackupLocations.Repositories.Count -gt 0) {
        $backupDrive = Split-Path $BackupLocations.Repositories[0].Path -Qualifier
    } elseif ($BackupLocations.AdhocBackups.Count -gt 0) {
        $backupDrive = Split-Path $BackupLocations.AdhocBackups[0].Directory -Qualifier
    }
    
    try {
        if ($backupDrive) {
            $driveInfo = Get-WmiObject -Class Win32_LogicalDisk | Where-Object { $_.DeviceID -eq $backupDrive }
            if ($driveInfo) {
                $totalCapacityTB = [math]::Round($driveInfo.Size / 1TB, 2)
                $usedSpaceTB = [math]::Round(($driveInfo.Size - $driveInfo.FreeSpace) / 1TB, 2)
                $freeSpaceTB = [math]::Round($driveInfo.FreeSpace / 1TB, 2)
                $backupDataTB = [math]::Round($StorageMetrics.TotalStorageGB / 1024, 2)
                $usagePercent = [math]::Round(($usedSpaceTB / $totalCapacityTB) * 100, 1)
            } else {
                # Fallback if WMI fails
                $backupDataTB = [math]::Round($StorageMetrics.TotalStorageGB / 1024, 2)
                $totalCapacityTB = [math]::Round($backupDataTB * 1.5, 2)
                $usedSpaceTB = $backupDataTB
                $freeSpaceTB = $totalCapacityTB - $usedSpaceTB
                $usagePercent = [math]::Round(($usedSpaceTB / $totalCapacityTB) * 100, 1)
            }
        } else {
            # No backup locations found
            $backupDataTB = [math]::Round($StorageMetrics.TotalStorageGB / 1024, 2)
            $totalCapacityTB = [math]::Round($backupDataTB * 1.5, 2)
            $usedSpaceTB = $backupDataTB
            $freeSpaceTB = $totalCapacityTB - $usedSpaceTB
            $usagePercent = [math]::Round(($usedSpaceTB / $totalCapacityTB) * 100, 1)
        }
    } catch {
        # Fallback calculation
        $backupDataTB = [math]::Round($StorageMetrics.TotalStorageGB / 1024, 2)
        $totalCapacityTB = [math]::Round($backupDataTB * 1.5, 2)
        $usedSpaceTB = $backupDataTB
        $freeSpaceTB = $totalCapacityTB - $usedSpaceTB
        $usagePercent = [math]::Round(($usedSpaceTB / $totalCapacityTB) * 100, 1)
    }

    # HIT logo is embedded as data URI - no file copying needed
    $reportDir = Split-Path $OutputPath -Parent
    
    # Ensure Downloads directory exists
    if (-not (Test-Path $reportDir)) {
        New-Item -Path $reportDir -ItemType Directory -Force | Out-Null
    }

    $html = @"
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Veeam Backup Repository Analysis - $ServerName</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        html {
            scroll-behavior: smooth;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 80%;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.08);
            overflow: hidden;
        }
        
        .header {
            background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
            color: white;
            padding: 30px;
            text-align: center;
            position: relative;
        }
        
        .header-logo {
            position: absolute;
            top: 20px;
            left: 30px;
            max-height: 120px;
            max-width: 300px;
        }
        
        .header h1 {
            font-size: 2.5em;
            margin-bottom: 10px;
            font-weight: 300;
        }
        
        .header p {
            font-size: 1.1em;
            opacity: 0.9;
        }
        
        .summary {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 25px;
            padding: 35px;
            background: linear-gradient(135deg, #f1f5f9, #e2e8f0);
        }
        
        .summary-card {
            background: linear-gradient(135deg, #ffffff, #f1f5f9);
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 2px 12px rgba(0,0,0,0.06);
            text-align: center;
            border-left: 4px solid #3498db;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
            border: 1px solid rgba(148, 163, 184, 0.1);
        }

        .summary-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 25px rgba(52, 152, 219, 0.15);
            background: linear-gradient(135deg, #ffffff, #e2e8f0);
        }

        /* Individual summary card accent colors */
        .summary-card:nth-child(1) {
            border-left: 4px solid #3B82F6;
            background: linear-gradient(135deg, #EBF8FF, #DBEAFE);
        }

        .summary-card:nth-child(1) h3 {
            color: #1E40AF;
        }

        .summary-card:nth-child(2) {
            border-left: 4px solid #EF4444;
            background: linear-gradient(135deg, #FEF2F2, #FEE2E2);
        }

        .summary-card:nth-child(2) h3 {
            color: #DC2626;
        }

        .summary-card:nth-child(3) {
            border-left: 4px solid #10B981;
            background: linear-gradient(135deg, #ECFDF5, #D1FAE5);
        }

        .summary-card:nth-child(3) h3 {
            color: #059669;
        }
        
        .summary-card:nth-child(4) {
            background: linear-gradient(135deg, #fefefe, #f8fafc);
            border-left: 4px solid #e74c3c;
        }
        
        .summary-card:nth-child(4) h3 {
            white-space: nowrap;
            font-size: 1.6em;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .summary-card h3 {
            color: #1e293b;
            font-size: 2em;
            margin-bottom: 5px;
            font-weight: 700;
            text-shadow: 0 1px 2px rgba(0,0,0,0.1);
        }
        
        .summary-card:nth-child(4) h3 {
            font-size: 2.5em;
            margin-bottom: 10px;
            font-weight: 600;
        }
        
        .summary-card p {
            color: #64748b;
            font-weight: 600;
            font-size: 0.95em;
            letter-spacing: 0.5px;
        }
        
        .summary-card:nth-child(4) p {
            font-weight: 700;
            font-size: 1.05em;
            color: #475569;
            letter-spacing: 0.5px;
        }

        /* Repository status color coding */
        .repo-status-healthy {
            border: 3px solid #059669 !important;
            background: linear-gradient(135deg, #F0FDF4, #DCFCE7) !important;
            box-shadow: 0 4px 20px rgba(5, 150, 105, 0.15) !important;
        }

        .repo-status-warning {
            border: 3px solid #D97706 !important;
            background: linear-gradient(135deg, #FFFBEB, #FEF3C7) !important;
            box-shadow: 0 4px 20px rgba(217, 119, 6, 0.15) !important;
        }

        .repo-status-critical {
            border: 3px solid #DC2626 !important;
            background: linear-gradient(135deg, #FEF2F2, #FEE2E2) !important;
            box-shadow: 0 4px 20px rgba(220, 38, 38, 0.15) !important;
            animation: pulse-warning 3s ease-in-out infinite;
        }

        @keyframes pulse-warning {
            0%, 100% { 
                box-shadow: 0 4px 20px rgba(220, 38, 38, 0.15);
            }
            50% { 
                box-shadow: 0 6px 30px rgba(220, 38, 38, 0.3);
            }
        }

        .repo-status-text {
            display: block;
            margin-top: 8px;
            font-size: 0.8em;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .repo-status-healthy .repo-status-text {
            color: #059669;
        }

        .repo-status-warning .repo-status-text {
            color: #D97706;
        }

        .repo-status-critical .repo-status-text {
            color: #DC2626;
        }
        
        .chart-section {
            background: #f8f9fa;
            margin: 0;
        }
        
        .chart-container {
            background: white;
            border-radius: 12px;
            padding: 30px;
            box-shadow: 0 3px 15px rgba(0,0,0,0.08);
            margin-bottom: 20px;
        }
        
        .chart-title {
            color: #2c3e50;
            font-size: 1.5em;
            margin-bottom: 20px;
            text-align: center;
            font-weight: 500;
        }
        
        .chart-canvas {
            max-height: 400px;
        }
        
        /* Adjust chart height based on number of VMs */
        .chart-canvas-large {
            max-height: 500px;
        }
        
        /* Chart scroll animations */
        .chart-animate {
            opacity: 0;
            transform: translateY(50px);
            transition: opacity 0.8s ease-out, transform 0.8s ease-out;
        }
        
        .chart-animate.chart-visible {
            opacity: 1;
            transform: translateY(0);
        }
        
        /* Repository Tab System */
        .repo-tabs {
            margin-top: 20px;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
            background: white;
        }
        
        .tab-nav {
            display: flex;
            background: linear-gradient(135deg, #f8fafc, #e2e8f0);
            border-bottom: 2px solid #e2e8f0;
        }
        
        .tab-button {
            flex: 1;
            padding: 15px 20px;
            background: none;
            border: none;
            cursor: pointer;
            font-size: 0.95em;
            font-weight: 600;
            color: #64748b;
            transition: all 0.3s ease;
            border-bottom: 3px solid transparent;
            position: relative;
        }
        
        .tab-button:hover {
            background: rgba(59, 130, 246, 0.05);
            color: #3b82f6;
        }
        
        .tab-button.active {
            color: #3b82f6;
            background: white;
            border-bottom-color: #3b82f6;
            box-shadow: 0 -2px 8px rgba(59, 130, 246, 0.1);
        }
        
        .tab-content {
            display: none;
            padding: 25px;
            background: white;
            min-height: 200px;
        }
        
        .tab-content.active {
            display: block;
            animation: fadeIn 0.3s ease-in-out;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        /* Tab Content Styling */
        .tab-overview {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }
        
        .overview-card {
            background: linear-gradient(135deg, #f8fafc, #f1f5f9);
            border-radius: 10px;
            padding: 20px;
            border-left: 4px solid #3b82f6;
        }
        
        .overview-card h4 {
            margin: 0 0 10px 0;
            color: #1e40af;
            font-size: 1.1em;
        }
        
        .overview-stat {
            display: flex;
            justify-content: space-between;
            margin: 8px 0;
            font-size: 0.9em;
        }
        
        .overview-stat-label {
            color: #64748b;
        }
        
        .overview-stat-value {
            font-weight: 600;
            color: #1e293b;
        }
        
        .machines-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 15px;
        }
        
        .machine-summary-card {
            background: linear-gradient(135deg, #ffffff, #f8fafc);
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 15px;
            transition: all 0.2s ease;
            cursor: pointer;
            position: relative;
        }
        
        .machine-summary-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            border-color: #3b82f6;
            background: linear-gradient(135deg, #f0f9ff, #e0f2fe);
        }
        
        .machine-summary-card::after {
            content: "→";
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 20px;
            color: #3b82f6;
            opacity: 0;
            transition: opacity 0.2s ease;
        }
        
        .machine-summary-card:hover::after {
            opacity: 1;
        }
        
        /* Storage Breakdown Styles */
        .storage-breakdown-section {
            margin: 30px 0;
            background: linear-gradient(135deg, #f8fafc, #f1f5f9);
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
        }
        
        .storage-breakdown-title {
            font-size: 1.4em;
            font-weight: 600;
            color: #1e293b;
            margin-bottom: 20px;
            text-align: center;
        }
        
        .storage-breakdown-container {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        
        .repo-storage-card {
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
            transition: box-shadow 0.3s ease;
        }
        
        .repo-storage-card:hover {
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
        
        .repo-storage-header {
            padding: 20px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: space-between;
            background: linear-gradient(135deg, #ffffff, #f8fafc);
            transition: background 0.3s ease;
        }
        
        .repo-storage-header:hover {
            background: linear-gradient(135deg, #f0f9ff, #e0f2fe);
        }
        
        .repo-storage-info {
            flex: 1;
            display: flex;
            flex-direction: column;
            gap: 5px;
        }
        
        .repo-storage-name {
            font-size: 1.1em;
            font-weight: 600;
            color: #1e293b;
        }
        
        .repo-storage-stats {
            font-size: 0.9em;
            color: #64748b;
        }
        
        .repo-storage-bar {
            width: 200px;
            height: 20px;
            background: #e2e8f0;
            border-radius: 10px;
            overflow: hidden;
            margin: 0 20px;
        }
        
        .repo-storage-fill {
            height: 100%;
            background: linear-gradient(90deg, #3b82f6, #2563eb);
            transition: width 0.5s ease;
            border-radius: 10px;
        }
        
        .collapse-icon {
            font-size: 1.2em;
            color: #64748b;
            transition: transform 0.3s ease;
        }
        
        .collapse-icon.rotated {
            transform: rotate(-90deg);
        }
        
        .repo-storage-details {
            padding: 0 20px 20px 20px;
            background: #f8fafc;
            border-top: 1px solid #e2e8f0;
        }
        
        .vm-storage-item {
            padding: 15px;
            margin: 10px 0;
            background: white;
            border-radius: 8px;
            border: 1px solid #e2e8f0;
        }
        
        .vm-storage-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }
        
        .vm-storage-name {
            font-weight: 600;
            color: #334155;
        }
        
        .vm-storage-size {
            font-weight: 600;
            color: #3b82f6;
        }
        
        .vm-storage-details {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }
        
        .vm-storage-bar-container {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .vm-storage-bar {
            flex: 1;
            height: 12px;
            background: #e2e8f0;
            border-radius: 6px;
            overflow: hidden;
        }
        
        .vm-storage-fill {
            height: 100%;
            background: linear-gradient(90deg, #10b981, #059669);
            transition: width 0.5s ease;
            border-radius: 6px;
        }
        
        .vm-storage-percent {
            font-size: 0.85em;
            font-weight: 600;
            color: #64748b;
            min-width: 45px;
            text-align: right;
        }
        
        .vm-storage-breakdown {
            display: flex;
            gap: 20px;
            font-size: 0.85em;
            color: #64748b;
            padding-left: 5px;
        }
        
        .vm-storage-full {
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .vm-storage-inc {
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .machine-summary-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }
        
        .machine-summary-name {
            font-weight: 600;
            color: #1e293b;
            font-size: 1em;
        }
        
        .machine-summary-size {
            font-size: 0.9em;
            color: #3b82f6;
            font-weight: 600;
        }
        
        .machine-summary-stats {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
            font-size: 0.85em;
        }
        
        .machine-summary-stat {
            text-align: center;
            padding: 8px;
            background: #f8fafc;
            border-radius: 6px;
        }
        
        .machine-summary-stat-value {
            display: block;
            font-weight: 600;
            color: #1e293b;
        }
        
        .machine-summary-stat-label {
            color: #64748b;
            font-size: 0.8em;
        }
        
        .content {
            padding: 0;
        }
        
        .vm-section {
            border-bottom: 1px solid #e9ecef;
            margin-bottom: 30px;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.06);
            background: white;
        }
        
        .vm-header {
            background: linear-gradient(135deg, #3498db, #2980b9);
            color: white;
            padding: 20px;
            font-size: 1.1em;
            font-weight: 600;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 8px rgba(52, 152, 219, 0.2);
            border-radius: 8px 8px 0 0;
            flex-wrap: wrap;
            gap: 10px;
        }
        
        .retention-info {
            font-size: 0.85em;
            opacity: 0.9;
            white-space: nowrap;
            margin-left: auto;
        }
        
        .backup-stats {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 0;
        }
        
        .backup-type {
            padding: 25px;
            border-radius: 0 0 8px 8px;
        }
        
        .backup-type.incremental {
            background: linear-gradient(135deg, #ffebee, #fce4ec);
            border-right: 1px solid #e9ecef;
            box-shadow: inset 0 1px 3px rgba(244, 67, 54, 0.1);
        }
        
        .backup-type.full {
            background: linear-gradient(135deg, #e8f5e8, #e1f5fe);
            box-shadow: inset 0 1px 3px rgba(76, 175, 80, 0.1);
        }
        
        .backup-type h4 {
            margin: 0 0 15px 0;
            font-size: 1.1em;
            color: #2c3e50;
        }
        
        .stat-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
            font-size: 0.9em;
        }
        
        .stat-label {
            color: #7f8c8d;
        }
        
        .stat-value {
            font-weight: 600;
            color: #2c3e50;
        }
        
        .machine-card {
            background: white;
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            padding: 25px;
            margin-bottom: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
            transition: box-shadow 0.2s ease;
        }

        .machine-card:hover {
            box-shadow: 0 4px 16px rgba(0,0,0,0.10);
        }
        
        .machine-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }
        
        .machine-name {
            font-size: 1.4em;
            font-weight: bold;
            color: #333;
        }
        
        .machine-status {
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.9em;
            font-weight: bold;
        }
        
        .status-ok {
            background: #C8E6C9;
            color: #2E7D32;
        }
        
        .status-warning {
            background: #FFE0B2;
            color: #E65100;
        }
        
        .status-error {
            background: #FFCDD2;
            color: #C62828;
        }
        
        .machine-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin-bottom: 15px;
        }
        
        .stat-item {
            text-align: center;
            padding: 10px;
            background: #f5f5f5;
            border-radius: 8px;
        }
        
        .stat-label {
            font-size: 0.85em;
            color: #666;
            margin-bottom: 5px;
        }
        
        .stat-value {
            font-size: 1.2em;
            font-weight: bold;
            color: #1976D2;
        }
        
        .backup-timeline {
            margin-top: 20px;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 8px;
        }
        
        .timeline-title {
            font-weight: bold;
            margin-bottom: 10px;
            color: #555;
        }
        
        .timeline-bar {
            height: 40px;
            background: #e0e0e0;
            border-radius: 5px;
            position: relative;
            overflow: hidden;
        }
        
        .timeline-segment {
            position: absolute;
            height: 100%;
            border-radius: 3px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 0.8em;
            font-weight: bold;
        }
        
        .segment-full {
            background: #1976D2;
        }
        
        .segment-incremental {
            background: #66BB6A;
        }
        
        .section {
            margin-bottom: 40px;
        }
        
        .section-title {
            color: #2c3e50;
            font-size: 1.8em;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 3px solid #3498db;
            font-weight: 600;
        }
        
        .repo-summary {
            background: linear-gradient(135deg, #f8fafc, #e2e8f0);
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 25px;
            border-left: 4px solid #3498db;
        }
        
        .repo-summary p {
            margin: 5px 0;
            color: #475569;
            font-weight: 500;
        }
        
        .recommendations-summary {
            background: linear-gradient(135deg, #F8FAFC, #F1F5F9);
            border-radius: 15px;
            padding: 0;
            margin-top: 30px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            overflow: hidden;
        }

        .recommendation-overview {
            background: linear-gradient(135deg, #EBF8FF, #DBEAFE);
            padding: 25px;
            border-bottom: 2px solid #E5E7EB;
        }

        .recommendation-overview h3 {
            color: #1E40AF;
            margin: 0 0 15px 0;
            font-size: 1.3em;
            font-weight: 700;
        }

        .severity-badges {
            display: flex;
            gap: 12px;
            margin-bottom: 15px;
            flex-wrap: wrap;
        }

        .severity-badge {
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 0.85em;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        .severity-badge.high {
            background: linear-gradient(135deg, #FEE2E2, #FECACA);
            color: #DC2626;
            border: 1px solid #FCA5A5;
        }

        .severity-badge.medium {
            background: linear-gradient(135deg, #FEF3C7, #FDE68A);
            color: #D97706;
            border: 1px solid #FBBF24;
        }

        .severity-badge.low {
            background: linear-gradient(135deg, #D1FAE5, #A7F3D0);
            color: #059669;
            border: 1px solid #6EE7B7;
        }

        .summary-text {
            color: #4B5563;
            font-size: 1em;
            line-height: 1.6;
            margin: 0;
        }

        .recommendation-category {
            border-bottom: 1px solid #E5E7EB;
            padding: 0;
        }

        .recommendation-category:last-child {
            border-bottom: none;
        }

        .category-header {
            background: linear-gradient(135deg, #F9FAFB, #F3F4F6);
            color: #374151;
            padding: 20px 25px;
            margin: 0;
            font-size: 1.1em;
            font-weight: 600;
            border-bottom: 1px solid #E5E7EB;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .category-items {
            padding: 0;
        }

        .recommendation-item {
            padding: 20px 25px;
            border-bottom: 1px solid #F3F4F6;
            transition: background-color 0.2s ease;
        }

        .recommendation-item:last-child {
            border-bottom: none;
        }

        .recommendation-item:hover {
            background: linear-gradient(135deg, #FAFBFC, #F8FAFC);
        }

        .recommendation-item.high {
            border-left: 4px solid #DC2626;
            background: linear-gradient(135deg, #FFFBFB, #FEF7F7);
        }

        .recommendation-item.medium {
            border-left: 4px solid #D97706;
            background: linear-gradient(135deg, #FFFCF5, #FEF9F1);
        }

        .recommendation-item.low {
            border-left: 4px solid #059669;
            background: linear-gradient(135deg, #F7FEF8, #F0FDF4);
        }

        .recommendation-header {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 8px;
        }

        .severity-icon {
            font-size: 1.2em;
        }

        .machine-name {
            font-weight: 700;
            color: #1F2937;
            font-size: 1em;
        }

        .severity-label {
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 0.75em;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-left: auto;
        }

        .severity-label.high {
            background: #FEE2E2;
            color: #DC2626;
            border: 1px solid #FCA5A5;
        }

        .severity-label.medium {
            background: #FEF3C7;
            color: #D97706;
            border: 1px solid #FBBF24;
        }

        .severity-label.low {
            background: #D1FAE5;
            color: #059669;
            border: 1px solid #6EE7B7;
        }

        .recommendation-message {
            color: #4B5563;
            line-height: 1.6;
            font-size: 0.95em;
            padding-left: 32px;
        }

        /* Machine-specific recommendations */
        .machine-recommendations {
            margin-top: 20px;
            background: linear-gradient(135deg, #FAFBFC, #F8FAFC);
            border-radius: 12px;
            padding: 20px;
            border: 1px solid #E5E7EB;
        }

        .recommendations-header {
            color: #374151;
            margin: 0 0 15px 0;
            font-size: 1.1em;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .recommendations-list {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .machine-recommendation-item {
            background: white;
            border-radius: 8px;
            padding: 15px;
            border: 1px solid #E5E7EB;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        .machine-recommendation-item:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .machine-recommendation-item.high {
            border-left: 4px solid #DC2626;
            background: linear-gradient(135deg, #FFFBFB, #FEF7F7);
        }

        .machine-recommendation-item.medium {
            border-left: 4px solid #D97706;
            background: linear-gradient(135deg, #FFFCF5, #FEF9F1);
        }

        .machine-recommendation-item.low {
            border-left: 4px solid #059669;
            background: linear-gradient(135deg, #F7FEF8, #F0FDF4);
        }

        .recommendation-header-inline {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 8px;
            flex-wrap: wrap;
        }

        .severity-icon {
            font-size: 1.1em;
        }

        .category-icon {
            font-size: 1em;
        }

        .category-name {
            font-weight: 600;
            color: #374151;
            font-size: 0.9em;
        }

        .severity-badge-inline {
            padding: 2px 8px;
            border-radius: 10px;
            font-size: 0.7em;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-left: auto;
        }

        .severity-badge-inline.high {
            background: #FEE2E2;
            color: #DC2626;
            border: 1px solid #FCA5A5;
        }

        .severity-badge-inline.medium {
            background: #FEF3C7;
            color: #D97706;
            border: 1px solid #FBBF24;
        }

        .severity-badge-inline.low {
            background: #D1FAE5;
            color: #059669;
            border: 1px solid #6EE7B7;
        }

        .recommendation-message-inline {
            color: #4B5563;
            line-height: 1.5;
            font-size: 0.9em;
            margin-left: 20px;
        }

        /* Summary statistics cards */
        .summary-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .summary-stat-card {
            background: white;
            padding: 25px;
            border-radius: 12px;
            text-align: center;
            box-shadow: 0 3px 15px rgba(0, 0, 0, 0.08);
            border: 1px solid #e2e8f0;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        .summary-stat-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 25px rgba(0, 0, 0, 0.15);
        }

        .summary-stat-card.high {
            border-left: 5px solid #DC2626;
            background: linear-gradient(135deg, #FFFBFB, #FEF7F7);
        }

        .summary-stat-card.medium {
            border-left: 5px solid #D97706;
            background: linear-gradient(135deg, #FFFCF5, #FEF9F1);
        }

        .summary-stat-card.low {
            border-left: 5px solid #059669;
            background: linear-gradient(135deg, #F7FEF8, #F0FDF4);
        }

        .summary-stat-card.info {
            border-left: 5px solid #3B82F6;
            background: linear-gradient(135deg, #F7F9FF, #EBF4FF);
        }

        .summary-stat-card h3 {
            color: #1F2937;
            font-size: 2.2em;
            margin: 0 0 8px 0;
            font-weight: 700;
        }

        .summary-stat-card p {
            color: #374151;
            font-weight: 600;
            margin: 0 0 5px 0;
            font-size: 1em;
        }

        .summary-stat-card small {
            color: #6B7280;
            font-size: 0.85em;
            font-style: italic;
        }
        
        .recommendation-item {
            display: flex;
            align-items: start;
            margin-bottom: 10px;
        }
        
        .recommendation-icon {
            margin-right: 10px;
            font-size: 1.2em;
        }
        
        .footer {
            background: #2c3e50;
            color: white;
            text-align: center;
            padding: 20px;
            font-size: 0.9em;
        }
        
        .machine-header-blue {
            background: linear-gradient(135deg, #3b82f6, #1d4ed8);
            color: white;
            padding: 15px 25px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: 600;
        }
        
        .backup-stats-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
            margin-top: 20px;
        }
        
        .backup-type-section h3 {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 15px;
            padding-bottom: 8px;
            border-bottom: 2px solid;
        }
        
        .incremental-section h3 {
            color: #ef4444;
            border-bottom-color: #ef4444;
        }
        
        .full-section h3 {
            color: #22c55e;
            border-bottom-color: #22c55e;
        }
        
        .stat-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
            padding: 4px 0;
        }
        
        .stat-label {
            color: #4a5568;
            font-weight: 500;
        }
        
        .stat-value {
            color: #2d3748;
            font-weight: 600;
        }
        
        @media print {
            body {
                background: white;
                padding: 0;
            }
            
            .container {
                box-shadow: none;
            }
        }
    </style>
</head>
<body>
                           <div class="container">
        <div class="header">
            <img src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0idXRmLTgiPz4NCjwhLS0gR2VuZXJhdG9yOiBBZG9iZSBJbGx1c3RyYXRvciAxNi4wLjQsIFNWRyBFeHBvcnQgUGx1Zy1JbiAuIFNWRyBWZXJzaW9uOiA2LjAwIEJ1aWxkIDApICAtLT4NCjwhRE9DVFlQRSBzdmcgUFVCTElDICItLy9XM0MvL0RURCBTVkcgMS4wLy9FTiIgImh0dHA6Ly93d3cudzMub3JnL1RSLzIwMDEvUkVDLVNWRy0yMDAxMDkwNC9EVEQvc3ZnMTAuZHRkIj4NCjxzdmcgdmVyc2lvbj0iMS4wIiBpZD0iTGF5ZXJfMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgeD0iMHB4IiB5PSIwcHgiDQoJIHdpZHRoPSIyMjlweCIgaGVpZ2h0PSIxNDhweCIgdmlld0JveD0iNjkuNSAzODcuNSAyMjkgMTQ4IiBlbmFibGUtYmFja2dyb3VuZD0ibmV3IDY5LjUgMzg3LjUgMjI5IDE0OCIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSI+DQo8Zz4NCgkNCgkJPGltYWdlIG92ZXJmbG93PSJ2aXNpYmxlIiBvcGFjaXR5PSIwLjc1IiB3aWR0aD0iMjQyIiBoZWlnaHQ9IjE2NyIgeGxpbms6aHJlZj0iZGF0YTppbWFnZS9wbmc7YmFzZTY0LGlWQk9SdzBLR2dvQUFBQU5TVWhFVWdBQUFQSUFBQUNuQ0FZQUFBQXJLd0hnQUFBQUNYQklXWE1BQUFzU0FBQUxFZ0hTM1g3OEFBQUEKR1hSRldIUlRiMlowZDJGeVpRQkJaRzlpWlNCSmJXRm5aVkpsWVdSNWNjbGxQQUFBTWNwSlJFRlVlTnJzZll0eTQwaXVMSXFVN0o0OQovLytsdXp0alN5THJub2x0M2dPbk13RVVMYnV0WGpKQ0lYZjdJVDRxQzBBQ1NKZ2R4M0VjeDNFY3gzRWN4M0VjeDNFY3gzRWN4M0VjCng5OUgrNVVmM251LzYrZTMxdm9qUG9SNzNJZEh2ZmJqZURBZ0R5elc2cy8xUjF6Z2Q3Z1AvU3ZCSFozdnNYbjhsd0JaTElJMmVCNnQKdUloNzVmKytldkhkNlI3WVYxLzNpSmR3QVBvM0JUSlpCSTE4M1hZdTdsNVkwSld2UDJVQkZvQmIrWG92aUV2WEhWMTc4dXpDeno4QQovWnNBR1JaQkJONG1BRDJ5c05VaVp1LzlNMEdkZ0xmNlB2bzhldkhhVTFBUGJEeWx6Zk1BOUFNRDJTM21ETFRadjBmT0xRTnY5dThQCkxjTEFlcWw3RU4yVHlFdnB4V3V2WEc4RTZsYTRsbWdUT2NEOHFFQW1WcGd0M3VyTGRpeHF0bmlycjJpUjA4VllCTy9vUGNEZlk5ZWYKZ2VmRDExdjBtdkNjNU44OXdQd2dRQllnVnE5SnZHZUF6aFpTdEloWDh2VmFXT2laQzFyZHZLYmszNVZyVjBCbUlGcVRleEJkYjNZOQpiRE5OLys0QjVtOE9aT0ZLc3dVN3VaZjY5NmgxenNEc1FldGZuWHlOaTUyNTNwblZpcTY5aWV1TnJqdHpaWHRoODhyZUdaZ3pUNExkCjkxVjgvZ0htTHp4T2R3YnhKQmJ3MzY4Wi9wMEJ1dXJlV2JLWS8zNHRBT2hGZ0QyeldCVUFUOG5tTlFtd1J4dFhUeXpoS3E2YmJXWU4KZm85ZG85cVkyRDF2OEZrVGdQazR2aXVRaFN1bUZ1MHMzcVBGUFJwRHNvVzlFdkF1QU9SRi9Dd0ROQUp0Wk5PYWc0MXJFdGUzSjRSUQo0RlhYMmNRMVJpR1JFWGUrdVUzQmcvbm52dC9iWVpXL0daREJHck9IN2hmdkRGOUhvQjZOSVZ2QktpTm8xUXQvanJtSXpQdW9ibHB6CmNkUGFBK0lJd0NzQUs5cTRjSE5XR3crenlIaitxOVVMZVk3akYxcGtSWEpOQkxpekFQSmNkTEdycks4RlZ0bUQ5T1lBZkF1QXZTYlcKaW9GWFhlT2NYR2NHNEk4QWVmbjVXZjU5Ky84bXJISVVKalJpa1JkeXJtK0lzY01xZnlNZ0J5ejFsTGpXYzJDVkswQ2VBaUtKTWFvSwp6QXNCOFEyK1hnSnJGWGtlMWV1c1d1R1J0TklFbGhldHNRZHhJKzhZUnZqN3pjN2Z3SzJPT0l0MldPWHZIeU8zd0IwYmZXWHBtaWxoCmdkbUNZcVRYSWdCOEF3dnR3Y0NBUEJlQnJFQnNEa1FSSTQzM1c0RzVPV0N4MXdMWDRQK04za2ZFZGFBTHZRWmVrWDhHaDFWK0VMSXIKUzhXMGhKVnR4UHAxWW0xYjRBSkdzWE5rbVJtUUY3SEFLMERPQUJ5NTBKSDFpa0R1NzlOVTNIejlOYTNpT3BXTDNaMlZqODZ4SFZiNQpld081N2ZnK0syQXdXQmcrYnRzV2tYY2hEU3pKTEN5bWtRV0VidWROV0dpMHlrWTJqeEZDaTUxTFZOREJDbG1pd2hWVm1vbjNJeXJoCm5BQjhFUnZmQXFCNkY3L0I4enlzOGplMnlCVlFxMHFqQm90aFNXSmpENWIrODk4ZHdEeVRUYUVOV0dnRjVCNHc5QlhybXdFM0sxU3AKVnFCRnBaaU1lZmN4dG9tZlk4OWtPNWJDWm1TSFZYNE1JUGNBdkpobmpPSzViUEhNZ21SYW5YWDJ3STdTUENybnJKanJMczV2U3R6bQpTbzVicFlRcVJTclo4NmpreEEwMlZaV1o4QnVXQ1pKeEZWYjVBUEEzQlhLM3ZDaWpFVElsSzhHTVNqNmoyUFFrdnJZQzhCVFFhTWxoCmdXMW1aWXVzQ0VWOW5aV1BqbnBHSDYwdFZ4dFlKd1RjQW9CZkQvZjZNU3l5Y2huUkNrOEUvTm1DakZ4WkJlVFR6OFcwZlgzNitia24KSUlObUVrK1BkaEFwc0RMWEhSbnh4ZUlLczZ3dTJwSk4wS3hXL1JhMU9DcEN6VnRsN3dtdHprTmFBckx6QVBFM0EzSTNucitOWE9yTQpEYXlDMlZ2bUV3RDM1QUNOaTlVRDl3U2dSamN3SzhEQVFoTWp3UDc3LzY4RlFtM1pBV0oxcnl6SkVEQXdyNWEzU3JZa1ZGa0ppQ2RDCkdCN0hON2JJYXNHamU1V3hwMnFSVmdwT1BJalBQOS85WXZYdXVRZno3RUN0aUNwbWFUZGdOZ0srN2ZzWEIyWUdaR1dOc2FtaEFtS3oKdk9ta2sydnFaTVAxejQ5dHNoUFo5RmJpV3JlRHZmNW1RUDc3eGhkRTJhS2lobXExVWlVK2k4QjgvZ21ZSjN1ZkgvVlczSVBaeDlXcwpydGhiNFEya2ZwRjdpN3o5ekpXOGZCRUtjNnVyOTJRRXlHM25jMm9XZDRJMUVxNzQxeEtCK1RoK3ZVWHVnclVjWVZMWHhDcVk4V1lGCnhXVDd4YlA4QkhNRTRoWCtMcEprVVYyeHQ4TGJaNktMNll0TXJqOHRNN1BLZXkxeHhiV3VpQlVva1BZaTQ3MTlQVHNMemlyMlZ2TDMKaitNYnVkYUtkTm1Ua3NuS0U0MEFlUUVncjhhcmxEelExYzlNd2lwajNHOE94RmpFd3R6dmErQmVSd3g1VHpJRkdjbFZGU3lJN3ZVYQpnSGx5MXJpYnJtNlQ3dlhtNlIxUS9EVkFqblMxbU9VMEVrK1o1YkkwRnJqWks3alpVVlhUcWVqQ2pyRG9XZWxwcFRSVXhjWm1zZFJ0ClZXNjRvclNpUUZ5UkE4SU5MS3VscHdVNjk1NDQ4cDJPcjlxazdsR2ltY1d2ckt3eXl1T094c3Rza1MwT3dKbHVGZk1NRkRCWHl3c3IKTXQ2QUZhQ29mTFVDVVMrNnFYM2dITlh2Vmp5akRsNktxam52Vms5QlB2TFIzUzdWdmdMWUgybGp0QUlCaFN6d2FtL3p5UlhYVzkwbwpiKzJaMmtWRkdOQ0kxY1M2YjJWaEt4MURGYm1jNkQwS1h5ci9Oc0pFVnpmcGFvWFhCSnQwMUVEQ2N2SHRkd092NEkwK05aellZNUZICmxVSHdRYTJ3aTJjc0tyTSsyQTJWblF0YlhBaFNCdUtvK3N2bnFKdUlzemMyL0FiM0JOTnlrWFd0Rm54a0ZyY1ZYZXJzK2JMTkdnbXkKQmU3QktzaXVIbmdQandUY2lOUmxHK25kNVkvS1FBNnNzU3JTWUlUUjZFUHJoUTFsRWdBNi8zdzkvWHh0Ly9hcHBnbXM4bUs2V2Q2Zgp6eW9JczhuZXA4QzJyNWNrSGw0TDVPRkk3RHU2RUZtK1hzazErVTNLZTBWbXVwNjhDd0x0ZDdMRWxZNjBkOXpBUFFBOWFwR2p2dVBJCjhuV3lPKzNkZVpYY0RnUHZzM3Y5K1BuKzVBQ05ZRjRLTWFLS21SSElKM3VieDE0REs4UVcrSWpJZmNYcVJpTm1tbUR2c2JpRy9YdUcKOElhQjJXOTBTOEFIUExKRmptU1plN0I1M2NVNmw0Q2NXT09aQUdvR2tCaTRvYU1FU3dUZzJRSDRETUQ5QTk2ZkFjd3p1UCtWZ294SQpEV055cnVTVDFjc3JtZXpPaU1CL0ZoOUhyWTI0YWJETjhRbnUzZlk2d1VhSXo5eUl0N0lVTXhPUEJ1S3N5dzJyLzlZZDNNV25XT1JLCkxOb1NLMXpWa2JiQUNyUEZ0b0dYQWRsYlpPWXhSQ2todEY3NEFDWUFjMFZxZHJML0t6QmhHbUVSaVZoUkg2azBnS0JiSFcyUXp3TEkKcTl2RThkeisvcit0M254NWNCQXJEeWVUWWZaaDJ3cUc0OE1scTZkQkVHZVdrUUc1QzRaeVpFSmdCR0p2SVg0QWlQL2hRTHdCMllONApJZ1JXdDNnOFMrYkNlakFidWU1STFCNUpvVXpBTUpJNFVtN2VhcnlLTHZKMG5vaFZQaE9MZkFPUGJIWWczZ3BoMWlTNzhJanhzUko2ClpBS1BDeUYvUCt4aXAwQXVLR2VxeFRhQk94RjFGWm5sMVZ6ZUdtRTgvQXdnL29jRDhmWkNsNW9SWFpHSVgrVDZNem5aT2JnT3ZJZFgKNG5ZMmk3dTdNakJYeEF5VTlVZTMyZ1A1U2R6SDdSNWVIY2kzWitScnpGZkxCUTRlSGNTK05IZDczNTR6L28yNzZIOVhMWElUY1ZURgpyYTY2ZThxOVFuZHZGaUQrQTBEOEQ3RElIc2dUeE1XclN4SGRIQ2x6TTE2MGtXMUVqY1NLR1VGNEplU1F2OTZUWU43bkJNaE0yMXNwCmhLcVFCWUY4QmlCM0FQTGw1OCs5MnR0bUVTVm1HQTBlK001QXhudnM2K3N2N2w1a0crMmJBcEk5VnZtanJEVUQ4MFNBTXRLMHp6NkwKZ2RqSGJCN0UvNU1BK1VUT2o2bHBNcTFyZks4UVk1c0gwY0Jkbm9nRlhHQ1JNMENkM1hXb0pnK3pYSmNNMnp2OXViS3c1UW5PNFFRYgp0cThyM3hid00zR3JUWkI1bFNhUDd3aGk3SWpiUVB6Njg0WHJqVlVSdGsrMXlFVzNXcWxKS2padXRBeHpCTVQrOVQvZ1dqOGxRTTdBCjdGOE5RTWZpVGxRQ1JROEQ4OTQzOXpjYmhCQXFSc1Y0bndHWlhSdksvV0lIMkFrMmpXY0M0aE1KbjdEVDZ5SklybXkyMUhlTW03dEkKUDY3azJqY1EvMFZJMzJodzRHNEdlOFMxSGdIelJCWjAxUm9qaUtlQWVQa0RYditBZHdWa3ZMa0x1RVlxenZHdTBnWGNib3ovS3BNcQpaN0RHSHNpekE1VFBnelAyWGUzNkRNUXFYcDBJVTYxY2FwV0R4L3VrUHFzeVh2ZFIzR3AvanpjUXZ6Z1FUNG1IZEJlQnd0TWRRS3c2ClhjeTRna1NVSEdjTU5Vc3gvWURYSDhCTy80Q2Zld2JYK21TODlWQXRmTC9UZW5MblJxejZTaGFybXB5QlFGNEpxSkNOMzc1RzBnazMKSjM5T3VCbGR5Y1l4RWErSHVkUXEvNzZRei9DeDhScWsxRWJHNlh3WHk3eVNEZXppUUh3bVJPRE5FWnN5NDdBblRoNGx1NkloNXJQbAoweDZxMWxpbG1KNEprUDhRZ0kxZUorSTVNREFqaUdlWEIxeUVSVm9FMHo0SEZ2bE1yT1BKQVFxOUMzK3RHWkNWdTN1ejl4SklKMkdKCldXdzhCWjkxRmRaWVRlcUkyUGZ2NkZvem9ZbUxjNmZQUUFMNlozRCsrVDRUbzNkLzExcjBpRllBUEFVWEh2VWNNOGtZbFdaNkRzREwKV0YxY29LY0NtUDJpUkJEN2xJTEIveTBpZllTNVlYK3R5T1RPY00wWU5xaTh1RklwdWJqclFKY1hYWGx2alo4RlV6MEhuM1cxOXdJSwpVYTRhbWZkSkFMaDlFeEF6TjlsYjQ3TzlMVnYxSUdlaDBGMjhqOU9nTmE1TVlHd2k1MXFWanBrdHJ0cDZObDV1ZVJiNTFZbHNEcGdICm5RS1g5R0p2aTF0dXNLTmlEdlZtYjBVUHNNcnJaTzlGQUkwd3gyZElyU0VUL3d4QW5rVktiYnNHYncwdUFzaU1URlQxNll3c3ZFTGUKK0JZdzQzT1E3VkNMdTMwVEVHTjhmSFZBbmQzM3JpNW1abXR1K2lvZ1Y0VGpzMWxIWnJYQlkyYTZHQ0VEY2JiRE5XSjFNQmVLOGJLUApaeERFNXlSR1hOejFNS0lubXEzRXJQRWZRVXJ0TEpqNDFWbkhNL0ZRMEh2WU5zN25BcENWQ3orN2UzWUxPQVB2TVoyQ21QRzd4Y21zCkNHUmJFNzZCWkFQeEM3bDM4NzFCL0pFOGNrWlVSRUxucWp3dks5YXZXb2hzL2hDU09xZkFWVVFRUHdud1k2eTBBV1F5WGRIazc5dE0KOHJmS0duc2dQd1ZBWGlBZVl4dndBamxyRnNKa1RTWW9nY3NhSkV4d0g2Y0F5TitSN09waUEvT2xxdHNhVUtGZU5HTDNsN2pXMFhDdgpUTC9hRXBkU1dXTlZXZFFFV1JXVkl2b05nLzBkWDdXMHdLNnI0dEVyY2E5VkF3V3FhMHdDeEN5OWhrQ2V3VTNIamNoRXp0SnZPT2pPClA0UFZWOTdMRW5oQUU4bFR6NExIbUwrNVJlNGlGM3gxOTJNUm9kNklGZDVGZUoxMkVGMHFMeHBaWlBiZUNPbHpLb0pZdVpMZXhXUEYKRDR4d3dlb29yQTJQTEVmRTJxNXVoNDd5cURQRXpYZ1BXRXFOcGRNd3pwOWdnWjBoZjRrRTQ0bmtrUDNYaXExV21Ra3pQaGpnSkN6eQp2WURjdndETVdPSzYzZU5UQXQ1SVF1bExYT3RNVzNwRWdGeFpjOFpRVitLMGxkem83ZS9kaEdWV3NhbXZ4dXFteTA3WnpydzNUdDRzCkZGdndUNmI3Z2M5Sk9zaE1hMmpOeHBzOEVHQm5BamcyZEw2VG1GOTVRWE1SeU8xTzRPMmZBR1RVODQ1QW13MjR2OHM1ZnJTTnNUSmEKVlAwdHRNWjdMVEZUbzVpQTBGbE0xMEZQeG5XOEpnSGdDTVJZVE5JZGtIdXd1TS9HQzBJd2xtZU5Fd3hnWnJFUTRDU2VRZlppV1luVgphblhUV2JmY2JIR3Bab1ZOVnFDN3Q1V3UxSWFQVGxQNUVLaFB4Uk91Z0RsemlmQ2hzdnhseFJJempTak15YmJFSWtmZVJTOXNURXlJCmJ5Rmc3bTdYN29scmZUWStwd3F0WmRTVDdNOXRzbHlvUHB1cnBTclRERUlWQzdJRkk3SkYwNEFsaTJyNVA4dnlSWEkrYXBxbW1yTTkKT3ZQNnJxNTFCTzdJZGNiRmEwVnJyRnJtV0hGSmM0Q1pyTjREVzlXL3N1VEJyY1lGNkp2cDlqMk1pYStKRzU0QmJjK0NpTkpoTGNsSwpWTFRKemVwREJ6S1hsQ21vWnVOdTdWNWdJV3NQTytUdytTOFc5NEovdllwbXNLTm5PMmkwNnlKVCt5eGl3VWp4Y2dVZ0c4bGpacEk5CkZUWFAxZkpHZlFac0k0dWZ4WXhQeWVaakJldFZrVlN5d1UyNEpkWTJteGx0Y0g1S1JiUVh5QitWMm93cUI2c3ViVFVHWjhVZ3Z2UVYKSzl1aUVVSDlYb0RlcTJ0dGxnOE1VMzNML3UvTXdxV09WQ2hXc2d0NmQ5cTcxV3NBQ05zUjQyU0R5TlhQTmNFUmJDQyt3RUxBVFVodApxT3krajhaZ0l3cWRTczFpRlp6QktzS3E3ZnRlNHh1dDdNamtqa2lDZDJUTzlCNkwvUGZyRlY0WDkzNEJNRmNhaDc0RXlCRjF6dHhvCkJESkxlYWphWHA4ZlpUVzlOMkwxSnZzL0dkclZjakcva1ljWGFXQkZQOU1FaUM5d0Q5akV4bXd6R2oxdnRaQkhySEVXYXJCK1oxWVkKc3RqYjVvTFJhMUtmR1UyNi9BaVlHVGZpNjZ6L3RQODBUZndGb01iNjl1WE9Ic1BkcGpFcUt6RVJhK3pCSFZuakU4bnRzamE1MWFXSwp6TjVPWE13V2JCWVBWL3VvSzFiUXg4dXNWZkppdk9FZ2NzTXFhWTNzbkZ2QnhhNHNhaVozNDcwbFJ1TGg1QTFWOWFmdUo4c1dvT2lkCmttcmFrOWJxd2pQMFFQWmdmckgzalNxM1lIUDV6NFYvZ2RSUHh2NWhSUS9tTENkd2c4K20xUmtSeEg3M3d4M09ENGRiaWl5MUZaalIKU3NOSHhBTk14TDNzSWtTNEJlUkpkUUZta3c2cXFpd1pQOUtGZGZMbjcydTV6UUhXZ3BUVUpDeDRWZWpPYjRTUlovTlJNRWN0alAvKwozOWUvSEtBUnpJdFlvMS9DV2xmb2NqYkJIb0dNZWxSbnF4VjhZRyt3anoyd2dJT0p5bzI0aTVtRmk4Z243TFBGRkF4am1GVnNtYzFOCjNnUHNQYXh4WnBIeDNQMXo4Z29ZdUtuaGNQclozdWVrbzVUUEVxd0w1QndXY0duWFFmQkV2Y2lMKzd5L2ZnSVl3ZnhhY0srL0pFYnUKaWNWU3UvY01xU2JXeE03SUxkVlZkSEc3MzlYZUZsMXMxeE14MDlQZ1FvMklQdFlldWJYd25kMDFvMkFBTnRPUHBuRDJ4UFJXWklpcgpGVWs5OEM1dXNOR3VFUEpnM24rR2VEbHlzUldRUGRIMEl1TFRlMWhDMWYxMEJhdjg1MDhnL3h1czhqWEpwbnhhakJ4MUxxbkpFTjRpClkrckJEOE5tNnBDK2VpZ1NOZk1QeDBpT0dkMjNLRzFqTmw2UkZva2ZaS1daVVpuaVBkdmJvakV4YXFNYkRUOGlGNWM5bzNOd0h6SXgKdWk0K0V5VjJmSHo2UXBoamxZNGNzYzZNOFBJYmlyZk1mN3J6OEI0Q0JmR25DZFFuYmhwem1SSE1LNG1UVVRnZ1lxZ1J4Syt3MnpkMwpMYXM0bDByeGVpUFhZbFlmVmVNYkpUWWk3MmE4RUFTRjlWVHQ5R3h4L1c1bDNuSmxWRXcxSlJjdDVvVThMeDhuejZZVlNmeUVDcFdPCllrQkdFSHZ3L0Fuc2NXU1Y5N2pYcU5tRjRuc3ZndlRLNmh2dVo1SC8zaFdnQTZvWHdHemdQalpoQ1ZpQlBtc2pqT0lmZEt1YnZTOCsKeU1RUG9nV2JnUmo3ZHJGSjRteHZCZWZWU0pudDc2RDI5a2VhMFRNUTk4Q0xpbVl4VjlocTFEaTd3SDN4YnJZSHNiSlF5aUlyOEhpWAo5dDhrUnIxSGZOcVRlUDFDQUszSXJpOHQwYXdzREJNTFh3MWhZOFh5TFdBRFg0bGI3UW1MMmZMaFo2TmtUZ1hFZjBBY3VGblppK211CksyeVdZTHBja2VSdHRSNTVORWM1YXZIWHhDSnZ6MjZCWjlRQXhEZUw1MFkzNC9yaGk0aE4vd2J3UHgyZzBiVlZRTzQ3d2J3T2tHKzMKTDdYSUJZS0R2UmhRSjh0bGRDTVFLeFlTM2VvZU1NbnNzN09tamd6RVB3U1o4eFFzR0NPTUxUYnplMkg5YUo1emxhVGJNOVVqRzZTZQpFVjBzczJDUWtqeWJGc3VQaHY1MThYbmVJbStNOFQ4SmMzd040dVNQa2w2cVBnQlRZdEsxLzh4cGpIMkFWV1dMbEhYb01BRDNJSVZ4CkVReGt0L2U5cjlWTm8xS0syQUpMakp2SlRBQ3U4cjlNdThvTENQaXhOempxNWhRdzNoV1NNdE5Nc3lJUm1QVmlYd21RWjN2ZmxiWVUKY3J0OUlDWi9nVnp1UHgxenpGamp2WVJYQnVab0VtTlc1UE1sRmpuYjRaVVNSTlNwNDNPbmJFZG5aVzVyd3BxcmphTXFncDVaWTJ6VQpPRHNRc3pqSWpJOUtZWDhiTmJwK2lKaVpYVU1GdktQbG1TTmtsNXBxWVk3RVl1V1RheUhObHJIV3IwQXcvZWtzOUYvT3ZiNkpaN01uCkk2QTJOVFZSUW5aQWZjUWFoMEIyaEZjbkJReFZpL3dVdUlRZFhNOG8xWVFsYnF5RmJhVGRMM01mbTdnV1hBQ3o4VHBwWldtYUtJancKSXZ4c2VzWXp1WmRUVWpoaEgzQ3BSemlUcUVydDVvQzh5U1pGWkU4WEhtRVhjZmxOckJuUFl2OEZjWEpra2ZmV1ZFUTE0S3l3NTQxYgovVkVRZjFiNkNTMk5tazJFblNBcXhtSmRRZjZ6ck1oV0swQkhJUGJYd3NhZWVMZjRLbUtnWHN4SDQ2aVdINE54Y3JYR2VwVHNxcnJXCnlyWDB6MHR0Y0gzQSttVWxtcStrUU9UbGprQTJpd3VrV0R2bGF2WG1sVTkzcmZkWVpHK1ZQZWdXK0p0VmdndmxjT3dEc2JGYXpLaWQKdFZrU05RMEN6eStMKzFDVmcwMmJqS1lnTWhJeEVqdFUxcnFpakdva3h4NVpJSFFsL2ZQSzdrbWxwZFJNTjB4Y0U4YjRja2NnVy9FZQpweFY2OTdER2V5d3llM2pSVE9BVHNjaXJBREY3Q0F3azZHNk5EcGVyTXJRSVpwWUhQOXY3VHB0S1dpRml4ckZRUnVraVQxWXZDREViCnI3TTJHNisxVmpYanJVaTBXVEV1Ny9hK1pYR0I4T3RxZktEYzlRNnBuejRJN0hmdjl3THdhQjQ1bWhwUlZVdWN5TU5TeWZSTFlPbXkKbEZGa2xhZkU0a1J4TW1PY3p4YjN2cHJWeWlKWjJhZlM2Wm9KNnoreTJDSUJpR3E4M0lOOGFxWExLRHFIaWpGUk9XekdFck92N3kyMwowNHVndHM4QThWN1dXajFJQ3hhbXI0WDJydFlxM0NMVmx4dTUxUkZ3bzlnNHF1NVM3dnRXYm5peVdJc3BBcE1aYjN1Y3hiMjd4MWlWClZzaTM3eWsyeVpRNUtoSlJsWFNYQW5IMFdpdXM4UjJQSGhISTlrbEhDR1JTcW1sVzcydGxtdEVyU1R2ZExOWTlZbW9UbVpzNjRsSm4KQzM0aTMxdnRiVk44TDZaUUtwNEVhN3lQTnFNK0NHS1V3YTFzZGhYaVNSRTlFWUJIUGpQYU9KWUEyT3djOS9RbER4K2ZDZHlQeE1obQpkZUg1U09VUnJUSG1ITE1FdWhVWFIyVUllOVE0MFlSMXhzOGFrZE5SUURianNyTWorZTlXMkN5MmU3QWFyM2FyNkVwbmhGZDFpUDBvClMxNEY4NXE0K2U4MjI2OEUzSGNCOGtqcVlnclNKQ3dYeUZRZE1FVTFHaGRuT2VTcWE4cjBtYWVFd2MvYzZzek5aT1d0SStjYmJhNCsKUktqbTJxTjUxNVgwU2t2Q0hVdWVTNWFuWlZwZGFZbnE3d0RpZXdDNTZpNDE0cEt4YWlBVzExVGMxTWcxbmF3dUt0Q1RFQ0pMTFZROApGeE9NY0lWNFVwNURMOFRBcU5qU0xKOVJiRllyMGMwc2NyWmhUUWxUSG4xbVZDbDI5MUxJM3dYSW1SUnU1REpWUzltcVJmU1ZvZXNWCmkxeE50VVh2VlNIMEZzU3JLMWpkUHBpZXlWSmJYa3JIMTRoblE4Y3E5eWl5Z05uR01qb2pTY1c4dStMZ3Z6bWczOTYxTGt4bG5DeWYKVk5BS2JHY21LenRDRmlsclhGMmtWYzNrcWt0WlphdDlkNURaKzJZUUkvRTdpdEszSkhPQUVyM1REakJIQUY2dDN0NjZwNUtzc241RwpwSHphZjVaNS8rWGpXeit0MXJyZ1FpdkJ1Vkd3VkhTcEtvWCtlK0xqaUZDSml0K1hIV21uTEgvTVFJZUFybHBrTml4dEUrOW5LaDJ6CmlKZXJ6Njdxd2xiRHIxWjhQZ3JNYXQxOHR5SHFYUm5OVVdCWEI1MW5NVmMyajZpYXVzcklwcjFNZFphQzZxWmJLaVBKMnRWcTljUHEKSG03M0RndEFWdkpzcG9CVnQrRHZiMytyMi9zQmVyNENyekxhTkJzUE14b2pqNFk5SDVINHhaYlhidmxFaTA4RnIvRVVZdmZBcmdKNgp6M3praVRDZW1Sek55QTFYOFhWRlNIMVBWWmR5R2F0TjRwWDZhZ1V5WDJPTlpaazkyY3lxNlQrMDdpdHNEbGhCcG9hMjlZQS9pS1k1CktObWswVmhjeGN5WjFXZFRMWnA5SGZtMXA1enpEYUFyWUQ0VjR1TVdXSkpzeENjRENYTURLODBPSStDdFZIV3BCYVA2WFN2TkhGbU0KcVBxY3ZacW9taDdaUkd5c1ltVVA0Z3pJODRCRnJtcUM5WUdOZWcrZ0srSFZkbzl2YnEyM1g4Umk3Mm13TUIvRFI0QStGUzJ4V1R5bwptc1hIbm1XTVJvczJzakg0ejFrVElJK3kxVkZEZmlidTV0L1p4SXNxa0UvR0I5aWhhQUx6SkdiVEZXN2Q5T0M4WmxvSU1OcU1NeW5jCnJQUnhkS2IyeUpoZTVlSDREZExMTWVIUStWOWhrYk1VM3E1MngycU1IREdoeksxR0MyZmlJV2NUN0JkN0s0MWF6VWxtVlYyV0xFN2YKVFJOcEpudDFSai9yYUNXdTVXVHhZUGMvN0cxN1p5TWIyaVRTY0t6VzNjL0RZa0JXejNTRTQ2Z010ck1CUzR3ZzdRVkNEeHQwdkhlRApFc1UzKzZMeXpDS0lWOHNIcGIreHpNb3FuM2E0MVJId0VNUitZVEpabDBpd2ZZSDRidjBnZ0xOQ2tHaUtnZGVDOHNxTWZvS0FFaDQzCllvMjlwdlVQQitJVk5yZ1RZYkpSdkwwRk1hSlBaelhDZ0xObWphalgyYXplOFJSVmQ0MjBTMmF4cjdlK3ovWldvdGlYb3A1L0FaQ3QKd0Myd0NaTFl4NTJDK2JURHJaNERFS01DU0lNVHVnbXJ3NEI4czdkTkNSWFhXaEVxVVdHK2FsajNzVEVxTkc2QVpuTjlWbUtSbTdERwpHNGpSL2R0KzdtcDhDb09aRnBqSGUydEpPcWJDUy9TaU5hN2tjRWRtTUdlNWNhWXg3dStuRjRDSXh0UitoV1dPQkF2eGZVc1RHZ1B6CjNoaTVZbzFSbEg2MTkzT0xjZGN4NC8zTGZ2SkFORlV4SXJhcUlHWTNHaHZWL1JnUVZHZjhFMXpzSlNDclVQK0w2V0w3NzE4YythV0UKL0NLd0tIZGJrWTJqbFcrWk5WYlB6U3dlMWw1Wmh6TzQwQnVBL2VBQ3IyNmFLWVAwTHdZeGxpYjdURWltdzBhWjdGUGlWbWVrQWpLZApTQml0eE5WbVlFWVFuKzE5RC9KaWZLcmhOSkJ5cXJMV2JLNFFTcTNpa0M3bVhsdXdBSDhRRUo5aDRWVWxZODN5UW93dTJPNHNYczIwCndDTENpNlZXS2cwckxXSGlVVWI0QXZlK3dZWjRzVSthOEREZ1ZqUCtCVlZ4R01mVXlTWmNkcTJ6SXBDSk1OWCtoTDFyRTQwT1phV0MKWjVHZk5VR1MzYU82aTVFMU4rTkR3djRFTUdjS2pRMjRnRE13MUUwc3lzcWc4MHFxcHFwV01yb29lMExVc0VXNHR4QklxWTVlWVVQcwp3ZjJNMXROWGdaaXRxODNqbXkwdVo0N0l2N0pySGFXZDJMUUljNjYxcXNuRmNhUElQTEpKRFFqa2x1U1BLNEp5eWlKbnVzbi9KdTcxClRhU1FtTmZSaXlCVzhiRWFCQjZ4eUFhdWVWYlpsQkZkV1JySzdrQXNSZm4zWjJJVXZNNjRGNlgvS3FJcjByeG14dUZNUUl6MzhSMzUKaU83MXFYQURJekFycmVxMVNJSXc5dnBzdlBUUkV3Qk0vbWFQOUMyeldGRkJpSStYdllYMjdQV1NBUG5KV1NvY00zTXJlQ01aSzVvMQpkdmpZZUMyeXhoV0NLNHVaOStSSG0yRDkyWWJoNy9FelpCTnVZb094THdBMGM2bTNkYlNwb3lLL2hQWDkrS3hpMTVxa25XeWc2QUozCmZxVFdWWkdBRWF1OE9FQ3Y1UGNxSU02NmJUSlNBZ2tKbkh6Qmhtc3Jpenk1RkFoYTRudU1GTWxTRzR4NHdrbVdyVUNpMlNDWXpmSVcKeDZybU5zb1RyeUw3Y2JaWWdiVi9JWWpWS0tRWHNNYmVDTjVjdHVJbTBvSHZ3SHhLMGs1VlBTd3pMYXpIRkRCVkJkRnNjUUgrQk5ZcwpLa3hoTFpiVjFzV0lYWXgwa3lNZyt3cXJrOFZxS0IrZERMZ0dsaDN2dFlraWpQWUJhK3l6RnBQbC9jSVJvSlU4TWJ1ZXpScGZMQjhTCjl5dmM2czBhYjNybEU2Um1jVzJWRzBvcXJuV2xGaHBKRUd3NFlIRU1BZyt0TXB0ZWo3RmwxSUszcDQweG1tbkVScUdnMnFkeXJTZTQKOXNYcTByRjdXVkcwOGxnSTB1Mjl6RzlQckhJdmJod0xjQ1hWRVNxWmlBUTdiKzl5YndNRG5zVkd0bjZTSmM1bVZlR1k0Q2QzRFN1NAoyemlJZ0kwbjNzMWFaNklCZU9Kc2thLzJkb0tpTC81Z0R5V0s2N0FpTENzWmpZaXV5a0F1QldnRm1wV1FVYTJRb29teUJpeTJid0pZClRNU1FBUm1iS2FMU3lGRnI3QzF5SkZXcnlqclZtcHlFMisxVFVyaUJxYzN5czFsclZtRGszV2tmTTc4RUlFNXorNk5rbHlxd3dJSUsKMXZxM2dsdU03dDRNdSs1SkZGVXN3RTZlTEIvam11a25Sek43b2dXWUtUZDYwRlFzNzZoZWRhWFk0Q2J5OXFxbXU0dE5vdUppWTVtaApPWkx5SmphOVNEQ3ZKVUQyNTc0NGZrWFZMSDlsZlRYV1RseGRtbWtEOFFWSXIxMGdmZ1BrUU80a0F6UHVRSmp3dmdDUW0zT2QxYVl4Cmt4MFRtVmJzNDgzaTVMMGFWQlcxeHBMc3FvMlBiYWt5N3RGZ016L0IwdXh0ODRTLzM5dnZUNWEzSzFZOEZ1OEZYTzE5QlJQYmFERGwKRW9GWmlTaFV5TFhQQnJFUkQ4bFBXOW5jYkRZdWR5cHdPaVdMbkxXTU5hdEwzSHFMdklDTHFWcjFaZ0J6QzREOEJHQStXYjFIZWpTMQp3aGo0YnJub1hGVUJkQVRFUFdEYTFiMWZ3WTFHTDJkT3JrRk5lb2pBM04zQ3ZacWV4M1J6aTMyQjU4V2VIWDZ2V3l4Ui9KVjExV3lECm5kMTUzZ1NBUHpSSlpMU05NVXZkUkFPdkZaQ2orSHNtS1NlL0lIRlNZYVowVVIxRG11VkhxenQvNXVWVU5zbHEzbmdKV0hZRWNnY1EKSzJ0b1FVM0FVaUFFZlhYWDJlSUI5bGQ3UDIzU2tqeDNJM0YvNUFWOWRiZVREekZXNS81SDdiKzdqdE1PRUxlQXJZN2l0RnRna1NzZApTMHkyNW14ODdPaGN0TVRSUXMxaTREMnBvb3BBUXViMW1MMFZhMWlEelJNTElwaG0xK3grZjdiM2ZlU1ZFUzAzOGZuZHVlc28wUEFLCmhSRU14RFBrdXlQbU5oSmFzRjlra1EwSTNqM2lmeC9XN0JyUmZyWml5Z2JCb3hyYkZWUGU0ZmY4WVBDejFZYUJkNGdGc3hTSytucHYKeFZMVStWTWRMajVCcWsrNTFMNWlyRHR3SU51N2lQeXZGWmo3VzdDSnJPN3p0bEJvcTRoN05qM0UzY0NhVjZXYXZocXdld0UrSWd0ZAo4aXBPZytDTllyUnV0Y2w0UnNnV1ZxbTFBcE9OMWhpQi9FUmNhelp2Q2wxSGxrNkswa3BaL25ka3lrUzFGdHcvOEViaTRxdkZNNmJSCkcvTHN0WTlOYnlTSHZJcjhlWlJQOTNPSUZ3ZElYeVBOUU13NjZFNVdreCt5YndMa0hteUFxNDFOalN5VGRLZWQxcGd0cml5bnVFQUsKU3JuVlRGdFp1ZG5vV3A5TmQyU3R4cFVVMThLaVpPenE2RlMvanhDSUs0Q2lpZFRHaGJpdHlFL014anVLc1BtbEFaRFJ5clBKbVZkQwpzdmtTVUM4RWdBUGNGWWlaaDlYcyt4NE15Qm5aRjgxdUxrMHlHUkhmRzJGNWxSVmJqSmZYNFlKQ3FWMHozbjMxRkxobmplUzJKOEoyCitxcWJpMWlvRVppcjhxd1ZVRWNGQlRkNEp1emN0eGpVaXgxNGl6d1ZnR3hnK1RjZ3Y4Sm1jWUhONGtJOEFsU0pZWk10RklpdlpIT2UKYk44UXZxOEdNY3NrSUQvQXludlJDeXdiaWoxalZUdXh4bVo1dFUvV2ljUDZuR2RDZ0tGT2s5L2haNkQ2R1loUjBNK0Q0U1c0NGRjRQp6SHRjNm1pelJCQTNBYkNiNlNhT1Y4anBUcEREVjhTbEYrMWpJb1F2c0dHOG1wWUtObkR0bzFwOWI3MmVBY2pLS2o4S2tGSEVVYTB4Ck5kZDVLRWJPRXR5cXVkd0tLUmxWbGxnUno4TkpDU2NBczNMUnZIeEtkOHdzYmo1K29mNXBYQ2t6YTNMb2d5RE9wbFd1c0FsMUlLQlkKdnpUYmhHNUFZSjNzZmNrbVdrUDBXRGJYZld2Yi9GUGNwMWRpWlRBMTFBSVErMDBqOHJTK3U0c2QxVm4vQ1M5Y1l5VlJpVlRxcDhBQQpSaGE1TXAxdkpVQ093T3hkTVRNdStZTE5GM2dEdTF1Z3pPMitpaHY5bDczWHNWWldPWE90c3huSUpraXMyVzFLR0E2Z1cvMHF6aGMxCndWaVR2ZjlNOUZpMnYrVUZGZjZkM0tjTHVQU3I2U1lNZEVGZkJaRG5JcEIvNVJnWWRWMjRHZjVMM0x0cklZVGI1VnBIdzdOVXZyRlMKbzZzYU15TDliRmJXcWRvcC9jSy9HVmY2Vks2UHY5SGJ6WDYxOTlwUWtVVWVtWGRrNHB3MmIyS0JkSm1TaTNrRnk0ZzZWaHZUZnlWcwpxZStEWmUxMXVBai81Y0Q4bDd0SHI0SXRWM3BaN0JtOEJCYTUwZ2p6SzkxcU05NTdnRjZmVjJUMVlGWVdPV1N1VCtSa21uQ2xWWmtlCnM4Zzl5RFhqLzIyRXlOWDBnRGd2T0xCWTNQUytRa3g1STR4c0YzSG14ZDdyY25rTjYyakhaQmFob25lbU5xR0x2UldtYndMRWx3REUKakxIZU9BWE1BVjhkYUJESUhtQWV5QjdNYUZVdXNJbk1wbHRGY2FMSFh4QWpxeUZ6M3kxR05zdmxsVjloamJIN0YvV285NDlZNUtpdQplQTFBRzFsMkF3dHJwclc0SWoydmxTd0tjd0NZZ3BRT2EvQjRFUzRraXRGbkdsQ1poNkY2dWoyd0REWWx4ckFqZzh5SUV5TkF2cEpOCjRjbWRXd2YrZ0MxQXRNb3Z3aHN3ZTl2VW9DU1Z0cy80RWRRR1BFSWFLa3BCdlFaOEE5TVlLL0V3cHdFUXF6SkdaY0d6M1FyajVNWGUKNnZveU1YSVVzci9aV3pGN0JMRVNORk4xeWQ0cU1GSUNVd1ZLUmdkamVSWW1uRVRheDhlcGkvc2Viaml2SWlWMEplZG9KSS9MaWtnMgo2NGV4dUZwOC95WkF4bzNFZTE2c3FBYmR6aC9HYStnenNxdDlJd0N6T05rL1A1OG0vQ3ZZQktscXpNaWtpYWo3UmJuWEkvcFNKcXl5CmNySFpqQittRUdJa2ZkSkpMS2pVUGk3R0ZUT3pHQ1lDc1UrWFpVejdDZ1NkdjZZcjdPZ014QmV4bzN2R09nUHk3Rng2TmYvcVR3QjEKUk5pdzlrbldjcmt4MVMvdUhFK0U2UHJ1cm5Ya1h0L2dPVjZDN0FoVE5oa2l1MWljckJReDBTSmJzU0FDQWI4NnE5eWNPMWtkSE9kWgoxamtndEZpSklWdlFtSk5sTnhyZEhveUxHWWlmZ3JqUElMNWZCT0hFR2cvUUVqTjVKYS9hK1VRMk1yVElxNzFYc0hnQklMODRsL0JGCmJDUllINi82cHk5d0RpbzJucjQ1aUZWSXlqYXVhN0FSTXhYVjNMWCsyMXlEdUlCaXE3dHh6ZDNNR2tlU05TYUtGQ2FyVDFqMGVXSk0KUTZHeWYvWlNNU2hUWmNRRk5ZbGM5eE41ZVUxam53cGJBVXdYc251L0pBVXJDd0hSeVZrK2xDcDZodk5obi8xWDRBNWVnbzNFU0syQgowbnBXM3RhajVKQWpNT000SWl3SmpqVE5wVnRkeVNObjhYRlA0bDUxMDV1d3lnYmtUR1dndWY5OWIxRk0wUDlYMDZXWXJIT0lsV29xCmVWOG1vdTVIcDdKbUFTeSt1SWhpREc4Vlh3UkRyV0ozRktoajhlcU5iQ3czWVpIeEhMQytPcFBoeGFiN3hYanBaaVQyK0NoQXJuSTAKV1hubTdqeHl0ZG0rQmU1MXBUbWNYVEJMNFRTTGhmK3dXNFlCbWJreWxTWUFWZEZWQWJHZkZMaTludTF0RDY1M29SZFJxUEppNzB2NwpYZ1dJMFJwN1Y1OVpTbitmcWtCbW41OFZNcWdVNEpZbnZ4a2ZSL1JkYzhkN2lDOVVWNG02bjk3Y1EyV05SMkprcFYrMTJOdnhuVmxsCmt5Vmc5a0U5NXBjajF6eXlLdWkrcVphL3FGRWlzblFzSmo0VlFNeHl0aWduekVEOEVvQllXVUx2N3ErbVZUSlg0VnBuc2JuNmZFYWEKNG5naEQ5YkY5SmhjdFg3YU53Y3hNMVNLYjJLZGRaYUJ1TXBhUjVJeWs3MmYzWnBOcWNlZDJjVE9GUlZZbU5oc25pRk9SaFdOU09uaQpGcnh3Z1diRTFoTzQxRC9nL1ltQVdKV012cHF1YVVaaWlVMVRhTWFWTTVrcVN4Y1dXWGtzckkrN29scUpnUFlOSVpQVnhRY2Z4U0tyCmNIVk4vbTIyUnlGRUVGNlJEQTd1bE4xcTljWXFWa2F0cUFhNTFGWmtCaytFOUZxVG14STFlWXlrbUo1RVhGeXh4c3dTUjUxR0RFU3MKREpZMUxjd0F4dG5lanlTSk5qWW14TkF0cnoxWEZ0b0EwQmFBK0JIaVkzVzl5bERLcVJ1Wk5SNkprUm1JWjVLbjdJRlZab0RPNUZuVwo0ZzZNNTZoVUo5QWFSWVFLMjN5bW5TQit0dmNsaHd6RXJKUHB4ZkpPck1pZGJRVEVUS0hpQnRlWEtiNUVreVBDUmZqVFdGU21RMmJoCjJDTlo1QXpZNzk0ckFLNjQxczEwYmV4RUxISVhWcmt5TlVGZDZGcThZY3FhSXBpeGMyb3RMRTUyWGlyRjlKeXcxR2ZoS2JDKzRzd1MKVi91aTBkcXRGb3NNTnNFdVp4NUxyMXFTN2Y4QjBHdzQyU081MG51QUxmdU1SMEJjc2NqTllwSDJ5ZmdFQU1WV1Z1TGtQV0NPVW1aZQp3TTJNRDR2clFmb01aWGlWd0lFQ3NOS2xZaVdLckFqbEpjblRSbW1LSm5pT05RR2p1bytWVWFubGhlaC9obGhwTXo1UTduYzRldVdlCmZBaklFQ2VyR0pUbGNWWG5sQ1V4VGtOM2dqelVOZG1Wc3dWNEFoQmFRcVo1VjFzTlpUc0ZMclV2K2pqWld3RzVibHFtNTlYaWdvOXIKd1JKSEE5QkhMSVJLb2FRNXpUMkxFWDlIRkNmOWRzZGU0STVhNUF6TTNzTE94a3M3SS9lYVd1UUV6TGNDYWFXT1dZQ1psWU51QUdSQQpuZ21RRWNCS1EyeE5RTHhYWnFnSGFVUkxXT1I3TTdQZlpvSC90eHdqYll4WU5zaUtNdGpRODEyTHAyQ1piZWNpOHQxSXFzdEtTYTR3CklEOFpGOHIzcmpTQ21EVm9zQnh0TlUvN0t4YjlWOHhTT282UEFEbElRM2tRYi9HZEIwZ25STW51aFphQXVjSG5WOGlRRnJEV2FHVlYKSlJkanE4K21CZkxOdU1hV0V2dGpaWmNxVHp4Nlh5TkZ6eEV5cVgreXBUK09PMXZrbm9BWlk5eUpXS0RNTXJjcytFOHM4NUlzWE9iUwpveXl1SjUvT2dzbEd4bHExVkdJM2xpSzFLaUJlVERlWTkrUWVLcW5kckorWGhUeS8ydm9meDE0Z0V3Q3hOSlIvMERPSnkvYk9TS3FBCnVjTTVaSlpHVlRPaCs2dWFRNHl3MXF6QUg4OVBnVGdqdFJTSVRUQzVXYXFtSW83ZkNwdjVZWUVmTkVZMnNDN0tUZXRpTWQ5anhJbzYKbDhsNDBValVOZVhCdC8zOHliU3VGN04wYXVBY2JuU3MwS1BTaWhoVmFxbWlDYk5hL3I0QzRPcGNxMzZRVkE4QVpHSUpjYkZHcEppWgpWdDdVQ1AzZnowc1dneEkrWUkwY0RMeWJHK3pycG1jZ3A2WmluSTF1S01heFNpenZFc1RDVE40bEswL3N3ZmMrT2tROTI0d1A0RDZZClJVYlhhaFVXWVJMV00yTmEvejhnZ0dpenhHV3NqSzFoTmNLczloaW5WVVJ4Skg0K0cxVEhXaWdyUWdCV0JIRG1BbWRhMnRIYzZMc1gKOWgvSDl3SnlFNEEyNGZwbFJFa1RmOXVTQlYwWmdLYUdjNk1FVFNQa1ZVV3hFZm1DTGx4czFuVEFHUEY3TU1uWkpJL3EwSHBWMGRjUAo4dXZ4Z1p5NXRxb3ZPYXM4cWxxZWlJVm03NVhyVUlVZ3B3VEliQ0s5VXUxVW13aUx2ZG5meWp3U2RvK3pkbExWRG1vRkVLdXBFY2Z4CklFQnVSVXZkQklqeGV4TWhjaXhoWVVmSXJFanZxUkVRTVFuYkpzS0ZYdkErMWlEZTllZUwxbk1kQUFkcldzZDdublYxR1d3Z3JQTnAKdFhqSSszRThtRVVlYVRPcmZDOWFDSzBJNG1idnAxTDQ0ZzZXNTUwQ3k4MDZjbG9oZHN6YUNiMGJ2OXI3Um95UmlxMHVOaFZtTVZ2aQpWcU9zc1JySUhkWUZISXoxTndXeUk1MnFPY2lxMkY2VktNaytVNDFoOFVEMkxZUnFzcDhaWjcrVjZBR1RPTTFFNTVUY2pqLzNhQ2hjCkQ3d0NMS0d0dU5mczd5eEExR1V0bm9jMWZtRFhtc1dsRmMzaGFPcDZIN1RDMlV4bHRNaCtoaklyb1dTRDN4WmhzWEVjeUdwYUZvaUIKdUpQNGZMYXhTZldNUldadXNvbDd5RFlFWnBGdmlVVStqdThPWkdLTksyQ3F6T1dKck15SUt6MGxzVEVETXdJWlFleEp1NHJialdEMgplc1dzMFlLMVF5NEZWamdEOFBiMVpPL2xjOHp5WFBFS1hzZGlNY3YrSFpvMmp1TU9GbGxORmZ5SS9uQlVEMXdSclo5TnoxZkNlTm1ECmRJRUZuT1ZXbVdWY2hhdk54QWhZV2tqSjVhZ3hQWjI0MFFqaXJHU1RFWEk0TEU2bHlzcHFJTWZ4L1lBY2dhcWlmV1hKNG9yaThha0kKWkFWb1pMRWJpUWtuWVgwcjljV3F3a3lKRXVBOVZZb2RxNGlCMTRITnNoZEE3SnRnVm1HUjE4TzFmbndndDhRcVQ4YW5BMFJEdHlMZwpxbmljeGVSc0k1bUQ3NW05SCt4bWhNR3R0R0l5UlZBTG1HeThmLzUzVi9nYVhmaUpBRmdSWDZxbVhXMDRHRnVyQWhaR3hoMkFmaEFnClYwREdyS0t5emxQaVBtZXhzWXFUVzJFVDhTTStJMnVhTWJTb3JLbXNveEltajlKVG5ieWIxVWJjcnNIbW8zNlhuYWVTdTEwUHQvcjMKaUpFckxQWXNBTjFNandEWjg1b3NyeDltdVZJajFuWVJMdkZpZVNWV2RGMldXRTRGN2pYWldKYmdlMm9VSndKNDB3ekgrNkppNUlQaworbzJCYkFITEhNWFBVd0dNTm1DeHpYUisxQkpMRnVrMkw4SnlaUXo2S0tBVnNDTVFMK1JyTlZOM2dqaDdBWklNeFJVVzAvbnhvVkVtCngvRjlnS3owcXMzeVpvZ3FLVFlWUUdzRjBtd3R1SklSZ0N1cGxrWlk1NmtBNW93RmowYlhkZ0ltdHVHd2FRL050QW9wRzFRZkZZTWMKMXZqQkxYSTAvSndCWnJLNlVIMjFGdG9JRUF3QVhJa2hGeEVIM29SRjdrV0xQQmMzS0JPQTdvUHVkZVJpcTNqZXlIMVRVeTFYRVJ2YgpZWTBmMjdXT1NnSlJXUk5GK3JBSm43bTlrWTV4dndNQUZtRnRibFp2RUlpNGdVcjQwSXIzVmpWZXJJWFltSkZjVEVtRnBkeDZzbEVjCjF2alJnRXlVTk0xaWFWd2JpQW14TUFMTEZpMEFkZ1c4blN6RUpZZ3JLelhGWm53U1kxYXVXZ0d5MnB6V3dqVjJFaGZqcHNOVVc5VC8KZDh0N2tBOXIvS0F4c29tNHlvQThNYXVuU1h4ZWRLOExHcEZEUzRFZ1drMFBtWTRtQzJZRkt4bUJsM2s5RWFDalBMZnErY2JQNzViWApYVXVKcGdQRUR3YmtRSXFXdVdvS3ZGR0ZGVm93dE9wWkhyUkNDaWxRVjEzVUxyZ0NnMURDTEUrRFJXRHVSY1k5Sy82SXpuZmR3YVpuClkxS1A0OEZpWlA4ZzE0SkxpQ05ZTWJjOEV4ZlVkaXl3ZFRDT3JDaGZWSUhSQ0d0ZVlkMHpBaS9xZGpLTFMwZVYzblZQdklObzQ3REQKcGY3ZVI2bWhBVHFockJBYlZrc205NUpCNndDZ0szRmwxaXM5b2lOV2VjZmY2MG5NWEhsWDduL2xmQ3JEdUE4UVB6cVFFekJIdWxsVApnYzJkaktlYk1vS3JGNEJaNlNqcUErQ3Qzc3VLQlI3eGdLcGZaK2RXbGRWOWR3OE9FUDhtUUFZd205VWJIQ3FsakJWR041TnA3Y1h2CldSVzhsY1VycEh2YlIrOTF3VkpiZHE3azNQWjRCQWVJZnpjZ0N6QkhvSzdvS1ZmWlhMUHhnZHcyNmpaL2RORW1tdHlWZTEvKy9PcTUKQnVmVVJqZUg0L2hOZ0Z3QWRBWFlGUklvS3dLcGdyVGtrbjdtb2gwQXQzMG1vS3JuY1FENHZ3aklCZmN0QTNjMWh1dzdTYUEwbGp3Vwo3SEVjUUI2THg2b1N1bGxOOVFoUUQrQWV4d0hrVDNEaDJwMCsrME1FMEhFY3h3SGt6NDBQdjR6OE9ZN2pPSUQ4dGVBK0FIc2N4M0VjCngzRWN4M0VjeDNFY0QzTDhQd0VHQU1kNEF4N3oxRjZMQUFBQUFFbEZUa1N1UW1DQyIgdHJhbnNmb3JtPSJtYXRyaXgoMSAwIDAgMSA2MS41IDM3Ny41KSI+DQoJPC9pbWFnZT4NCgk8Zz4NCgkJPGc+DQoJCQk8cGF0aCBmaWxsPSIjMzMzMDkyIiBkPSJNMTk5LjcwMjE1LDM5My4wMDc4MWM1LjE2OTQzLDcuNjcyODUsNi44NTI1NCwxNy40NDE0MSw1LjY5MDkyLDI4LjE1OTE4aC0xMi41NjAwNmwtNC4yNTkyOCw0Mi43OTY4OA0KCQkJCWMtMC40MDYyNSwwLjYyMDEyLTAuODIwMzEsMS4yMzczLTEuMjM4NzcsMS44NTQ0OWMtMS4wMjczNC0yLjE4MDY2LTIuMDkxOC00LjI1MjkzLTMuMTY3OTctNi4yMTM4N2w0LTM4LjI3MTQ4bC0yMC41LTAuMTY2OTkNCgkJCQlsLTEuMTkzODUsMTIuODE0NDVjLTUuNjQ3OTUtNi43NDYwOS0xNi40MDMzMi0xOC4wMDY4NC0yOS4yNjUxNC0yNi43NTU4NmMzMy40NjUzMy0yMC41Nzk1OSw1NC41NDEwMi00LjAwODc5LDU0LjU0MTAyLTQuMDA4NzkNCgkJCQlzLTIwLjg0NzY2LTIwLjExNTIzLTU3LjA3NDIyLDIuMzM0OTZjLTYuMDgxMDUtMy44ODg2Ny0xMi41Njk4Mi03LjE0MTYtMTkuMTc0OC05LjA1MDc4Yy0yMC43NS02LTMzLDMuNS0zMywzLjUNCgkJCQljMTMuNDI4MjItNi44MTAwNiwzMS41NDY4OC0zLjA2MjUsNDkuMTE3NjgsNy41MjkzYy03LjQzMTY0LDQuOTgzNC0xNS40NzA3LDExLjczNDM4LTI0LjA4MTU0LDIwLjc4MzINCgkJCQljLTkuMzczNTQsOS44NDk2MS0xNi4wODQ5NiwxOC44MDM3MS0yMC43OTU5LDI2Ljg3ODkxQzc0Ljc0OTUxLDQyNC42MTEzMyw5MSw0MDguNSw5MSw0MDguNQ0KCQkJCXMtMTkuNjExODIsMTUuODYwMzUtNS44NDAzMyw0OS41MDY4NGMtMTkuMzg0MjgsMzUuOTA4MiwxLjUwNTM3LDUzLjQ0MzM2LDEuNTA1MzcsNTMuNDQzMzZzLTE2LjU3MTc4LTE2LjIyNTU5LDAuMjk1NDEtNDkuMzU0NDkNCgkJCQlDOTAuNzM4NzcsNDcwLjEyMjA3LDk2LjM2NjIxLDQ3OS4wNzgxMiwxMDQuNSw0ODljMTAuNDE5OTIsMTIuNzA5OTYsMTkuOTU4NSwyMS4wOTY2OCwyOC40NzcwNSwyNi40ODkyNg0KCQkJCWMtMTQuMDc1NjgsNy43NDMxNi0yNS4xNzgyMiw5Ljk0NDM0LTMzLjU2Mjk5LDEwLjU2MTUyYy0xNC4zMzEwNSwxLjA1NDY5LTIxLjk0MDkyLTMuNDI0OC0yMS45NDA5Mi0zLjQyNDgNCgkJCQlzMTAuMTcxMzksNy43MDg5OCwyMy41NjM5Niw2LjI5OThjMTMuNzAxNjYtMS40NDMzNiwyNS42MTI3OS01Ljg5ODQ0LDM1LjU2ODM2LTExLjI4MTI1DQoJCQkJQzE2My4wOTI3Nyw1MzIuMzA4NTksMTc4Ljc1LDUxNy43NSwxNzguNzUsNTE3Ljc1cy0xNC4yOTYzOSwxMS4zODM3OS0zOC45MDU3Ni0xLjkyNTc4DQoJCQkJYzE2LjA4MTA1LTkuNDAxMzcsMjYuNDk4MDUtMjAuODA3NjIsMzAuMzI4NjEtMjQuMjI4NTJjMC4wMzE3NC0wLjAyODMyLDAuMDcxMjktMC4wNjY0MSwwLjEwNC0wLjA5NTdoMTAuNTU2MTVsMS4zNzg5MS0xMy4xOTA0Mw0KCQkJCWMxLjQxNjAyLTEuNzY2NiwyLjg4MjMyLTMuNjY2OTksNC4zNjMyOC01LjY3Njc2YzAuMzE5ODIsMC43MzgyOCwwLjYyNDUxLDEuNDY2OCwwLjkxNzk3LDIuMTg3NUwxODUuODMzMDEsNDkxLjVoNi42OTQzNA0KCQkJCWMxLjIwNjU0LDYuMzUzNTIsMS4zNjI3OSwxMS43MDIxNSwxLjEzOTY1LDE2LjE2Njk5QzE5Myw1MjEsMTg4LDUyNy41LDE4OCw1MjcuNXM4LjI2NzU4LTguNDkyMTksOC41LTIxDQoJCQkJYzAuMDk3MTctNS4yMjg1Mi0wLjMxMzQ4LTEwLjIzMjQyLTEuMDgwNTctMTVIMjA2bDctNzAuMzMzMDFoLTQuNTIzNDQNCgkJCQlDMjA5LjIwMzEyLDQwMi41NjY0MSwxOTkuNzAyMTUsMzkzLjAwNzgxLDE5OS43MDIxNSwzOTMuMDA3ODF6IE0xMzYuMTQ1NTEsNTEzLjY4MzU5DQoJCQkJYy05LjA4NDk2LTUuNjEyMy0xOS40NDE0MS0xNC41NDk4LTMwLjg5NTUxLTI4LjQzMzU5Yy03Ljg1MDU5LTkuNTE2Ni0xMy4yMjQxMi0xOC4xODc1LTE2Ljc4NzExLTI1Ljk5NTEyDQoJCQkJYzQuOTc1MS05LjAyMjQ2LDEyLjM4OTE2LTE5LjIyOTQ5LDIzLjE3NzczLTMwLjYzNjcyYzcuOTg5NzUtOC40NDcyNywxNS41Mzc2LTE0Ljc3NTM5LDIyLjU3NDcxLTE5LjQ3MTY4DQoJCQkJYzExLjQzOTk0LDcuMzU4NCwyMi41Mjc4MywxNy41NjU0MywzMS44MTM5NiwyOS41OTk2MUwxNjUuMTY2OTksNDQ4aC0yNy4zMzM5OGwzLjAwMDk4LTI2LjgzMzAxSDEyMGwtNyw3MC40OTkwMmgyMC44MzMwMQ0KCQkJCWwyLjUtMjYuMTY2MDJoMjZsLTIsMjZoNC43NjA3NEMxNTQuMzYwMzUsNTAxLjQ4MzQsMTQ0LjcyODAzLDUwOC42MDc0MiwxMzYuMTQ1NTEsNTEzLjY4MzU5eiBNMTgyLjg2ODE2LDQ3Mi4wMzEyNQ0KCQkJCWwwLjYyMjU2LTUuOTU3MDNjMC41Mjc4MywxLjA0NDkyLDEuMDI3MzQsMi4wNzEyOSwxLjUwNDg4LDMuMDgzOThDMTg0LjMwMDc4LDQ3MC4xMjEwOSwxODMuNTkyNzcsNDcxLjA3ODEyLDE4Mi44NjgxNiw0NzIuMDMxMjUNCgkJCQl6Ii8+DQoJCQk8cGF0aCBmaWxsPSIjMzMzMDkyIiBkPSJNMjQ1LDQ3Mi4zMzMwMWMtNi4xNjY5OSwwLTcuNS0zLjY2NjAyLTYuODMzMDEtNy4zMzMwMVMyNDEsNDQxLjE2Njk5LDI0MSw0NDEuMTY2OTlsMzUuODMzMDEsMC4xNjYwMg0KCQkJCWwxLjY2Njk5LTIwTDIxNi4xMjUsNDIxLjI1bC0yLDE5Ljg3NWw1Ljg3NSwwLjA0MTk5YzAsMC0xLjgzMzAxLDEyLjgzMzAxLTMuMTY2OTksMzANCgkJCQlDMjE1LjQ5OTAyLDQ4OC4zMzMwMSwyMjksNDkxLjUsMjMyLjgzMzAxLDQ5MS41aDUzbDEuODMzOTgtMTkuMTY2OTlIMjQ1eiIvPg0KCQk8L2c+DQoJPC9nPg0KPC9nPg0KPHBhdGggZmlsbD0iIzU0Qjk0OCIgZD0iTTE5OS43MDIxNSwzOTMuMDA3ODFjMCwwLDExLjc3NDQxLDExLjgyOTEsOC4xMTYyMSwzNC43OTM5NQ0KCWMtNC41NjM0OCwyOC42MjQwMi0zMS4zMDA3OCw1OC4xMjQwMi0zNy42NDU1MSw2My43OTM5NWMtNi4zNDg2Myw1LjY2OTkyLTMwLjc2NTYyLDMzLjI4NzExLTY5LjEzNTc0LDM3LjMzMDA4DQoJYy0xMy4zOTI1OCwxLjQwOTE4LTIzLjU2Mzk2LTYuMjk5OC0yMy41NjM5Ni02LjI5OThzNy42MDk4Niw0LjQ3OTQ5LDIxLjk0MDkyLDMuNDI0OA0KCWMxNC4zMzM5OC0xLjA1NTY2LDM2LjU5NTctNi43MTE5MSw2OC4xMTEzMy0zNi44Mzc4OUMxOTkuMDQzOTUsNDU5LjA4NDk2LDIxNS40NDA0Myw0MTYuMzY4MTYsMTk5LjcwMjE1LDM5My4wMDc4MSIvPg0KPHBhdGggZmlsbD0iIzU0Qjk0OCIgZD0iTTE5MS43NDkwMiw0MDMuMjE1ODJjMCwwLTMxLjQ0NjI5LTMwLjM1MDU5LTg0LjIxMjg5LDI1LjA5NjY4DQoJYy01My4yNjIyMSw1NS45NzA3LTIwLjg3MTA5LDgzLjEzNzctMjAuODcxMDksODMuMTM3N3MtMjcuNzE5MjQtMjcuMTE0MjYsMjQuOTc1NTktODIuODMyMDMNCglDMTU5LjU5MDgyLDM3Ny45MTg5NSwxOTEuNzQ5MDIsNDAzLjIxNTgyLDE5MS43NDkwMiw0MDMuMjE1ODIiLz4NCjxwYXRoIGZpbGw9IiMwMEFFRUYiIGQ9Ik04Mi41LDQwMGMwLDAsMTIuMjUtOS41LDMzLTMuNWMyNS44NjYyMSw3LjQ3ODUyLDUwLDM1LjUsNTQuNSw0MnMyNy4xNjY5OSwzMi4xNjY5OSwyNi41LDY4DQoJYy0wLjIzMjQyLDEyLjUwNzgxLTguNSwyMS04LjUsMjFzNS02LjUsNS42NjY5OS0xOS44MzMwMWMwLjY2NjAyLTEzLjMzMzk4LTItMzQuNS0yNi4xNjY5OS02N1MxMDUuODMzMDEsMzg4LjE2Njk5LDgyLjUsNDAwIi8+DQo8cGF0aCBmaWxsPSIjMDBBRUVGIiBkPSJNOTEsNDA4LjVjMCwwLTMxLjU3NzE1LDI1LjUxNTYyLDEzLjUsODAuNWM0NS41LDU1LjUsNzQuMjUsMjguNzUsNzQuMjUsMjguNzVzLTI4LjE2Njk5LDIyLjQ1MDItNzMuNS0zMi41DQoJQzY0LDQzNS4yNSw5MSw0MDguNSw5MSw0MDguNSIvPg0KPHBvbHlnb24gZmlsbD0iIzMzMzA5MiIgcG9pbnRzPSIxMTMsNDkxLjY2NjAyIDEyMCw0MjEuMTY2OTkgMTQwLjgzMzk4LDQyMS4xNjY5OSAxMzcuODMzMDEsNDQ4IDE2NS4xNjY5OSw0NDggMTY3LjY2Njk5LDQyMS4xNjYwMiANCgkxODguMTY2OTksNDIxLjMzMzAxIDE4MC44MzMwMSw0OTEuNSAxNjAuMzMzMDEsNDkxLjUgMTYyLjMzMzAxLDQ2NS41IDEzNi4zMzMwMSw0NjUuNSAxMzMuODMzMDEsNDkxLjY2NjAyICIvPg0KPHBvbHlnb24gZmlsbD0iIzMzMzA5MiIgcG9pbnRzPSIyMDYsNDkxLjUgMTg1LjgzMzAxLDQ5MS41IDE5Mi44MzMwMSw0MjEuMTY2OTkgMjEzLDQyMS4xNjY5OSAiLz4NCjxwYXRoIGZpbGw9IiMzMzMwOTIiIGQ9Ik0yMTYuMTI1LDQyMS4yNWw2Mi4zNzUsMC4wODMwMWwtMS42NjY5OSwyMEwyNDEsNDQxLjE2Njk5YzAsMC0yLjE2NjAyLDIwLjE2NjAyLTIuODMzMDEsMjMuODMzMDENCglzMC42NjYwMiw3LjMzMzAxLDYuODMzMDEsNy4zMzMwMWg0Mi42NjY5OUwyODUuODMzMDEsNDkxLjVoLTUzYy0zLjgzMzAxLDAtMTcuMzMzOTgtMy4xNjY5OS0xNi0yMC4zMzMwMQ0KCWMxLjMzMzk4LTE3LjE2Njk5LDMuMTY2OTktMzAsMy4xNjY5OS0zMGwtNS44NzUtMC4wNDE5OUwyMTYuMTI1LDQyMS4yNXoiLz4NCjwvc3ZnPg0K" alt="HIT Logo" class="header-logo" style="" />
            <h1>Veeam Backup Repository Analysis - $ServerName</h1>
            <p>Comprehensive backup file analysis and statistics</p>
        </div>
            
        <div class="content">
"@

    # Add repository capacity information to StorageMetrics
    $StorageMetrics.RepositoryInfo = @{
        TotalCapacityTB = $totalCapacityTB
        UsedSpaceTB = $usedSpaceTB
        FreeSpaceTB = $freeSpaceTB
        BackupDataTB = $backupDataTB
        UsagePercent = $usagePercent
        BackupDrive = $backupDrive
    }
    
    # Generate individual charts for each repository dynamically (for later use in repository sections)
    $validRepositories = @()
    $chartIndex = 0
    
    # First, identify repositories that have machines with data
    foreach ($repository in $BackupLocations.Repositories) {
        $repoMachineKeys = $StorageMetrics.MachineMetrics.Keys | Where-Object { $_ -like "$($repository.Name)::*" } | Sort-Object { $StorageMetrics.MachineMetrics[$_].TotalSizeGB } -Descending
        
        if ($repoMachineKeys.Count -gt 0) {
            $chartIndex++
            $validRepositories += @{
                Repository = $repository
                MachineKeys = $repoMachineKeys
                ChartIndex = $chartIndex
                ChartId = "repoChart$chartIndex"
            }
        }
    }
    
    # Get all recommendations first
    $allRecommendations = Get-StorageRecommendations -StorageMetrics $StorageMetrics
    
    # Add repository and ADHOC sections
    $html += @"
            <!-- Repository Sections -->
"@
    
    # Process Repositories
    foreach ($repository in $BackupLocations.Repositories) {
        # Find the corresponding chart info for this repository
        $repoChartInfo = $validRepositories | Where-Object { $_.Repository.Name -eq $repository.Name }
        
        $html += @"
            <div class="section">
                <h2 class="section-title">📦 Repository: $($repository.Name)</h2>
                <div class="repo-summary">
                    <p>📁 Path: $($repository.Path)</p>
                    <p>💻 Machines: $($repository.Machines.Count) | 📊 Total Size: $([math]::Round($repository.TotalSizeGB, 2)) GB</p>
$(if ($repository.Name -eq "Ad-Hoc Backups") { "                    <p>🎯 Includes: Individual backup files and machine folders from root drive</p>" })
            </div>
"@

        # Add chart container at the top of each repository section
        if ($repoChartInfo) {
            $chartId = $repoChartInfo.ChartId
            $html += @"
                <div class="chart-container chart-animate" data-chart-id="$chartId">
                    <div class="chart-title">📊 Storage Usage Per Machine (GB)</div>
                    <canvas id="$chartId" class="chart-canvas"></canvas>
            </div>
"@
        } else {
            # Repository has no chart data
            $html += @"
                <div class="chart-container">
                    <div class="chart-title">📊 No Chart Data Available</div>
                    <p style="text-align: center; padding: 40px; color: #666;">No backup data found for visualization.</p>
            </div>
"@
        }
        
        # Add Repository Tabs
        $tabId = if ($repoChartInfo) { $repoChartInfo.ChartId } else { "repo" + [guid]::NewGuid().ToString().Substring(0,8) }
        $html += @"
                <!-- Repository Tabs -->
                <div class="repo-tabs" id="tabs-$tabId">
                    <div class="tab-nav">
                        <button class="tab-button active" onclick="switchTab('$tabId', 'overview')">📊 Overview</button>
                        <button class="tab-button" onclick="switchTab('$tabId', 'machines')">💻 Machines</button>
                        <button class="tab-button" onclick="switchTab('$tabId', 'storage')">💾 Storage</button>
                        <button class="tab-button" onclick="switchTab('$tabId', 'recommendations')">💡 Recommendations</button>
                    </div>
                    
                    <!-- Overview Tab -->
                    <div id="tab-overview-$tabId" class="tab-content active">
                        <div class="tab-overview">
                            <div class="overview-card">
                                <h4>Repository Summary</h4>
                                <div class="overview-stat">
                                    <span class="overview-stat-label">📁 Path:</span>
                                    <span class="overview-stat-value">$($repository.Path)</span>
                                </div>
                                <div class="overview-stat">
                                    <span class="overview-stat-label">💻 Machines:</span>
                                    <span class="overview-stat-value">$($repository.Machines.Count)</span>
                                </div>
                                <div class="overview-stat">
                                    <span class="overview-stat-label">📊 Total Size:</span>
                                    <span class="overview-stat-value">$([math]::Round($repository.TotalSizeGB, 2)) GB</span>
            </div>
        </div>
            
                            <div class="overview-card">
                                <h4>Backup Distribution</h4>
                                <div class="overview-stat">
                                    <span class="overview-stat-label">🔵 Full Backups:</span>
                                    <span class="overview-stat-value">$(($repository.Machines.Keys | ForEach-Object { $StorageMetrics.MachineMetrics["$($repository.Name)::$_"].FullBackupCount } | Measure-Object -Sum).Sum)</span>
                                </div>
                                <div class="overview-stat">
                                    <span class="overview-stat-label">🟡 Incremental:</span>
                                    <span class="overview-stat-value">$(($repository.Machines.Keys | ForEach-Object { $StorageMetrics.MachineMetrics["$($repository.Name)::$_"].IncrementalBackupCount } | Measure-Object -Sum).Sum)</span>
                                </div>
                                <div class="overview-stat">
                                    <span class="overview-stat-label">📈 Total Files:</span>
                                    <span class="overview-stat-value">$(($repository.Machines.Keys | ForEach-Object { $StorageMetrics.MachineMetrics["$($repository.Name)::$_"].FullBackupCount + $StorageMetrics.MachineMetrics["$($repository.Name)::$_"].IncrementalBackupCount } | Measure-Object -Sum).Sum)</span>
            </div>
        </div>
        
                            <div class="overview-card">
                                <h4>Performance Metrics</h4>
                                <div class="overview-stat">
                                    <span class="overview-stat-label">📈 Avg Machine Size:</span>
                                    <span class="overview-stat-value">$([math]::Round($repository.TotalSizeGB / $repository.Machines.Count, 2)) GB</span>
                                </div>
                                <div class="overview-stat">
                                    <span class="overview-stat-label">🎯 Largest Machine:</span>
                                    <span class="overview-stat-value">$(($repository.Machines.Keys | Sort-Object { $StorageMetrics.MachineMetrics["$($repository.Name)::$_"].TotalSizeGB } -Descending | Select-Object -First 1) -replace '-\d{4}-\d{2}-\d{2}T\d{6}.*$', '' -replace '-adhoc.*$', '' -replace 'Job\s*', '')</span>
                                </div>
                                <div class="overview-stat">
                                    <span class="overview-stat-label">⚡ Efficiency:</span>
                                    <span class="overview-stat-value">$(if ($repository.TotalSizeGB -gt 1000) { 'High Volume' } elseif ($repository.TotalSizeGB -gt 100) { 'Moderate' } else { 'Light Usage' })</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Machines Tab -->
                    <div id="tab-machines-$tabId" class="tab-content">
                        <div class="machines-grid">
"@
        
        # Sort machines by size for this repository
        $sortedRepoMachines = $repository.Machines.Keys | Sort-Object { $StorageMetrics.MachineMetrics["$($repository.Name)::$_"].TotalSizeGB } -Descending
        
        # Generate machine summary cards for the Machines tab
        foreach ($machineName in $sortedRepoMachines) {
            $inventoryKey = "$($repository.Name)::$machineName"
            $metric = $StorageMetrics.MachineMetrics[$inventoryKey]
            
            # Clean machine name for display (remove timestamps and job suffixes)
            $cleanMachineName = $machineName -replace '-\d{4}-\d{2}-\d{2}T\d{6}.*$', '' -replace '-adhoc.*$', '' -replace 'Job\s*', ''
            
            $html += @"
                            <div class="machine-summary-card" onclick="navigateToMachineStorage('$tabId', '$cleanMachineName')" title="Click to view detailed storage analysis">
                                <div class="machine-summary-header">
                                    <span class="machine-summary-name">📁 $cleanMachineName</span>
                                    <span class="machine-summary-size">$([math]::Round($metric.TotalSizeGB, 2)) GB</span>
                                </div>
                                <div class="machine-summary-stats">
                                    <div class="machine-summary-stat">
                                        <span class="machine-summary-stat-value">$($metric.FullBackupCount)</span>
                                        <span class="machine-summary-stat-label">Full Backups</span>
                                    </div>
                                    <div class="machine-summary-stat">
                                        <span class="machine-summary-stat-value">$($metric.IncrementalBackupCount)</span>
                                        <span class="machine-summary-stat-label">Incrementals</span>
                                    </div>
                                </div>
                            </div>
"@
        }
        
        $html += @"
                        </div>
                    </div>
                    
                    <!-- Storage Tab -->
                    <div id="tab-storage-$tabId" class="tab-content">
                        <div class="tab-overview">
                            <div class="overview-card">
                                <h4>Storage Breakdown</h4>
                                <div class="overview-stat">
                                    <span class="overview-stat-label">💾 Used Space:</span>
                                    <span class="overview-stat-value">$([math]::Round($repository.TotalSizeGB, 2)) GB</span>
                                </div>
                                <div class="overview-stat">
                                    <span class="overview-stat-label">📊 Storage Health:</span>
                                    <span class="overview-stat-value">$(if ($repository.TotalSizeGB -gt 10000) { 'Large Repository' } elseif ($repository.TotalSizeGB -gt 1000) { 'Medium Repository' } else { 'Small Repository' })</span>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Detailed Machine Storage Analysis -->
"@
        
        # Generate detailed machine storage sections for the Storage tab
        foreach ($machineName in $sortedRepoMachines) {
            $inventoryKey = "$($repository.Name)::$machineName"
            $metric = $StorageMetrics.MachineMetrics[$inventoryKey]
            $machineData = $BackupInventory[$inventoryKey]
        
            # Skip if machine data doesn't exist (safety check)
            if (-not $metric -or -not $machineData) {
                continue
            }
        
            # Clean machine name for display (remove timestamps and job suffixes)
            $cleanMachineName = $machineName -replace '-\d{4}-\d{2}-\d{2}T\d{6}.*$', '' -replace '-adhoc.*$', '' -replace 'Job\s*', ''
        
        # Get backup points in retention from analysis
        $backupPoints = if ($metric.RetentionAnalysis) { $metric.RetentionAnalysis.RetentionPoints } else { $metric.FullBackupCount + $metric.IncrementalBackupCount }
            
            # Filter recommendations for this specific machine
            $machineRecommendations = $allRecommendations | Where-Object { $_.Machine -eq $inventoryKey }
        
                    # Get the file system path for this machine
            $machinePath = if ($machineData.FullBackups.Count -gt 0) {
                Split-Path $machineData.FullBackups[0].FullPath -Parent
            } elseif ($machineData.IncrementalBackups.Count -gt 0) {
                Split-Path $machineData.IncrementalBackups[0].FullPath -Parent
            } else {
                "N/A"
            }
            
            $html += @"
                        <div class="vm-section" id="machine-$tabId-$cleanMachineName">
                            <div class="vm-header">
                                📁 $($repository.Name) : $cleanMachineName : $machinePath
                                <div class="retention-info">Currently has $backupPoints backup points in retention</div>
                            </div>
                <div class="backup-stats">
                    <div class="backup-type incremental">
                        <h4>🔴 Incremental Backups (.vib)</h4>
"@
        
        # Add incremental backup stats
            if ($machineData.IncrementalBackups -and $machineData.IncrementalBackups.Count -gt 0) {
                try {
            $lastIncremental = ($machineData.IncrementalBackups | Sort-Object LastWriteTime -Descending | Select-Object -First 1).LastWriteTime
            $smallestIncremental = ($machineData.IncrementalBackups | Sort-Object SizeGB | Select-Object -First 1).SizeGB
            $largestIncremental = ($machineData.IncrementalBackups | Sort-Object SizeGB -Descending | Select-Object -First 1).SizeGB
            $avgIncremental = [math]::Round(($machineData.IncrementalBackups | Measure-Object -Property SizeGB -Average).Average, 2)
                } catch {
                    # Handle any data processing errors
                    $lastIncremental = "N/A"
                    $smallestIncremental = 0
                    $largestIncremental = 0
                    $avgIncremental = 0
                }
            
            $html += @"
                                <div class="stat-row">
                                    <span class="stat-label">Count:</span>
                                    <span class="stat-value">$($metric.IncrementalBackupCount) files</span>
                                </div>
                                <div class="stat-row">
                                    <span class="stat-label">Last Run:</span>
                                        <span class="stat-value">$(if ($lastIncremental -ne "N/A" -and $lastIncremental) { $lastIncremental.ToString('ddd yyyy-MM-dd HH:mm:ss') } else { "N/A" })</span>
                                </div>
                                <div class="stat-row">
                                    <span class="stat-label">Smallest:</span>
                                    <span class="stat-value">$smallestIncremental GB</span>
                                </div>
                                <div class="stat-row">
                                    <span class="stat-label">Largest:</span>
                                    <span class="stat-value">$largestIncremental GB</span>
                                </div>
                                <div class="stat-row">
                                    <span class="stat-label">Average:</span>
                                    <span class="stat-value">$avgIncremental GB</span>
                                </div>
                                <div class="stat-row">
                                    <span class="stat-label">Std Dev:</span>
                                    <span class="stat-value">$($metric.IncrementalBackupStdDev) GB</span>
                                </div>
                                <div class="stat-row">
                                    <span class="stat-label">Total Size:</span>
                                    <span class="stat-value">$([math]::Round($metric.IncrementalBackupSizeGB, 2)) GB</span>
                                </div>
"@
        } else {
            $html += @"
                                <div class="stat-row">
                                    <span class="stat-value">No incremental backups found</span>
                                </div>
"@
        }
        
        $html += @"
                    </div>
                    <div class="backup-type full">
                        <h4>🟢 Full Backups (.vbk)</h4>
"@
        
        # Add full backup stats
            if ($machineData.FullBackups -and $machineData.FullBackups.Count -gt 0) {
                try {
            $lastFull = ($machineData.FullBackups | Sort-Object LastWriteTime -Descending | Select-Object -First 1).LastWriteTime
            $smallestFull = ($machineData.FullBackups | Sort-Object SizeGB | Select-Object -First 1).SizeGB
            $largestFull = ($machineData.FullBackups | Sort-Object SizeGB -Descending | Select-Object -First 1).SizeGB
            $avgFull = [math]::Round(($machineData.FullBackups | Measure-Object -Property SizeGB -Average).Average, 2)
                } catch {
                    # Handle any data processing errors
                    $lastFull = "N/A"
                    $smallestFull = 0
                    $largestFull = 0
                    $avgFull = 0
                }
            
            $html += @"
                                <div class="stat-row">
                                    <span class="stat-label">Count:</span>
                                    <span class="stat-value">$($metric.FullBackupCount) files</span>
                                </div>
                                <div class="stat-row">
                                    <span class="stat-label">Last Run:</span>
                                        <span class="stat-value">$(if ($lastFull -ne "N/A" -and $lastFull) { $lastFull.ToString('ddd yyyy-MM-dd HH:mm:ss') } else { "N/A" })</span>
                                </div>
                                <div class="stat-row">
                                    <span class="stat-label">Smallest:</span>
                                    <span class="stat-value">$smallestFull GB</span>
                                </div>
                                <div class="stat-row">
                                    <span class="stat-label">Largest:</span>
                                    <span class="stat-value">$largestFull GB</span>
                                </div>
                                <div class="stat-row">
                                    <span class="stat-label">Average:</span>
                                    <span class="stat-value">$avgFull GB</span>
                                </div>
                                <div class="stat-row">
                                    <span class="stat-label">Std Dev:</span>
                                    <span class="stat-value">$($metric.FullBackupStdDev) GB</span>
                                </div>
                                <div class="stat-row">
                                    <span class="stat-label">Total Size:</span>
                                    <span class="stat-value">$([math]::Round($metric.FullBackupSizeGB, 2)) GB</span>
                                </div>
"@
        } else {
            $html += @"
                                <div class="stat-row">
                                    <span class="stat-value">No full backups found</span>
                                </div>
"@
        }
        
        $html += @"
                    </div>
                </div>
"@
            
            # Add machine-specific recommendations if any exist in Storage tab
            if ($machineRecommendations.Count -gt 0) {
                $html += @"
                            <div class="machine-recommendations">
                                <h4 class="recommendations-header">💡 Storage Insights & Recommendations</h4>
                                <div class="recommendations-list">
"@
                
                # Sort recommendations by severity (High -> Medium -> Low)
                $sortedMachineRecs = $machineRecommendations | Sort-Object { 
                    switch ($_.Severity) {
                        "High" { 1 }
                        "Medium" { 2 }
                        "Low" { 3 }
                        default { 4 }
                    }
                }
                
                foreach ($rec in $sortedMachineRecs) {
                    $severityClass = $rec.Severity.ToLower()
                    $icon = switch ($rec.Severity) {
                        "High" { "🚨" }
                        "Medium" { "⚠️" }
                        "Low" { "💡" }
                        default { "ℹ️" }
                    }
                    
                    $categoryIcon = switch ($rec.Category) {
                        "Backup Health" { "🩺" }
                        "Risk Management" { "🛡️" }
                        "Performance" { "⚡" }
                        "Storage Optimization" { "💾" }
                        "Capacity Management" { "📊" }
                        "Capacity Planning" { "📈" }
                        "Cost Optimization" { "💰" }
                        "Schedule Optimization" { "⏰" }
                        "Data Analysis" { "📈" }
                        "Storage Analysis" { "🔍" }
                        "Infrastructure" { "🏗️" }
                        default { "💡" }
                    }
                    
                    $html += @"
                                    <div class="machine-recommendation-item $severityClass">
                                        <div class="recommendation-header-inline">
                                            <span class="severity-icon">$icon</span>
                                            <span class="category-icon">$categoryIcon</span>
                                            <span class="category-name">$($rec.Category)</span>
                                            <span class="severity-badge-inline $severityClass">$($rec.Severity)</span>
                                        </div>
                                        <div class="recommendation-message-inline">$($rec.Message)</div>
            </div>
"@
    }
    
                $html += @"
                                </div>
                            </div>
"@
            }
            
        $html += @"
            </div>
"@
        }
        
        # Close Storage tab and add Recommendations tab
        $html += @"
                    </div>
                    
                    <!-- Recommendations Tab -->
                    <div id="tab-recommendations-$tabId" class="tab-content">
"@
        
        # Add repository-specific recommendations to the Recommendations tab
        $repoSpecificRecommendations = $allRecommendations | Where-Object { $_.Machine -like "$($repository.Name)::*" }
        
        if ($repoSpecificRecommendations.Count -gt 0) {
            $html += @"
                        <h4>🔍 Machine-Specific Recommendations</h4>
                        <div class="recommendations-list">
"@
            
            # Group by machine
            $machineGroups = $repoSpecificRecommendations | Group-Object Machine
            
            foreach ($group in $machineGroups) {
                $machineDisplayName = ($group.Name -split "::")[-1] # Get machine name after "::"
                $html += @"
                            <div class="machine-group">
                                <h5>📁 $machineDisplayName</h5>
"@
                
                foreach ($rec in $group.Group) {
                    $severityClass = $rec.Severity.ToLower()
                    $icon = switch ($rec.Severity) {
                        "High" { "🚨" }
                        "Medium" { "⚠️" }
                        "Low" { "💡" }
                        default { "ℹ️" }
                    }
                    
                    $categoryIcon = switch ($rec.Category) {
                        "Backup Health" { "🩺" }
                        "Risk Management" { "🛡️" }
                        "Performance" { "⚡" }
                        "Storage Optimization" { "💾" }
                        "Capacity Management" { "📊" }
                        "Capacity Planning" { "📈" }
                        "Cost Optimization" { "💰" }
                        "Schedule Optimization" { "⏰" }
                        "Data Analysis" { "📈" }
                        "Storage Analysis" { "🔍" }
                        "Infrastructure" { "🏗️" }
                        default { "💡" }
                    }
                    
                    $html += @"
                                <div class="machine-recommendation-item $severityClass">
                                    <div class="recommendation-header-inline">
                                        <span class="severity-icon">$icon</span>
                                        <span class="category-icon">$categoryIcon</span>
                                        <span class="category-name">$($rec.Category)</span>
                                        <span class="severity-badge-inline $severityClass">$($rec.Severity)</span>
                                    </div>
                                    <div class="recommendation-message-inline">$($rec.Message)</div>
                                </div>
"@
                }
                
                $html += @"
                            </div>
"@
            }
            
            $html += @"
                        </div>
"@
        } else {
            $html += @"
                        <div style="text-align: center; padding: 40px; color: #666;">
                            <h4>✅ No Specific Recommendations</h4>
                            <p>This repository is operating within optimal parameters.</p>
                        </div>
"@
        }
        
        $html += @"
                    </div>
                </div>
            </div>
"@
    }
    

    
    # Add repository-level insights section
    $html += @"
            </div>
            
            <!-- Repository-Level Insights Section -->
            <div class="section">
                <h2 class="section-title">🏢 Repository-Level Insights</h2>
"@
    
    # Add Storage Space Breakdown
    $html += @"
                <!-- Storage Space Breakdown -->
                <div class="storage-breakdown-section">
                    <h3 class="storage-breakdown-title">💾 Storage Space Breakdown by Repository</h3>
                    <div class="storage-breakdown-container">
"@
    
    # Calculate total storage across all repositories
    $totalStorageGB = [math]::Round(($BackupLocations.Repositories | Measure-Object -Property TotalSizeGB -Sum).Sum, 2)
    
    # Process each repository for storage breakdown
    foreach ($repository in $BackupLocations.Repositories) {
        $repoStoragePercent = if ($totalStorageGB -gt 0) { [math]::Round(($repository.TotalSizeGB / $totalStorageGB) * 100, 1) } else { 0 }
        $repoId = "storage-" + [guid]::NewGuid().ToString().Substring(0,8)
        
        $html += @"
                        <div class="repo-storage-card">
                            <div class="repo-storage-header" onclick="toggleStorageDetails('$repoId')">
                                <div class="repo-storage-info">
                                    <span class="repo-storage-name">📦 $($repository.Name)</span>
                                    <span class="repo-storage-stats">$($repository.Machines.Count) machines | $([math]::Round($repository.TotalSizeGB, 2)) GB ($repoStoragePercent%)</span>
                                </div>
                                <div class="repo-storage-bar">
                                    <div class="repo-storage-fill" style="width: $repoStoragePercent%"></div>
                                </div>
                                <span class="collapse-icon" id="icon-$repoId">▼</span>
                            </div>
                            <div class="repo-storage-details" id="details-$repoId" style="display: none;">
"@
        
        # Sort machines by size for this repository
        $sortedMachines = $repository.Machines.Keys | Sort-Object { $StorageMetrics.MachineMetrics["$($repository.Name)::$_"].TotalSizeGB } -Descending
        
        foreach ($machineName in $sortedMachines) {
            $inventoryKey = "$($repository.Name)::$machineName"
            $metric = $StorageMetrics.MachineMetrics[$inventoryKey]
            $machinePercent = if ($repository.TotalSizeGB -gt 0) { [math]::Round(($metric.TotalSizeGB / $repository.TotalSizeGB) * 100, 1) } else { 0 }
            
            # Clean machine name for display
            $cleanMachineName = $machineName -replace '-\d{4}-\d{2}-\d{2}T\d{6}.*$', '' -replace '-adhoc.*$', '' -replace 'Job\s*', ''
            
            $html += @"
                                <div class="vm-storage-item">
                                    <div class="vm-storage-header">
                                        <span class="vm-storage-name">💻 $cleanMachineName</span>
                                        <span class="vm-storage-size">$([math]::Round($metric.TotalSizeGB, 2)) GB</span>
                                    </div>
                                    <div class="vm-storage-details">
                                        <div class="vm-storage-bar-container">
                                            <div class="vm-storage-bar">
                                                <div class="vm-storage-fill" style="width: $machinePercent%"></div>
                                            </div>
                                            <span class="vm-storage-percent">$machinePercent%</span>
                                        </div>
                                        <div class="vm-storage-breakdown">
                                            <span class="vm-storage-full">🟢 Full: $([math]::Round($metric.FullBackupSizeGB, 2)) GB ($($metric.FullBackupCount) files)</span>
                                            <span class="vm-storage-inc">🔴 Inc: $([math]::Round($metric.IncrementalBackupSizeGB, 2)) GB ($($metric.IncrementalBackupCount) files)</span>
                                        </div>
                                    </div>
                                </div>
"@
        }
        
        $html += @"
                            </div>
                        </div>
"@
    }
    
    $html += @"
                    </div>
                </div>
"@
    
    # Add repository recommendations if any
    $repositoryRecommendations = $allRecommendations | Where-Object { $_.Machine -eq "Repository" }
    
    if ($repositoryRecommendations.Count -gt 0) {
        $html += @"
                <div class="recommendations-summary">
"@
        
        # Group repository recommendations by category and severity
        $categorizedRecs = @{}
        $severityCounts = @{ "High" = 0; "Medium" = 0; "Low" = 0 }
        
        foreach ($rec in $repositoryRecommendations) {
            $category = if ($rec.Category) { $rec.Category } else { "General" }
            if (-not $categorizedRecs.ContainsKey($category)) {
                $categorizedRecs[$category] = @()
            }
            $categorizedRecs[$category] += $rec
            $severityCounts[$rec.Severity]++
        }
        
        # Add summary overview
        $html += @"
                    <div class="recommendation-overview">
                        <h3>📊 Repository Analysis Summary</h3>
                        <div class="severity-badges">
                            <span class="severity-badge high">$($severityCounts["High"]) Critical</span>
                            <span class="severity-badge medium">$($severityCounts["Medium"]) Warnings</span>
                            <span class="severity-badge low">$($severityCounts["Low"]) Optimizations</span>
                        </div>
                        <p class="summary-text">Repository-wide insights for infrastructure planning and optimization.</p>
                    </div>
"@
        
        # Display repository recommendations by category
        $categoryOrder = @("Capacity Management", "Capacity Planning", "Storage Analysis", "Infrastructure")
        
        foreach ($category in $categoryOrder) {
            if ($categorizedRecs.ContainsKey($category)) {
                $categoryRecs = $categorizedRecs[$category]
                $categoryIcon = switch ($category) {
                    "Capacity Management" { "📊" }
                    "Capacity Planning" { "📈" }
                    "Storage Analysis" { "🔍" }
                    "Infrastructure" { "🏗️" }
                    default { "💡" }
                }
                
                $html += @"
                    <div class="recommendation-category">
                        <h4 class="category-header">$categoryIcon $category ($($categoryRecs.Count) items)</h4>
                        <div class="category-items">
"@
                
                # Sort by severity (High -> Medium -> Low)
                $sortedRecs = $categoryRecs | Sort-Object { 
                    switch ($_.Severity) {
                        "High" { 1 }
                        "Medium" { 2 }
                        "Low" { 3 }
                        default { 4 }
                    }
                }
                
                foreach ($rec in $sortedRecs) {
                    $severityClass = $rec.Severity.ToLower()
            $icon = switch ($rec.Severity) {
                        "High" { "🚨" }
                "Medium" { "⚠️" }
                        "Low" { "💡" }
                        default { "ℹ️" }
            }
            
            $html += @"
                            <div class="recommendation-item $severityClass">
                                <div class="recommendation-header">
                                    <span class="severity-icon">$icon</span>
                                    <span class="machine-name">Repository</span>
                                    <span class="severity-label $severityClass">$($rec.Severity)</span>
                        </div>
                                <div class="recommendation-message">$($rec.Message)</div>
                    </div>
"@
        }
        
        $html += @"
                        </div>
                </div>
"@
            }
    }
    
        # Add any remaining categories not in the predefined order
        foreach ($category in $categorizedRecs.Keys) {
            if ($category -notin $categoryOrder) {
                $categoryRecs = $categorizedRecs[$category]
    $html += @"
                    <div class="recommendation-category">
                        <h4 class="category-header">💡 $category ($($categoryRecs.Count) items)</h4>
                        <div class="category-items">
"@
                
                foreach ($rec in $categoryRecs) {
                    $severityClass = $rec.Severity.ToLower()
                    $icon = switch ($rec.Severity) {
                        "High" { "🚨" }
                        "Medium" { "⚠️" }
                        "Low" { "💡" }
                        default { "ℹ️" }
                    }
                    
                    $html += @"
                            <div class="recommendation-item $severityClass">
                                <div class="recommendation-header">
                                    <span class="severity-icon">$icon</span>
                                    <span class="machine-name">Repository</span>
                                    <span class="severity-label $severityClass">$($rec.Severity)</span>
            </div>
                                <div class="recommendation-message">$($rec.Message)</div>
                            </div>
"@
                }
                
                $html += @"
                        </div>
                    </div>
"@
            }
        }
        
        $html += @"
                </div>
"@
    }
    
    # Add overall recommendations summary
    $totalMachineRecs = $allRecommendations | Where-Object { $_.Machine -ne "Repository" }
    if ($totalMachineRecs.Count -gt 0 -or $repositoryRecommendations.Count -gt 0) {
        $totalHighSeverity = ($allRecommendations | Where-Object { $_.Severity -eq "High" }).Count
        $totalMediumSeverity = ($allRecommendations | Where-Object { $_.Severity -eq "Medium" }).Count
        $totalLowSeverity = ($allRecommendations | Where-Object { $_.Severity -eq "Low" }).Count
        $machinesWithRecommendations = ($totalMachineRecs | Select-Object -ExpandProperty Machine -Unique).Count
        
        $html += @"
            
            <!-- Overall Summary -->
            <div class="section">
                <h2 class="section-title">📈 Overall Recommendations Summary</h2>
                <div class="summary-stats">
                    <div class="summary-stat-card high">
                        <h3>$totalHighSeverity</h3>
                        <p>Critical Issues</p>
                        <small>Require immediate attention</small>
                    </div>
                    <div class="summary-stat-card medium">
                        <h3>$totalMediumSeverity</h3>
                        <p>Warnings</p>
                        <small>Should be addressed soon</small>
                    </div>
                    <div class="summary-stat-card low">
                        <h3>$totalLowSeverity</h3>
                        <p>Optimizations</p>
                        <small>Potential improvements</small>
                    </div>
                    <div class="summary-stat-card info">
                        <h3>$machinesWithRecommendations</h3>
                        <p>Machines Analyzed</p>
                        <small>With specific recommendations</small>
                    </div>
                </div>
            </div>
"@
    }
    
    $html += @"
            </div>
        </div>
        
        <div class="footer">
            <p>Veeam Backup Explorer $(Get-Date -Format 'yyyy')</p>
            <p style="margin-top: 15px; font-size: 0.8em; color: #bdc3c7;">
                Author: David Andrews | © $(Get-Date -Format 'yyyy') Houston Information Team. All rights reserved. This document and its contents are the property of Houston Information Team 
                and are protected by U.S. and international copyright laws. No part of this document may be copied, reproduced, distributed, 
                transmitted, displayed, stored in a retrieval system, or used in any form or by any means, electronic, mechanical, photocopying, 
                recording, or otherwise, without the prior written permission of Houston Information Team. Unauthorized use, disclosure, or duplication is strictly prohibited.
            </p>
        </div>
    </div>

    <script>
        // Function to switch tabs
        function switchTab(tabGroupId, tabName, skipButtonUpdate) {
            // Hide all tab contents for this group
            const tabGroup = document.getElementById('tabs-' + tabGroupId);
            const tabContents = tabGroup.querySelectorAll('.tab-content');
            const tabButtons = tabGroup.querySelectorAll('.tab-button');
            
            tabContents.forEach(content => {
                content.classList.remove('active');
            });
            
            tabButtons.forEach(button => {
                button.classList.remove('active');
            });
            
            // Show selected tab content
            const selectedTab = document.getElementById('tab-' + tabName + '-' + tabGroupId);
            
            if (selectedTab) {
                selectedTab.classList.add('active');
            }
            
            // Update button state
            if (!skipButtonUpdate) {
                const selectedButton = event.target;
                if (selectedButton && selectedButton.classList.contains('tab-button')) {
                    selectedButton.classList.add('active');
                }
            } else {
                // Find and activate the correct button
                tabButtons.forEach(button => {
                    if (button.textContent.toLowerCase().includes(tabName.toLowerCase())) {
                        button.classList.add('active');
                    }
                });
            }
        }
        
        // Function to navigate to a specific machine in the Storage tab
        function navigateToMachineStorage(tabGroupId, machineName) {
            // Switch to Storage tab
            switchTab(tabGroupId, 'storage', true);
            
            // Wait for tab animation to complete
            setTimeout(() => {
                // Find the machine section
                const machineSection = document.getElementById('machine-' + tabGroupId + '-' + machineName);
                if (machineSection) {
                    // Scroll to the machine section with smooth animation
                    machineSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
                    
                    // Add a highlight effect
                    machineSection.style.transition = 'box-shadow 0.3s ease';
                    machineSection.style.boxShadow = '0 0 20px rgba(59, 130, 246, 0.5)';
                    
                    // Remove highlight after 2 seconds
                    setTimeout(() => {
                        machineSection.style.boxShadow = '';
                    }, 2000);
                }
            }, 300);
        }
        
        // Function to toggle storage details collapse/expand
        function toggleStorageDetails(repoId) {
            const details = document.getElementById('details-' + repoId);
            const icon = document.getElementById('icon-' + repoId);
            
            if (details.style.display === 'none') {
                details.style.display = 'block';
                icon.classList.add('rotated');
                
                // Animate the expansion
                details.style.opacity = '0';
                details.style.transform = 'translateY(-10px)';
                setTimeout(() => {
                    details.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
                    details.style.opacity = '1';
                    details.style.transform = 'translateY(0)';
                }, 10);
            } else {
                // Animate the collapse
                details.style.opacity = '0';
                details.style.transform = 'translateY(-10px)';
                setTimeout(() => {
                    details.style.display = 'none';
                    icon.classList.remove('rotated');
                }, 300);
            }
        }
        
        // Function to create individual charts for each repository and ADHOC
        function createChart(canvasId, title, machineKeys, metrics) {
            console.log('Attempting to create chart:', { canvasId, title, machineKeys: machineKeys.length, metricsAvailable: Object.keys(metrics).length });
            
            const canvas = document.getElementById(canvasId);
            if (!canvas) {
                console.error('Canvas element not found:', canvasId);
                return;
            }
            
            if (!machineKeys || machineKeys.length === 0) {
                console.warn('No machine keys provided for chart:', canvasId);
                return;
            }
            
            const vmNames = machineKeys.map(key => {
                // Extract display name and add [ADHOC] suffix for ADHOC backups
                if (key.startsWith('ADHOC::') || key.startsWith('Ad-Hoc Backups::')) {
                    const parts = key.split('::');
                    return parts[1] + ' [ADHOC]';
                } else {
                    const parts = key.split('::');
                    return parts.length > 1 ? parts[1] : parts[0]; // Repository machine name
                }
            });
            
            // Validate that all machine keys have metrics data
            const missingKeys = machineKeys.filter(key => !metrics[key]);
            if (missingKeys.length > 0) {
                console.error('Missing metrics for keys:', missingKeys);
                return;
            }
            
            const incrementalSizes = machineKeys.map(key => metrics[key].IncrementalBackupSizeGB || 0);
            const fullSizes = machineKeys.map(key => metrics[key].FullBackupSizeGB || 0);
            const incrementalCounts = machineKeys.map(key => metrics[key].IncrementalBackupCount || 0);
            const fullCounts = machineKeys.map(key => metrics[key].FullBackupCount || 0);
        
        // Adjust canvas class based on number of VMs
        if (vmNames.length > 8) {
            canvas.classList.add('chart-canvas-large');
        }
        
            // Create the animated chart
        const ctx = canvas.getContext('2d');
            const chart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: vmNames,
                datasets: [{
                    label: 'Incremental Backups (GB)',
                    data: incrementalSizes,
                    backgroundColor: function(ctx) {
                        const gradient = ctx.chart.ctx.createLinearGradient(0, 0, 0, 400);
                        gradient.addColorStop(0, 'rgba(239, 68, 68, 0.9)');
                        gradient.addColorStop(1, 'rgba(239, 68, 68, 0.6)');
                        return gradient;
                    },
                    borderColor: 'rgba(220, 38, 38, 1)',
                    borderWidth: 2,
                    borderRadius: 6,
                    borderSkipped: false,
                    hoverBackgroundColor: function(ctx) {
                        const gradient = ctx.chart.ctx.createLinearGradient(0, 0, 0, 400);
                        gradient.addColorStop(0, 'rgba(239, 68, 68, 1)');
                        gradient.addColorStop(1, 'rgba(239, 68, 68, 0.8)');
                        return gradient;
                    },
                    hoverBorderColor: 'rgba(185, 28, 28, 1)',
                    hoverBorderWidth: 3,
                }, {
                    label: 'Full Backups (GB)',
                    data: fullSizes,
                    backgroundColor: function(ctx) {
                        const gradient = ctx.chart.ctx.createLinearGradient(0, 0, 0, 400);
                        gradient.addColorStop(0, 'rgba(16, 185, 129, 0.9)');
                        gradient.addColorStop(1, 'rgba(16, 185, 129, 0.6)');
                        return gradient;
                    },
                    borderColor: 'rgba(5, 150, 105, 1)',
                    borderWidth: 2,
                    borderRadius: 6,
                    borderSkipped: false,
                    hoverBackgroundColor: function(ctx) {
                        const gradient = ctx.chart.ctx.createLinearGradient(0, 0, 0, 400);
                        gradient.addColorStop(0, 'rgba(16, 185, 129, 1)');
                        gradient.addColorStop(1, 'rgba(16, 185, 129, 0.8)');
                        return gradient;
                    },
                    hoverBorderColor: 'rgba(4, 120, 87, 1)',
                    hoverBorderWidth: 3,
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: {
                    intersect: false,
                    mode: 'index'
                },
                animation: false, // Disable auto-animation, we'll trigger it manually
                animations: {
                    y: {
                        duration: 2000,
                        easing: 'easeInOutBounce',
                        from: 0
                    },
                    x: {
                        duration: 1500,
                        easing: 'easeInOutQuart'
                    }
                },
                hover: {
                    animationDuration: 300,
                    mode: 'nearest'
                },
                onHover: function(event, elements) {
                    event.native.target.style.cursor = elements.length > 0 ? 'pointer' : 'default';
                },
                scales: {
                    x: {
                        stacked: true,
                        title: {
                            display: true,
                            text: 'Machine Name',
                            font: {
                                size: 14,
                                weight: 'bold',
                                family: 'Segoe UI'
                            },
                            color: '#374151'
                        },
                        ticks: {
                            maxRotation: vmNames.length > 8 ? 90 : (vmNames.length > 5 ? 45 : 0),
                            minRotation: vmNames.length > 8 ? 90 : 0,
                            color: '#6B7280',
                            font: {
                                size: 12,
                                family: 'Segoe UI'
                            },
                            callback: function(value, index) {
                                const label = this.getLabelForValue(value);
                                if (vmNames.length > 10 && label.length > 12) {
                                    return label.substring(0, 12) + '...';
                                }
                                return label;
                            }
                        },
                        grid: {
                            display: false
                        }
                    },
                    y: {
                        stacked: true,
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Storage Usage (GB)',
                            font: {
                                size: 14,
                                weight: 'bold',
                                family: 'Segoe UI'
                            },
                            color: '#374151'
                        },
                        ticks: {
                            color: '#6B7280',
                            font: {
                                size: 12,
                                family: 'Segoe UI'
                            },
                            callback: function(value) {
                                return value.toFixed(1) + ' GB';
                            }
                        },
                        grid: {
                            color: 'rgba(156, 163, 175, 0.2)',
                            lineWidth: 1
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: true,
                        position: 'top',
                        labels: {
                            usePointStyle: true,
                            padding: 20,
                            font: {
                                size: 13,
                                weight: '600',
                                family: 'Segoe UI'
                            },
                            color: '#374151',
                            boxWidth: 12,
                            boxHeight: 12
                        }
                    },
                    tooltip: {
                        enabled: true,
                        backgroundColor: 'rgba(0, 0, 0, 0.9)',
                        titleColor: '#FFFFFF',
                        bodyColor: '#FFFFFF',
                        borderColor: 'rgba(156, 163, 175, 0.3)',
                        borderWidth: 1,
                        cornerRadius: 8,
                        displayColors: true,
                        titleFont: {
                            size: 14,
                            weight: 'bold'
                        },
                        bodyFont: {
                            size: 13
                        },
                        animation: {
                            duration: 200
                        },
                        callbacks: {
                            title: function(context) {
                                return '📁 ' + context[0].label;
                            },
                            label: function(context) {
                                const machineIndex = context.dataIndex;
                                const isIncremental = context.dataset.label.includes('Incremental');
                                const icon = isIncremental ? '🔴' : '🟢';
                                const size = context.parsed.y.toFixed(2);
                                const count = isIncremental ? incrementalCounts[machineIndex] : fullCounts[machineIndex];
                                const fileText = count === 1 ? 'file' : 'files';
                                
                                return [
                                    icon + ' ' + context.dataset.label + ':',
                                    '   💾 ' + size + ' GB (' + count + ' ' + fileText + ')'
                                ];
                            },
                            footer: function(context) {
                                const machineIndex = context[0].dataIndex;
                                const totalSize = context.reduce((sum, item) => sum + item.parsed.y, 0);
                                const totalFiles = incrementalCounts[machineIndex] + fullCounts[machineIndex];
                                const avgFileSize = totalFiles > 0 ? (totalSize / totalFiles).toFixed(2) : '0.00';
                                
                                return [
                                    '📊 Total Storage: ' + totalSize.toFixed(2) + ' GB',
                                    '📁 Total Files: ' + totalFiles + ' backups',
                                    '📈 Avg File Size: ' + avgFileSize + ' GB'
                                ];
                            }
                        }
                    }
                }
            }
        });

        // Store chart reference for scroll-triggered animation
        chart.chartId = canvasId;
        return chart;
    }
    
    // Repository and machine data for charts
    console.log('Initializing chart system...');
    const metricsData = {
"@

# Generate metrics data properly
$metricsDataLines = @()
foreach ($key in $StorageMetrics.MachineMetrics.Keys) {
    $metric = $StorageMetrics.MachineMetrics[$key]
    $metricsDataLines += "        '$key': { IncrementalBackupSizeGB: $([math]::Round($metric.IncrementalBackupSizeGB, 2)), FullBackupSizeGB: $([math]::Round($metric.FullBackupSizeGB, 2)), IncrementalBackupCount: $($metric.IncrementalBackupCount), FullBackupCount: $($metric.FullBackupCount) }"
}
$html += $metricsDataLines -join ",`n"

$html += @"
    };
    
    console.log('Metrics data loaded for', Object.keys(metricsData).length, 'machines');
    console.log('Valid repositories to create:', $($validRepositories.Count));
    
    // Create charts for each repository
"@

# Generate chart creation calls for valid repositories only
$html += @"
    
    // Store chart instances for animation
    const chartInstances = {};
    
    // Initialize charts when DOM is ready
    document.addEventListener('DOMContentLoaded', function() {
        console.log('DOM loaded, creating charts...');
        
"@

if ($validRepositories.Count -gt 0) {
    foreach ($repoInfo in $validRepositories) {
        $repository = $repoInfo.Repository
        $machineKeys = $repoInfo.MachineKeys
        $chartId = $repoInfo.ChartId
        
        $machineKeysJS = ($machineKeys | ForEach-Object { "'$_'" }) -join ', '
        $html += "        console.log('Creating chart for repository: $($repository.Name) with ID: $chartId');`n"
        $html += "        const chart$chartId = createChart('$chartId', 'Repository: $($repository.Name)', [$machineKeysJS], metricsData);`n"
        $html += "        if (chart$chartId) chartInstances['$chartId'] = chart$chartId;`n"
    }
} else {
    $html += "        console.log('No valid repositories found for chart creation');`n"
}

$html += @"
        
        // Set up Intersection Observer for scroll-triggered animations
        const observerOptions = {
            threshold: 0.3, // Trigger when 30% of the chart is visible
            rootMargin: '0px 0px -50px 0px' // Start animation 50px before chart enters viewport
        };
        
        const chartObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const chartContainer = entry.target;
                    const chartId = chartContainer.getAttribute('data-chart-id');
                    
                    // Add visible class for CSS animation
                    chartContainer.classList.add('chart-visible');
                    
                    // Trigger Chart.js animation
                    if (chartInstances[chartId]) {
                        console.log('Animating chart:', chartId);
                        
                        // Update chart with staggered animation
                        chartInstances[chartId].update({
                            duration: 2000,
                            easing: 'easeInOutQuart',
                            delay: function(ctx) {
                                return ctx.dataIndex * 150; // Stagger animation
                            }
                        });
                    }
                    
                    // Stop observing this chart (animate only once)
                    chartObserver.unobserve(chartContainer);
                }
            });
        }, observerOptions);
        
        // Observe all chart containers
        document.querySelectorAll('.chart-animate').forEach(container => {
            chartObserver.observe(container);
        });
        
        console.log('Chart scroll animation system initialized');
    });
"@

$html += @"
    </script>
</body>
</html>
"@
    
    # Save the report (overwrite if exists)
    $html | Out-File -FilePath $OutputPath -Encoding UTF8 -Force
    
    return $OutputPath
}

Export-ModuleMember -Function New-HTMLReport 