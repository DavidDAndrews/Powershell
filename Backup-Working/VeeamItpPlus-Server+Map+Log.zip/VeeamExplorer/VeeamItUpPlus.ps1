# =====================
# All Function Definitions (move to very top)
# =====================
function Write-Log {
    param(
        [string]$Message,
        [ValidateSet('CRITICAL','FAILURE','WARNING','INFORMATIONAL','ALL')][string]$Level = 'INFORMATIONAL'
    )
    # Append green checkmark if message contains 'succeeded' or 'successfully'
    if ($Message -match '(?i)\bsucceeded\b|\bsuccessfully\b') {
        $Message += ' ✅'
    }
    $entry = [PSCustomObject]@{
        Timestamp = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff')
        Level = $Level
        Message = $Message
    }
    $script:LogBuffer += $entry
    $script:HtmlLogBuffer += $entry
    
    # Throttled HTML update - only update every 500ms to prevent excessive I/O
    $now = Get-Date
    if (-not $script:LastHtmlUpdate) { 
        $script:LastHtmlUpdate = $now.AddSeconds(-1) 
    }
    
    $timeSinceLastUpdate = ($now - $script:LastHtmlUpdate).TotalMilliseconds
    $shouldUpdate = ($timeSinceLastUpdate -gt 500) -or ($Level -in @('CRITICAL', 'FAILURE'))
    
    if ($script:LogFilePath -and $script:HtmlLogBuffer.Count -gt 0 -and $shouldUpdate) {
        Update-HTMLLog
        $script:LastHtmlUpdate = $now
    }
    
    # No console output for any log level
    # (All logs go to HTML only)
}
function Update-HTMLLog {
    # Quick HTML log update
    if (-not $script:LogFilePath) { return }
    
    try {
        $logEntries = $script:HtmlLogBuffer
        $sessionTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss.fff"
        $lastUpdate = Get-Date -Format "HH:mm:ss"
        
        # Generate just the log entries HTML
        $logEntriesHtml = ""
        $entryNumber = 1
        foreach ($entry in $logEntries) {
            $levelClass = switch ($entry.Level) {
                'CRITICAL' { 'error' }
                'FAILURE' { 'warning' }
                'WARNING' { 'warning' }
                'INFORMATIONAL' { 'info' }
                default { 'info' }
            }
            $logEntriesHtml += "<div class='log-entry $levelClass'><span class='log-number' style='font-weight:bold;color:#6366F1;margin-right:10px;'>$entryNumber.</span><span class='timestamp'>$($entry.Timestamp)</span><span class='message'>$($entry.Message)</span></div>"
            $entryNumber++
        }
        
        # Create complete HTML with auto-refresh
        $html = @"
<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>VeeamItUp+ Activity Log</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; padding: 20px; }
        .container { max-width: 80vw; width: 80vw; margin: 0 auto; background: white; border-radius: 15px; box-shadow: 0 4px 20px rgba(0,0,0,0.1); overflow: hidden; }
        .header { background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%); color: white; padding: 30px; text-align: center; }
        .header h1 { font-size: 2.5em; margin-bottom: 10px; font-weight: 300; }
        .status-bar { background: #F8F9FA; padding: 15px 30px; border-bottom: 1px solid #E9ECEF; display: flex; justify-content: space-between; align-items: center; }
        .log-container { padding: 30px; max-height: 70vh; overflow-y: auto; }
        .log-entry { padding: 12px 20px; margin-bottom: 8px; border-radius: 8px; background: #F9FAFB; border-left: 4px solid #E5E7EB; animation: slideIn 0.3s ease; }
        .log-entry.info { border-left-color: #3B82F6; }
        .log-entry.success { border-left-color: #10B981; }
        .log-entry.warning { border-left-color: #F59E0B; }
        .log-entry.error { border-left-color: #EF4444; }
        .log-entry.menu { border-left-color: #8B5CF6; background: #F3F4F6; }
        .log-entry.input { border-left-color: #06B6D4; background: #ECFEFF; }
        .timestamp { font-family: 'Consolas', monospace; font-size: 0.85em; color: #6B7280; margin-right: 15px; }
        .message { color: #1F2937; }
        .menu-text { font-weight: bold; color: #4C1D95; }
        .input-text { font-weight: bold; color: #0E7490; }
        @keyframes slideIn { from { opacity: 0; transform: translateX(-20px); } to { opacity: 1; transform: translateX(0); } }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🚀 VeeamItUp+ Activity Log</h1>
            <p>Activity monitoring and logging</p>
        </div>
        <div class="status-bar">
            <div style="display: flex; align-items: center; gap: 10px;">
                <button onclick="window.scrollTo(0,0)" style="padding: 8px 18px; font-size: 1em; border-radius: 6px; border: none; background: #10B981; color: white; font-weight: bold; cursor: pointer;">⏮ First</button>
                <button onclick="location.reload()" style="padding: 8px 18px; font-size: 1em; border-radius: 6px; border: none; background: #3B82F6; color: white; font-weight: bold; cursor: pointer;">🔄 Refresh</button>
                <button onclick="window.scrollTo(0,document.body.scrollHeight)" style="padding: 8px 18px; font-size: 1em; border-radius: 6px; border: none; background: #F59E0B; color: white; font-weight: bold; cursor: pointer;">⏭ Last</button>
            </div>
            <div>
                <span>Session: $sessionTime | Last Update: $lastUpdate</span>
            </div>
        </div>
        <div style="padding: 20px 30px 0 30px;">
            <label for="levelFilter"><b>Show entries at or above:</b></label>
            <select id="levelFilter" onchange="filterLog()" style="margin-left: 10px;">
                <option value="ALL">ALL</option>
                <option value="CRITICAL">CRITICAL</option>
                <option value="FAILURE">FAILURE</option>
                <option value="WARNING">WARNING</option>
                <option value="INFORMATIONAL">INFORMATIONAL</option>
            </select>
        </div>
        <div class="log-container" id="logContainer">
$logEntriesHtml
        </div>
    </div>
    <script>
        const levelOrder = { 'ALL': 0, 'INFORMATIONAL': 1, 'WARNING': 2, 'FAILURE': 3, 'CRITICAL': 4 };
        
        function filterLog() {
            const sel = document.getElementById('levelFilter').value;
            const entries = document.querySelectorAll('.log-entry');
            entries.forEach(entry => {
                const classList = entry.className.split(' ');
                let level = 'INFORMATIONAL';
                if (classList.includes('error')) level = 'CRITICAL';
                else if (classList.includes('warning')) level = 'WARNING';
                else if (classList.includes('info')) level = 'INFORMATIONAL';
                if (sel === 'ALL' || levelOrder[level] >= levelOrder[sel]) {
                    entry.style.display = '';
                } else {
                    entry.style.display = 'none';
                }
            });
        }
        
        // Auto-scroll to bottom on load
        window.addEventListener('load', function() {
            const logContainer = document.getElementById('logContainer');
            logContainer.scrollTop = logContainer.scrollHeight;
        });
        
        filterLog();
    </script>
</body>
</html>
"@
        
        $html | Out-File -FilePath $script:LogFilePath -Encoding UTF8 -Force
    } catch {
        # Silently ignore errors during HTML update to avoid recursive logging
    }
}
function Generate-HTMLActivityLog {
    $now = Get-Date
    $fileName = "VeeamItUpPlusLog-" + $now.ToString("yyyy-MMM-dd-ddd-hhmmtt").Replace(":","") + ".html"
    $downloads = Join-Path $env:USERPROFILE "Downloads"
    $logPath = Join-Path $downloads $fileName
    $logEntries = $script:HtmlLogBuffer
    $sessionTime = $now.ToString("yyyy-MM-dd HH:mm:ss.fff")
    $html = @"
<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>VeeamItUp+ Activity Log</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; padding: 20px; }
        .container { max-width: 80vw; width: 80vw; margin: 0 auto; background: white; border-radius: 15px; box-shadow: 0 4px 20px rgba(0,0,0,0.1); overflow: hidden; }
        .header { background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%); color: white; padding: 30px; text-align: center; }
        .header h1 { font-size: 2.5em; margin-bottom: 10px; font-weight: 300; }
        .status-bar { background: #F8F9FA; padding: 15px 30px; border-bottom: 1px solid #E9ECEF; display: flex; justify-content: space-between; align-items: center; }
        .log-container { padding: 30px; max-height: 70vh; overflow-y: auto; }
        .log-entry { padding: 12px 20px; margin-bottom: 8px; border-radius: 8px; background: #F9FAFB; border-left: 4px solid #E5E7EB; animation: slideIn 0.3s ease; }
        .log-entry.info { border-left-color: #3B82F6; }
        .log-entry.success { border-left-color: #10B981; }
        .log-entry.warning { border-left-color: #F59E0B; }
        .log-entry.error { border-left-color: #EF4444; }
        .log-entry.menu { border-left-color: #8B5CF6; background: #F3F4F6; }
        .log-entry.input { border-left-color: #06B6D4; background: #ECFEFF; }
        .timestamp { font-family: 'Consolas', monospace; font-size: 0.85em; color: #6B7280; margin-right: 15px; }
        .message { color: #1F2937; }
        .menu-text { font-weight: bold; color: #4C1D95; }
        .input-text { font-weight: bold; color: #0E7490; }
        @keyframes slideIn { from { opacity: 0; transform: translateX(-20px); } to { opacity: 1; transform: translateX(0); } }
        .refresh-toggle { margin-left: 18px; font-size: 1em; display: inline-flex; align-items: center; gap: 6px; }
        .refresh-toggle input[type=checkbox] { accent-color: #3B82F6; width: 18px; height: 18px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🚀 VeeamItUp+ Activity Log</h1>
            <p>Activity monitoring and logging</p>
        </div>
        <div class="status-bar">
            <div style="display: flex; align-items: center; gap: 10px;">
                <button id="firstBtn" style="padding: 8px 18px; font-size: 1em; border-radius: 6px; border: none; background: #10B981; color: white; font-weight: bold; cursor: pointer;">⏮ First</button>
                <button id="refreshBtn" style="padding: 8px 18px; font-size: 1em; border-radius: 6px; border: none; background: #3B82F6; color: white; font-weight: bold; cursor: pointer;">🔄 Refresh</button>
                <button id="lastBtn" style="padding: 8px 18px; font-size: 1em; border-radius: 6px; border: none; background: #F59E0B; color: white; font-weight: bold; cursor: pointer;">⏭ Last</button>
            </div>
            <div>
                <span>Session: $sessionTime</span>
            </div>
        </div>
        <div style="padding: 20px 30px 0 30px;">
            <label for="levelFilter"><b>Show entries at or above:</b></label>
            <select id="levelFilter" onchange="filterLog()" style="margin-left: 10px;">
                <option value="ALL">ALL</option>
                <option value="CRITICAL">CRITICAL</option>
                <option value="FAILURE">FAILURE</option>
                <option value="WARNING">WARNING</option>
                <option value="INFORMATIONAL">INFORMATIONAL</option>
            </select>
        </div>
        <div class="log-container" id="logContainer">
"@
    $entryNumber = 1
    foreach ($entry in $logEntries) {
        # Map log level to class
        $levelClass = switch ($entry.Level) {
            'CRITICAL' { 'error' }
            'FAILURE' { 'warning' }
            'WARNING' { 'warning' }
            'INFORMATIONAL' { 'info' }
            default { 'info' }
        }
        $html += "<div class='log-entry $levelClass'><span class='log-number' style='font-weight:bold;color:#6366F1;margin-right:10px;'>$entryNumber.</span><span class='timestamp'>$($entry.Timestamp)</span><span class='message'>$($entry.Message)</span></div>"
        $entryNumber++
    }
    $html += @"
        </div>
    </div>
    <script>
        const levelOrder = { 'ALL': 0, 'INFORMATIONAL': 1, 'WARNING': 2, 'FAILURE': 3, 'CRITICAL': 4 };
        function filterLog() {
            const sel = document.getElementById('levelFilter').value;
            const entries = document.querySelectorAll('.log-entry');
            entries.forEach(entry => {
                const classList = entry.className.split(' ');
                let level = 'INFORMATIONAL';
                if (classList.includes('error')) level = 'CRITICAL';
                else if (classList.includes('warning')) level = 'WARNING';
                else if (classList.includes('info')) level = 'INFORMATIONAL';
                if (sel === 'ALL' || levelOrder[level] >= levelOrder[sel]) {
                    entry.style.display = '';
                } else {
                    entry.style.display = 'none';
                }
            });
        }
        document.getElementById('levelFilter').addEventListener('change', filterLog);
        filterLog();
        // Auto-scroll to bottom only once on load
        window.addEventListener('load', function() {
            const logContainer = document.getElementById('logContainer');
            logContainer.scrollTop = logContainer.scrollHeight;
        });
        // --- Button logic ---
        document.getElementById('refreshBtn').addEventListener('click', function() {
            location.reload();
        });
        document.getElementById('firstBtn').addEventListener('click', function() {
            const logContainer = document.getElementById('logContainer');
            logContainer.scrollTop = 0;
        });
        document.getElementById('lastBtn').addEventListener('click', function() {
            const logContainer = document.getElementById('logContainer');
            logContainer.scrollTop = logContainer.scrollHeight;
        });
    </script>
</body>
</html>
"@
    $html | Out-File -FilePath $logPath -Encoding UTF8 -Force
    Write-Log "HTML activity log generated: $logPath" 'INFORMATIONAL'
}
function Keep-LastNLogs {
    param($N)
    $downloads = Join-Path $env:USERPROFILE "Downloads"
    $pattern = "VeeamItUpPlusLog-*.html"
    $logs = Get-ChildItem -Path $downloads -Filter $pattern | Sort-Object LastWriteTime -Descending
    if ($logs.Count -gt $N) {
        $logs | Select-Object -Skip $N | Remove-Item -Force
    }
}
function Get-AvailableDriveLetters {
    $all = 65..90 | ForEach-Object { [char]$_ }
    $used = (Get-PSDrive -PSProvider FileSystem).Name
    return $all | Where-Object { $_ -notin $used }
}
function New-NetworkDrive {
    param(
        $DriveLetter,
        $UNCPath,
        $Username,
        [System.Security.SecureString]$Password
    )
    
    # First, clean up any existing mapping to this drive letter
    Write-Log "🧹 Cleaning up any existing mapping to $DriveLetter..." 'INFORMATIONAL'
    $cleanupCmd = "net use $DriveLetter /delete /yes"
    $cleanupResult = Invoke-Expression $cleanupCmd 2>&1
    # Don't worry about cleanup errors - drive might not be mapped
    
    # Test UNC path accessibility first
    Write-Log "🔍 Testing UNC path accessibility: $UNCPath" 'INFORMATIONAL'
    try {
        if (-not (Test-Path $UNCPath -ErrorAction SilentlyContinue)) {
            Write-Log "⚠️ UNC path $UNCPath is not accessible from this machine" 'WARNING'
        }
    } catch {
        Write-Log "⚠️ Error testing UNC path: $_" 'WARNING'
    }
    
    # Convert SecureString to plain text for net use
    $BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($Password)
    $plainPassword = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($BSTR)
    [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($BSTR)
    
    # Build command (don't log password for security)
    $cmd = "net use $DriveLetter `"$UNCPath`" /user:`"$Username`" `"$plainPassword`" /persistent:no"
    Write-Log "🔗 Executing drive mapping: net use $DriveLetter `"$UNCPath`" /user:`"$Username`" [PASSWORD HIDDEN] /persistent:no" 'INFORMATIONAL'
    
    # Execute the mapping command
    $result = Invoke-Expression $cmd 2>&1
    
    if ($LASTEXITCODE -eq 0) {
        Write-Log "✅ Drive mapped successfully: $DriveLetter -> $UNCPath" 'INFORMATIONAL'
        
        # Verify the mapping worked by testing the drive
        if (Test-Path $DriveLetter) {
            Write-Log "✅ Drive verification successful: $DriveLetter is accessible" 'INFORMATIONAL'
        return $true
    } else {
            Write-Log "❌ Drive mapping appeared successful but $DriveLetter is not accessible" 'FAILURE'
        return $false
    }
    } else {
        Write-Log "❌ Failed to map drive $DriveLetter to $UNCPath" 'FAILURE'
        Write-Log "❌ Net use error details: $result" 'FAILURE'
        
        # Provide specific error guidance based on common errors
        $errorString = $result.ToString()
        if ($errorString -match "System error 5") {
            Write-Log "💡 Error 5 = Access Denied. Check username/password or permissions." 'WARNING'
        } elseif ($errorString -match "System error 53") {
            Write-Log "💡 Error 53 = Network path not found. Check UNC path and network connectivity." 'WARNING'
        } elseif ($errorString -match "System error 67") {
            Write-Log "💡 Error 67 = Network name not found. Check server name and network connectivity." 'WARNING'
        } elseif ($errorString -match "System error 86") {
            Write-Log "💡 Error 86 = Invalid password. Check password accuracy." 'WARNING'
        } elseif ($errorString -match "System error 1326") {
            Write-Log "💡 Error 1326 = Logon failure. Check username and password." 'WARNING'
        }
        
        return $false
    }
}
function Remove-NetworkDrive {
    param($DriveLetter)
    $cmd = "net use $DriveLetter /delete /yes"
    Write-Log "Unmapping drive: $cmd" 'INFORMATIONAL'
    $result = Invoke-Expression $cmd 2>&1
    if ($LASTEXITCODE -eq 0) {
        Write-Log "Drive unmapped: $DriveLetter" 'INFORMATIONAL'
    } else {
        Write-Log "Failed to unmap drive: $result" 'WARNING'
    }
}
function Get-SavedServers {
    if (-not (Test-Path $script:RegRoot)) { return @() }
    $subkeys = Get-ChildItem -Path $script:RegRoot -ErrorAction SilentlyContinue | Where-Object { $_.PSIsContainer }
    $servers = @()
    foreach ($key in $subkeys) {
        $props = Get-ItemProperty -Path $key.PSPath -ErrorAction SilentlyContinue
        if ($props.UNCPath -and $props.Username -and $props.Password -and $props.DriveLetter) {
            $servers += [PSCustomObject]@{
                Key = $key.PSChildName
                UNCPath = $props.UNCPath
                Username = $props.Username
                Password = $props.Password
                DriveLetter = $props.DriveLetter
                ServerName = $props.ServerName
            }
        }
    }
    return $servers
}
function Save-ServerSettings {
    param($UNCPath, $Username, $Password, $DriveLetter, $KeyName, $ServerName)
    if (-not (Test-Path $script:RegRoot)) { New-Item -Path $script:RegRoot -Force | Out-Null }
    $key = Join-Path $script:RegRoot $KeyName
    if (-not (Test-Path $key)) { New-Item -Path $key -Force | Out-Null }
    Set-ItemProperty -Path $key -Name "UNCPath" -Value $UNCPath -Force
    Set-ItemProperty -Path $key -Name "Username" -Value $Username -Force
    Set-ItemProperty -Path $key -Name "Password" -Value (ConvertTo-EncryptedString $Password) -Force
    Set-ItemProperty -Path $key -Name "DriveLetter" -Value $DriveLetter -Force
    Set-ItemProperty -Path $key -Name "ServerName" -Value $ServerName -Force
    Write-Log "Settings saved for $UNCPath ($Username, $DriveLetter) in registry." 'INFORMATIONAL'
}
function Delete-ServerSettings {
    param($KeyName)
    $key = Join-Path $script:RegRoot $KeyName
    if (Test-Path $key) { Remove-Item -Path $key -Recurse -Force }
}
function Delete-AllServerSettings {
    if (Test-Path $script:RegRoot) { Remove-Item -Path $script:RegRoot -Recurse -Force }
}
function Load-ServerSettings {
    param($KeyName)
    $key = Join-Path $script:RegRoot $KeyName
    if (Test-Path $key) {
        $props = Get-ItemProperty -Path $key -ErrorAction SilentlyContinue
        if ($props.UNCPath -and $props.Username -and $props.Password -and $props.DriveLetter) {
            try {
                $decrypted = ConvertFrom-EncryptedString $props.Password
            } catch {
                Write-Log "Corrupt or invalid password in registry for $KeyName. Please re-enter credentials." 'FAILURE'
                return $null
            }
            return @{ UNCPath = $props.UNCPath; Username = $props.Username; Password = $decrypted; DriveLetter = $props.DriveLetter }
        }
    }
    return $null
}
function Sanitize-KeyName {
    param($UNCPath, $Username)
    # Use a hash for uniqueness and to avoid invalid chars
    $raw = "$UNCPath|$Username"
    $hash = [System.BitConverter]::ToString((New-Object -TypeName System.Security.Cryptography.SHA1Managed).ComputeHash([System.Text.Encoding]::UTF8.GetBytes($raw))).Replace("-","")
    return $hash
}
function ConvertTo-EncryptedString {
    param([string]$PlainText)
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($PlainText)
    $enc = [System.Security.Cryptography.ProtectedData]::Protect($bytes, $null, 'CurrentUser')
    return [Convert]::ToBase64String($enc)
}
function ConvertFrom-EncryptedString {
    param([string]$EncryptedText)
    try {
        $bytes = [Convert]::FromBase64String($EncryptedText)
        $dec = [System.Security.Cryptography.ProtectedData]::Unprotect($bytes, $null, 'CurrentUser')
        if (-not $dec) { throw 'Decryption returned null.' }
        return [System.Text.Encoding]::UTF8.GetString($dec)
    } catch {
        throw "Failed to decrypt password: $_"
    }
}
function Find-Repositories {
    param($RootPath)
    $repos = @{}
    $adhoc = @{}
    $allBackupFiles = Get-ChildItem -Path $RootPath -Recurse -Include *.vbk,*.vib,*.vrb -File -ErrorAction SilentlyContinue
    $machineFolders = @{}
    foreach ($file in $allBackupFiles) {
        $parent = $file.Directory.FullName
        if (-not $machineFolders.ContainsKey($parent)) {
            $machineFolders[$parent] = @()
            Write-Log "🖥️ Found machine folder: $parent" 'INFORMATIONAL'
        }
        $machineFolders[$parent] += $file
        if ($file.Name -match '\.vbk$') {
            Write-Log "💾 Found VBK (Full Backup): $($file.FullName)" 'INFORMATIONAL'
        } elseif ($file.Name -match '\.vib$') {
            Write-Log "📈 Found VIB (Incremental Backup): $($file.FullName)" 'INFORMATIONAL'
        } elseif ($file.Name -match '\.vrb$') {
            Write-Log "🔄 Found VRB (Reverse Incremental): $($file.FullName)" 'INFORMATIONAL'
        }
    }
    # Find all candidate repo folders (folders whose immediate children are machine folders with backup files)
    $repoCandidates = @{}
    foreach ($folder in $machineFolders.Keys) {
        $parentFolder = Split-Path $folder -Parent
        if (-not $repoCandidates.ContainsKey($parentFolder)) {
            $repoCandidates[$parentFolder] = @()
        }
        $repoCandidates[$parentFolder] += $folder
    }
    $reposFound = @{}
    foreach ($repo in $repoCandidates.Keys) {
        # A repo is a folder with 2+ machine subfolders containing backup files
        $machineSubfolders = $repoCandidates[$repo] | Where-Object { $_ -ne $repo }
        if ($machineSubfolders.Count -ge 2) {
            $reposFound[$repo] = $machineSubfolders
        }
    }
    # Build repo structure
    $repoResults = @{}
    $adhocMachines = @{}
    foreach ($repo in $reposFound.Keys) {
        $repoName = Split-Path $repo -Leaf
        $repoResults[$repoName] = @{}
        foreach ($machineFolder in $reposFound[$repo]) {
            $vmName = Split-Path $machineFolder -Leaf
            $repoResults[$repoName][$vmName] = $machineFolders[$machineFolder]
        }
    }
    # Now, any machine folder not in a detected repo is AD-Hoc
    $allRepoMachineFolders = $reposFound.Values | ForEach-Object { $_ } | Select-Object -Unique
    foreach ($machineFolder in $machineFolders.Keys) {
        if ($machineFolder -notin $allRepoMachineFolders) {
            $vmName = Split-Path $machineFolder -Leaf
            $adhocMachines[$vmName] = $machineFolders[$machineFolder]
        }
    }
    return @{ Repositories = $repoResults; AdHoc = $adhocMachines }
}
function Analyze-RepoBackups {
    param($RepoStructure)
    $result = @{}
    foreach ($repoName in $RepoStructure.Repositories.Keys) {
        $result[$repoName] = @{}
        foreach ($vm in $RepoStructure.Repositories[$repoName].Keys) {
            $files = $RepoStructure.Repositories[$repoName][$vm]
            $result[$repoName][$vm] = Analyze-Backups -Files $files
        }
    }
    if ($RepoStructure.AdHoc.Count -gt 0) {
        $result['AD-Hoc Backups'] = @{}
        foreach ($vm in $RepoStructure.AdHoc.Keys) {
            $files = $RepoStructure.AdHoc[$vm]
            $result['AD-Hoc Backups'][$vm] = Analyze-Backups -Files $files
        }
    }
    return $result
}
function Generate-HTMLReport {
    param($RepoResults, $OutputPath)
    $html = "<html><head><title>VeeamItUp+ Report</title></head><body><h1>VeeamItUp+ Report</h1>"
    foreach ($repoName in $RepoResults.Keys) {
        $html += "<h2>Repository: $repoName</h2>"
        foreach ($vm in $RepoResults[$repoName].Keys) {
            $m = $RepoResults[$repoName][$vm]
            $html += "<h3>$vm</h3><ul>"
            $html += "<li>Full backups: $($m.Full.Count)</li>"
            $html += "<li>Incremental backups: $($m.Incr.Count)</li>"
            $html += "<li>Total size: $([math]::Round($m.TotalSize/1GB,2)) GB</li>"
            $html += "<li>Last backup: $($m.LastBackup)</li>"
            $html += "</ul>"
        }
    }
    $html += "</body></html>"
    $html | Out-File -FilePath $OutputPath -Encoding UTF8 -Force
    Write-Log "HTML report generated: $OutputPath" 'INFORMATIONAL'
}
function Analyze-Backups {
    param($Files)
    $result = @{ Full = @(); Incr = @(); TotalSize = 0; LastBackup = $null }
    foreach ($file in $Files) {
        if ($file.Name -match '\.vbk$') {
            $result.Full += $file
            Write-Log "💾 Analyzing VBK (Full Backup): $($file.FullName)" 'INFORMATIONAL'
        } elseif ($file.Name -match '\.vib$') {
            $result.Incr += $file
            Write-Log "📈 Analyzing VIB (Incremental Backup): $($file.FullName)" 'INFORMATIONAL'
        } elseif ($file.Name -match '\.vrb$') {
            Write-Log "🔄 Analyzing VRB (Reverse Incremental): $($file.FullName)" 'INFORMATIONAL'
        }
        $result.TotalSize += $file.Length
        if (-not $result.LastBackup -or $file.LastWriteTime -gt $result.LastBackup) { $result.LastBackup = $file.LastWriteTime }
    }
    return $result
}
function Test-ServerConnectivity {
    param(
        [string]$ServerName,
        [string]$UNCPath,
        [int]$TimeoutSeconds = 3
    )
    
    Write-Log "🔍 Testing connectivity to $ServerName (timeout: ${TimeoutSeconds}s)" 'INFORMATIONAL'
    $allPassed = $true
    
    # 1. Quick ping test
    try {
        $pingResult = Test-Connection -ComputerName $ServerName -Count 1 -TimeToLive 10 -Quiet -ErrorAction Stop
        if ($pingResult) {
            Write-Log "📶 Ping to $ServerName succeeded." 'INFORMATIONAL'
        } else {
            Write-Log "⚠️ Ping to $ServerName failed." 'WARNING'
            $allPassed = $false
        }
    } catch {
        Write-Log "⚠️ Ping test to $ServerName failed: $_" 'WARNING'
        $allPassed = $false
    }
    
    # 2. Port 445 test with timeout
    $port445 = $false
    try {
        $tcp = New-Object System.Net.Sockets.TcpClient
        $iar = $tcp.BeginConnect($ServerName, 445, $null, $null)
        $success = $iar.AsyncWaitHandle.WaitOne(($TimeoutSeconds * 1000), $false)
        if ($success -and $tcp.Connected) {
            $tcp.EndConnect($iar)
            $tcp.Close()
            $port445 = $true
            Write-Log "🔌 Port 445 open on $ServerName." 'INFORMATIONAL'
        } else {
            Write-Log "⚠️ Port 445 not accessible on $ServerName (timeout or closed)." 'WARNING'
            $allPassed = $false
        }
        $tcp.Dispose()
    } catch {
        Write-Log "⚠️ Port 445 check failed for $ServerName`: $_" 'WARNING'
        $allPassed = $false
    }
    
    # 3. Skip UNC Path validation as it can be slow and unreliable
    # This will be tested during actual drive mapping
    Write-Log "ℹ️ UNC path validation skipped (will be tested during drive mapping)" 'INFORMATIONAL'
    
    Write-Log "🔍 Connectivity test completed for $ServerName" 'INFORMATIONAL'
    return $allPassed
}
function Show-Banner {
    $esc = [char]27
    $banner = @"
${esc}[40;92m┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
${esc}[40;92m┃                                                                              ┃
${esc}[40;92m┃                          VeeamItUp+                                          ┃
${esc}[40;92m┃                                                                              ┃
${esc}[40;92m┃   Version 1.0.0   |   Author: David Andrews   |   All Rights Reserved© $(Get-Date -Format 'yyyy')  ┃
${esc}[40;92m┃                                                                              ┃
${esc}[40;92m┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛${esc}[0m
"@
    Write-Host $banner
}
function Show-ReturnToMenuPrompt {
    param(
        [string]$Message = "Press any key to return to menu...",
        [string]$Color = "Cyan"
    )
    
    Write-Host ""
    Write-Host $Message -ForegroundColor $Color
    Write-Log "⏸️ $Message" 'INFORMATIONAL'
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    Write-Log "🔄 Returning to main menu..." 'INFORMATIONAL'
    Clear-Host
    Show-Banner
    Write-Host ""
}
function Run-ReportForMappedDrive {
    param(
        $DriveLetter
    )
    # Scan backups (repo-aware)
    $repoStruct = Find-Repositories -RootPath $DriveLetter
    $repoResults = Analyze-RepoBackups -RepoStructure $repoStruct
    $totalVMs = ($repoResults.Keys | ForEach-Object { $repoResults[$_].Count } | Measure-Object -Sum).Sum
    if ($totalVMs -eq 0) {
        Write-Log "No backup files found on $DriveLetter" 'WARNING'
        } else {
        Write-Log "Found $totalVMs machines with backups in $($repoResults.Keys.Count) repositories." 'INFORMATIONAL'
        # Generate report
        $reportPath = Join-Path $env:USERPROFILE "Downloads\VeeamItUp+-Report.html"
        Generate-HTMLReport -RepoResults $repoResults -OutputPath $reportPath
    }
    Remove-NetworkDrive -DriveLetter $DriveLetter
    Write-Log "🏁 ==== End of Session ====" 'INFORMATIONAL'
}
function Add-NewServerProfile {
    Write-Log "➕ Adding a new server profile." 'INFORMATIONAL'
        Write-Log "❓ Prompting user for UNC path to Veeam repository" 'INFORMATIONAL'
    $UNCPath = Read-Host "Enter UNC path to Veeam repository (e.g. \\server\share)"
        if ([string]::IsNullOrWhiteSpace($UNCPath)) {
            Write-Log "❌ UNC path is empty. Aborting add operation." 'FAILURE'
        return $false
        }
        if (-not $UNCPath.StartsWith("\\")) {
            Write-Log "❌ UNC path does not start with \\. Aborting add operation." 'FAILURE'
        return $false
        }
        Write-Log "📝 User entered UNC path: $UNCPath" 'INFORMATIONAL'
        Write-Log "❓ Prompting user for username" 'INFORMATIONAL'
        $Username = Read-Host "Enter username"
        if ([string]::IsNullOrWhiteSpace($Username)) {
            Write-Log "❌ Username is empty. Aborting add operation." 'FAILURE'
        return $false
        }
        Write-Log "📝 User entered username: $Username" 'INFORMATIONAL'
        Write-Log "❓ Prompting user for password (secure input)" 'INFORMATIONAL'
        $SecurePassword = Read-Host "Enter password" -AsSecureString
        if (-not $SecurePassword -or $SecurePassword.Length -eq 0) {
            Write-Log "❌ Password is empty. Aborting add operation." 'FAILURE'
        return $false
        }
        Write-Log "🔒 User entered password (hidden)." 'INFORMATIONAL'
    
    # Convert SecureString to plain string for registry storage
        $BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecurePassword)
        $Password = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($BSTR)
        [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($BSTR)
    
        $available = Get-AvailableDriveLetters
        Write-Log "🔍 Available drive letters: $($available -join ', ')" 'INFORMATIONAL'
    $suggested = if ($available -contains 'V') { 'V' } else { $available | Sort-Object | Select-Object -First 1 }
        do {
        $prompt = "Enter drive letter to use (choose one: $($available -join ', ')) [Suggested: $suggested]"
        Write-Log "❓ Prompting user for drive letter selection" 'INFORMATIONAL'
        $DriveLetterInput = Read-Host $prompt
        if ([string]::IsNullOrWhiteSpace($DriveLetterInput)) { $DriveLetterInput = $suggested }
        $DriveLetterInput = [string]$DriveLetterInput
            $DriveLetterInput = $DriveLetterInput.ToUpper()
            if ($DriveLetterInput.Length -ne 1 -or $DriveLetterInput -notin $available) {
                Write-Log "⚠️ Invalid drive letter entered: $DriveLetterInput" 'WARNING'
                Write-Log "⚠️ Invalid drive letter. Please try again." 'WARNING'
            }
        } while ($DriveLetterInput.Length -ne 1 -or $DriveLetterInput -notin $available)
        $DriveLetter = "$DriveLetterInput`:"
        Write-Log "💾 User selected drive letter: $DriveLetter" 'INFORMATIONAL'
    
        # Parse server name from UNC path
        $ServerName = $null
        if ($UNCPath -match '^\\\\([^\\]+)') { $ServerName = $matches[1] }
        $key = Sanitize-KeyName -UNCPath $UNCPath -Username $Username
        Write-Log "🔑 Generated registry key for new profile: $key" 'INFORMATIONAL'
    
    # Map the drive and run report generation
        Write-Log "🔗 Attempting to map drive $DriveLetter to $UNCPath for $Username..." 'INFORMATIONAL'
    if (New-NetworkDrive -DriveLetter $DriveLetter -UNCPath $UNCPath -Username $Username -Password $SecurePassword) {
            Write-Log "✅ Drive mapping succeeded. Saving new server profile to registry." 'INFORMATIONAL'
            Save-ServerSettings -UNCPath $UNCPath -Username $Username -Password $Password -DriveLetter $DriveLetter -KeyName $key -ServerName $ServerName
        Write-Log "✅ Running backup analysis and report generation." 'INFORMATIONAL'
        Run-ReportForMappedDrive -DriveLetter $DriveLetter
        Update-HTMLLog
        Keep-LastNLogs -N 3
        Write-Log "HTML activity log updated with new server profile and report generation" 'INFORMATIONAL'
        Show-ReturnToMenuPrompt "✅ New server profile added and report completed! Press any key to return to menu..." "Green"
        return $true
        } else {
            Write-Log "❌ Drive mapping failed. Server not saved to registry." 'FAILURE'
        return $false
    }
}
function Test-DriveMapping {
    param(
        $DriveLetter,
        $UNCPath,
        $Username
    )
    
    Write-Log "🔍 Running drive mapping diagnostics..." 'INFORMATIONAL'
    
    # Check if drive letter is already in use
    $existingDrives = Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue
    $driveInUse = $existingDrives | Where-Object { $_.Name -eq $DriveLetter.Replace(":","") }
    
    if ($driveInUse) {
        Write-Log "⚠️ Drive $DriveLetter is already mapped to: $($driveInUse.DisplayRoot)" 'WARNING'
    } else {
        Write-Log "✅ Drive $DriveLetter is available" 'INFORMATIONAL'
    }
    
    # Check network connectivity to server
    if ($UNCPath -match '^\\\\([^\\]+)') {
        $serverName = $matches[1]
        Write-Log "🌐 Testing connectivity to server: $serverName" 'INFORMATIONAL'
        
        try {
            $ping = Test-Connection -ComputerName $serverName -Count 1 -Quiet -ErrorAction SilentlyContinue
            if ($ping) {
                Write-Log "✅ Server $serverName is reachable" 'INFORMATIONAL'
            } else {
                Write-Log "❌ Server $serverName is not reachable" 'FAILURE'
            }
        } catch {
            Write-Log "⚠️ Could not test connectivity to $serverName" 'WARNING'
        }
    }
    
    # Show current network mappings
    Write-Log "📋 Current network drive mappings:" 'INFORMATIONAL'
    try {
        $netUseOutput = cmd /c "net use" 2>&1
        if ($netUseOutput) {
            $netUseOutput | ForEach-Object { 
                if ($_ -match "^\s*([A-Z]:)\s+(.+)$") {
                    Write-Log "   $($matches[1]) -> $($matches[2])" 'INFORMATIONAL'
                }
            }
        } else {
            Write-Log "   No network drives currently mapped" 'INFORMATIONAL'
        }
    } catch {
        Write-Log "   Could not retrieve network mappings" 'WARNING'
    }
}

# =====================
# Now do your startup logic
# =====================
Clear-Host
Show-Banner

$now = Get-Date
$script:LogFileName = "VeeamItUpPlusLog-" + $now.ToString("yyyy-MMM-dd-ddd-hhmmtt").Replace(":","") + ".html"
$script:DownloadsPath = Join-Path $env:USERPROFILE "Downloads"
$script:LogFilePath = Join-Path $script:DownloadsPath $script:LogFileName

$script:LogBuffer = @()
$script:HtmlLogBuffer = @()
$script:LogLevelOrder = @{ 'ALL'=0; 'INFORMATIONAL'=1; 'WARNING'=2; 'FAILURE'=3; 'CRITICAL'=4 }
$script:CurrentLogLevel = 'ALL'
$script:ConnectivityResults = @{}

Write-Log "🚀 VeeamItUp+ Console started" 'INFORMATIONAL'
Write-Log "🌐 Initializing HTML activity log..." 'INFORMATIONAL'
Update-HTMLLog  # Use the HTML log function
Keep-LastNLogs -N 3
Start-Process $script:LogFilePath
Write-Log "📱 HTML activity log opened in browser" 'INFORMATIONAL'

# =====================
# Section 0: Multi-Server Registry Management
# =====================
$script:RegRoot = "HKCU:\Software\VeeamItUpPlus"

# =====================
# Section 1: Startup Menu (now in a loop)
# =====================

while ($true) {
    $servers = Get-SavedServers
    Write-Log "🔍 Retrieved saved server profiles from registry. Count: $($servers.Count)" 'INFORMATIONAL'
    if ($servers.Count -gt 0) {
        Write-Log "📋 Displaying saved VeeamItUp+ server profiles to user." 'INFORMATIONAL'
        Write-Host ""
        Write-Log "📋 Saved VeeamItUp+ server profiles:" 'INFORMATIONAL'
        Write-Host "Saved VeeamItUp+ server profiles:" -ForegroundColor Cyan
        Write-Host ""
        
        try {
            $i = 1
            foreach ($s in $servers) {
                try {
                    $serverDisplay = $s.ServerName
                    if (-not $serverDisplay) {
                        # Fallback: parse from UNC if not present
                        if ($s.UNCPath -match '^\\\\([^\\]+)') { $serverDisplay = $matches[1] }
                        else { $serverDisplay = "Unknown Server" }
                    }
                    # Show server info with connectivity status if available
                    $connectivityIcon = ""
                    $connectivityColor = "White"
                    if ($script:ConnectivityResults.ContainsKey($serverDisplay)) {
                        if ($script:ConnectivityResults[$serverDisplay]) {
                            $connectivityIcon = " ⭐" # Pink star for servers that passed connectivity
                            $connectivityColor = "Magenta"
                        } else {
                            $connectivityIcon = " ❌" # Red X for servers that failed connectivity
                            $connectivityColor = "Red"
                        }
                    }
                    
                    Write-Log "$i.$connectivityIcon [Server: $serverDisplay | UNC: $($s.UNCPath)  [$($s.Username)]  Drive: $($s.DriveLetter)]" 'INFORMATIONAL'
                    
                    if ($connectivityIcon) {
                        Write-Host "$i." -NoNewline
                        Write-Host $connectivityIcon -ForegroundColor $connectivityColor -NoNewline
                        Write-Host " [Server: $serverDisplay | UNC: $($s.UNCPath)  [$($s.Username)]  Drive: $($s.DriveLetter)]"
                    } else {
                        Write-Host "$i. [Server: $serverDisplay | UNC: $($s.UNCPath)  [$($s.Username)]  Drive: $($s.DriveLetter)]"
                    }
                    $i++
                } catch {
                    Write-Log "⚠️ Error displaying server profile $i`: $_" 'WARNING'
                    Write-Log "$i. [Error loading server profile - check logs]" 'FAILURE'
                    Write-Host "$i. [Error loading server profile - check logs]" -ForegroundColor Red
                    $i++
                }
            }
        } catch {
            Write-Log "❌ Critical error displaying server profiles: $_" 'CRITICAL'
            Write-Log "❌ Error loading server profiles. Check HTML activity log for details." 'CRITICAL'
        }
        
        Write-Log "📝 Prompting user to select, add, or delete a server profile." 'INFORMATIONAL'
        
        # Debug: Ensure menu always displays
        Write-Log "🎯 Displaying main menu options for $($servers.Count) server(s)" 'INFORMATIONAL'
        
        Write-Log "═══════════════════════════════════════════════════════════════════════════════" 'INFORMATIONAL'
        Write-Log "                                    MENU OPTIONS                                   " 'INFORMATIONAL'
        Write-Log "═══════════════════════════════════════════════════════════════════════════════" 'INFORMATIONAL'
        Write-Log "  1-$($servers.Count): Select a server to map and run report" 'INFORMATIONAL'
        Write-Log "  A: Add new server profile" 'INFORMATIONAL'
        Write-Log "  C: Test server connectivity" 'INFORMATIONAL'
        Write-Log "  D: Delete server profiles" 'INFORMATIONAL'
        Write-Log "  Q: Quit application" 'INFORMATIONAL'
        Write-Log "═══════════════════════════════════════════════════════════════════════════════" 'INFORMATIONAL'
        
        Write-Host ""
        Write-Host "═══════════════════════════════════════════════════════════════════════════════" -ForegroundColor Cyan
        Write-Host "                                    MENU OPTIONS                                   " -ForegroundColor Cyan
        Write-Host "═══════════════════════════════════════════════════════════════════════════════" -ForegroundColor Cyan
        Write-Host "  1-$($servers.Count): Select a server to map and run report" -ForegroundColor White
        Write-Host "  A: Add new server profile" -ForegroundColor Green
        Write-Host "  C: Test server connectivity" -ForegroundColor Magenta
        Write-Host "  D: Delete server profiles" -ForegroundColor Red
        Write-Host "  Q: Quit application" -ForegroundColor Yellow
        Write-Host "═══════════════════════════════════════════════════════════════════════════════" -ForegroundColor Cyan
        Write-Host ""
        
        Write-Log "❓ Prompting user to choose a menu option" 'INFORMATIONAL'
        $choice = Read-Host "Please choose an option"
        Write-Log "📝 User selected menu option: $choice" 'INFORMATIONAL'
        if ($choice -match '^[0-9]+$' -and [int]$choice -ge 1 -and [int]$choice -le $servers.Count) {
            $selected = $servers[[int]$choice-1]
            Write-Log "🔑 User selected profile: $($selected.ServerName) [$($selected.UNCPath)] ($($selected.Username))" 'INFORMATIONAL'
            $settings = Load-ServerSettings -KeyName $selected.Key
            if (-not $settings) { Write-Log "❌ Failed to load settings for selected profile. Continuing to menu." 'CRITICAL'; continue }
            $UNCPath = $settings.UNCPath
            $Username = $settings.Username
            $Password = $settings.Password
            $DriveLetter = $settings.DriveLetter
            if ([string]::IsNullOrWhiteSpace($Password)) {
                Write-Log "❌ Password loaded from registry is null or empty. Continuing to menu for security." 'FAILURE'
                continue
            }
            $SecurePassword = ConvertTo-SecureString $Password -AsPlainText -Force
            Write-Log "🔒 Loaded credentials and drive mapping for selected profile." 'WARNING'
            Write-Log "📋 UNC Path: $UNCPath" 'INFORMATIONAL'
            Write-Log "👤 Username: $Username" 'INFORMATIONAL'
            Write-Log "💾 Drive Letter: $DriveLetter" 'INFORMATIONAL'
            Write-Log "🔒 Password: ********" 'INFORMATIONAL'
            
            # Run diagnostics first
            Test-DriveMapping -DriveLetter $DriveLetter -UNCPath $UNCPath -Username $Username
            
            Write-Log "🔗 Starting drive mapping process..." 'INFORMATIONAL'
            
            # Map the drive and run report
            Write-Log "🔗 Attempting to map drive $DriveLetter to $UNCPath for $Username..." 'INFORMATIONAL'
            if (New-NetworkDrive -DriveLetter $DriveLetter -UNCPath $UNCPath -Username $Username -Password $SecurePassword) {
                Write-Log "✅ Drive mapping succeeded!" 'INFORMATIONAL'
                Write-Log "✅ Drive mapping succeeded. Running report generation." 'INFORMATIONAL'
                Write-Log "📊 Analyzing backup files and generating report..." 'INFORMATIONAL'
                Run-ReportForMappedDrive -DriveLetter $DriveLetter
                Write-Log "✅ Report generation completed!" 'INFORMATIONAL'
                Update-HTMLLog
                Keep-LastNLogs -N 3
                Write-Log "HTML activity log updated with report generation results" 'INFORMATIONAL'
                Show-ReturnToMenuPrompt "✅ Report completed! Press any key to return to menu..." "Green"
                continue
    } else {
                Write-Log "❌ Drive mapping failed!" 'FAILURE'
                Write-Log "❌ Drive mapping failed. Continuing to menu." 'FAILURE'
                Write-Log "💡 Troubleshooting tips:" 'WARNING'
                Write-Log "   • Check if the server is online and accessible" 'WARNING'
                Write-Log "   • Verify username and password are correct" 'WARNING'
                Write-Log "   • Ensure you have permission to access the UNC path" 'WARNING'
                Write-Log "   • Try accessing the UNC path directly in File Explorer first" 'WARNING'
                Write-Log "   • Check if any firewall or VPN is blocking the connection" 'WARNING'
                Write-Log "🔍 Check the HTML activity log for detailed error information." 'INFORMATIONAL'
                Show-ReturnToMenuPrompt "❌ Drive mapping failed. Press any key to return to menu..." "Red"
                continue
            }
        } elseif ($choice -eq 'A') {
            if (Add-NewServerProfile) {
                continue
            } else {
                continue
            }
        } elseif ($choice -eq 'C') {
            Write-Log "🔍 User chose to test server connectivity." 'INFORMATIONAL'
            Write-Log "🔍 Testing connectivity for all saved servers..." 'INFORMATIONAL'
            
            # Clear previous connectivity results
            $script:ConnectivityResults.Clear()
            
            foreach ($s in $servers) {
                $serverDisplay = $s.ServerName
                if (-not $serverDisplay) {
                    if ($s.UNCPath -match '^\\\\([^\\]+)') { $serverDisplay = $matches[1] }
                }
                
                Write-Log "🔍 Testing: $serverDisplay ($($s.UNCPath))" 'INFORMATIONAL'
                $testResult = Test-ServerConnectivity -ServerName $serverDisplay -UNCPath $s.UNCPath -TimeoutSeconds 5
                
                # Store the connectivity result
                $script:ConnectivityResults[$serverDisplay] = $testResult
                
                if ($testResult) {
                    Write-Log "✅ $serverDisplay is accessible" 'INFORMATIONAL'
                } else {
                    Write-Log "❌ $serverDisplay has connectivity issues" 'WARNING'
                }
            }
            
            Write-Log "🔍 Connectivity test completed. Refreshing menu display." 'INFORMATIONAL'
            Clear-Host
            Show-Banner
            Write-Host ""
            continue
        } elseif ($choice -eq 'D') {
            Write-Log "🗑️ User chose to delete a server profile." 'INFORMATIONAL'
            Write-Log "🗑️ Delete ALL or a specific server?" 'INFORMATIONAL'
            Write-Log "❓ Prompting user for delete choice" 'INFORMATIONAL'
            $delChoice = Read-Host "Enter number to delete a server, or ALL to delete all"
            Write-Log "📝 User selected delete option: $delChoice" 'INFORMATIONAL'
            if ($delChoice -eq 'ALL') {
                Write-Log "🗑️ Deleting ALL server profiles from registry." 'WARNING'
                Delete-AllServerSettings
                Show-ReturnToMenuPrompt "🗑️ All server profiles deleted. Press any key to return to menu..." "Yellow"
                continue
            } elseif ($delChoice -match '^[0-9]+$' -and [int]$delChoice -ge 1 -and [int]$delChoice -le $servers.Count) {
                $delKey = $servers[[int]$delChoice-1].Key
                Write-Log "🗑️ Deleting server profile with key: $delKey" 'WARNING'
                Delete-ServerSettings -KeyName $delKey
                Show-ReturnToMenuPrompt "🗑️ Server profile deleted. Press any key to return to menu..." "Yellow"
                continue
            } else {
                Write-Log "❌ Invalid delete choice entered: $delChoice. Continuing to menu." 'FAILURE'
                continue
            }
        } elseif ($choice -eq 'Q') {
            Write-Log "👋 User chose to quit the application." 'INFORMATIONAL'
            Write-Log "👋 Thank you for using VeeamItUp+!" 'INFORMATIONAL'
            Generate-HTMLActivityLog
            break
        } else {
            Write-Log "❌ Invalid menu choice entered: $choice. Continuing to menu." 'FAILURE'
            continue
        }
    } else {
        Write-Log "ℹ️ No saved server profiles found. Prompting user to add a new one." 'INFORMATIONAL'
        Write-Log "⚠️ No saved server profiles found." 'WARNING'
        
        Write-Log "═══════════════════════════════════════════════════════════════════════════════" 'INFORMATIONAL'
        Write-Log "                                    MENU OPTIONS                                   " 'INFORMATIONAL'
        Write-Log "═══════════════════════════════════════════════════════════════════════════════" 'INFORMATIONAL'
        Write-Log "  A: Add new server profile" 'INFORMATIONAL'
        Write-Log "  Q: Quit application" 'INFORMATIONAL'
        Write-Log "═══════════════════════════════════════════════════════════════════════════════" 'INFORMATIONAL'
        
        Write-Host "No saved server profiles found." -ForegroundColor Yellow
        Write-Host ""
        Write-Host "═══════════════════════════════════════════════════════════════════════════════" -ForegroundColor Cyan
        Write-Host "                                    MENU OPTIONS                                   " -ForegroundColor Cyan
        Write-Host "═══════════════════════════════════════════════════════════════════════════════" -ForegroundColor Cyan
        Write-Host "  A: Add new server profile" -ForegroundColor Green
        Write-Host "  Q: Quit application" -ForegroundColor Yellow
        Write-Host "═══════════════════════════════════════════════════════════════════════════════" -ForegroundColor Cyan
        Write-Host ""
        
        Write-Log "❓ Prompting user to choose a menu option (no servers scenario)" 'INFORMATIONAL'
        $choice = Read-Host "Please choose an option"
        Write-Log "📝 User selected menu option: $choice" 'INFORMATIONAL'
        if ($choice -eq 'A') {
            if (Add-NewServerProfile) {
                continue
            } else {
                continue
            }
        } elseif ($choice -eq 'Q') {
            Write-Log "👋 User chose to quit the application." 'INFORMATIONAL'
            Write-Log "👋 Thank you for using VeeamItUp+!" 'INFORMATIONAL'
            Generate-HTMLActivityLog
            break
        } else {
            Write-Log "❌ Invalid choice entered: $choice. Continuing to menu." 'FAILURE'
            continue
        }
    }
}

# End of script - all logic is now handled within the menu loop 