#Requires -Version 5.1

param(
    [Parameter(Mandatory=$true)]
    [string]$MappedDrive,
    
    [Parameter(Mandatory=$true)]
    [string]$UNCPath
)

Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# Import required modules
$ScriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path
Import-Module "$ScriptPath\Modules\BackupAnalyzer.psm1" -Force -DisableNameChecking
Import-Module "$ScriptPath\Modules\ReportGenerator.psm1" -Force -DisableNameChecking

# Script-level variables
# Ensure the mapped drive has a colon
if ($MappedDrive -notmatch ':$') {
    $MappedDrive = "${MappedDrive}:"
}
$script:MappedDrive = $MappedDrive
$script:UNCPath = $UNCPath

# Extract server name from UNC path and convert to uppercase
$script:ServerName = if ($UNCPath -match '^\\\\([^\\]+)') { 
    $matches[1].ToUpper() 
} else { 
    $env:COMPUTERNAME.ToUpper() 
}

$script:BackupRootPath = $null
$script:BackupInventory = @{}
$script:StorageMetrics = $null
$script:IsInitialScan = $true  # Track if this is the first scan

# XAML for the Report Generator window
[xml]$xaml = @"
<Window
    xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
    xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
    Title="Veeam Report Generator" WindowState="Maximized" MinHeight="700" MinWidth="1000"
    WindowStartupLocation="CenterScreen" 
    FontFamily="Segoe UI">
    
    <Window.Background>
        <LinearGradientBrush StartPoint="0,0" EndPoint="1,1">
            <GradientStop Color="#FF0B5394" Offset="0"/>
            <GradientStop Color="#FF1E88E5" Offset="0.5"/>
            <GradientStop Color="#FF42A5F5" Offset="1"/>
        </LinearGradientBrush>
    </Window.Background>
    
    <Grid Margin="25">
        <Grid.RowDefinitions>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="*"/>
            <RowDefinition Height="Auto"/>
        </Grid.RowDefinitions>

        <!-- Header Section -->
        <Border Grid.Row="0" Background="White" CornerRadius="15" Margin="0,0,0,20" Padding="25">
            <Border.Effect>
                <DropShadowEffect Color="Black" Opacity="0.2" ShadowDepth="5" BlurRadius="15"/>
            </Border.Effect>
            
            <StackPanel>
                <!-- Centered Title Section -->
                <StackPanel HorizontalAlignment="Center">
                    <TextBlock FontSize="32" FontWeight="Bold" 
                              Foreground="#0B5394" HorizontalAlignment="Center" TextAlignment="Center">
                        <Run Text="📊 Veeam Report Generator - "/>
                        <Run x:Name="runServerName" Text="" FontWeight="ExtraBold"/>
                    </TextBlock>
                    
                    <TextBlock FontSize="16" HorizontalAlignment="Center" TextAlignment="Center" 
                               Foreground="#546E7A" Margin="0,5,0,0">
                        <Run Text="{Binding ElementName=window, Path=Tag}" FontWeight="Bold" Foreground="#1565C0"/>
                    </TextBlock>
                </StackPanel>
            </StackPanel>
        </Border>



        <!-- Main Content Area -->
        <Border Grid.Row="1" Background="White" CornerRadius="15" Margin="0,0,0,20">
            <Border.Effect>
                <DropShadowEffect Color="Black" Opacity="0.2" ShadowDepth="5" BlurRadius="15"/>
            </Border.Effect>
            
            <TabControl x:Name="tabControl" Background="Transparent" BorderThickness="0" Margin="10">
                <!-- Scan Log Tab -->
                <TabItem>
                    <TabItem.Header>
                        <TextBlock Text="📋 Scan Log" FontWeight="SemiBold" FontSize="14"/>
                    </TabItem.Header>
                    
                    <ScrollViewer Margin="10">
                        <TextBox x:Name="txtScanLog" IsReadOnly="True" TextWrapping="Wrap" 
                                 Background="#F5F5F5" BorderThickness="0" Padding="10" 
                                 FontFamily="Consolas" FontSize="12" Foreground="#1F2937"/>
                    </ScrollViewer>
                </TabItem>
                
                <!-- Repository Overview Tab -->
                <TabItem>
                    <TabItem.Header>
                        <TextBlock Text="📊 Repository Overview" FontWeight="SemiBold" FontSize="14"/>
                    </TabItem.Header>
                    
                    <Grid Margin="10">
                        <Grid.RowDefinitions>
                            <RowDefinition Height="Auto"/>
                            <RowDefinition Height="*"/>
                        </Grid.RowDefinitions>
                        
                        <TextBlock Grid.Row="0" Text="Backup repository analysis will appear here after scan completes" 
                                   FontStyle="Italic" Foreground="#757575" HorizontalAlignment="Center" 
                                   VerticalAlignment="Center" Margin="0,20"/>
                        
                        <TreeView x:Name="treeBackups" Grid.Row="1" Visibility="Collapsed" 
                                  Background="#F5F5F5" BorderThickness="1" BorderBrush="#E0E0E0"/>
                    </Grid>
                </TabItem>
                

            </TabControl>
        </Border>

        <!-- Bottom Action Bar -->
        <Border Grid.Row="2" Background="White" CornerRadius="15" Padding="20">
            <Border.Effect>
                <DropShadowEffect Color="Black" Opacity="0.2" ShadowDepth="5" BlurRadius="15"/>
            </Border.Effect>
            
            <Grid>
                <Grid.ColumnDefinitions>
                    <ColumnDefinition Width="*"/>
                    <ColumnDefinition Width="Auto"/>
                    <ColumnDefinition Width="Auto"/>
                    <ColumnDefinition Width="Auto"/>
                    <ColumnDefinition Width="Auto"/>
                </Grid.ColumnDefinitions>
                
                <TextBlock Grid.Column="0" x:Name="txtSummary" Text="Ready to scan backup repository" 
                           VerticalAlignment="Center" FontSize="14" Foreground="#546E7A"/>
                
                <Button x:Name="btnScanNow" Grid.Column="1" Content="🔄 Rescan" 
                        Width="120" Height="35" Margin="0,0,10,0"
                        FontWeight="Bold" Foreground="White">
                    <Button.Template>
                        <ControlTemplate TargetType="Button">
                            <Border CornerRadius="18" Background="#4CAF50">
                                <Border.Effect>
                                    <DropShadowEffect Color="#4CAF50" Opacity="0.4" ShadowDepth="3" BlurRadius="10"/>
                                </Border.Effect>
                                <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
                            </Border>
                        </ControlTemplate>
                    </Button.Template>
                </Button>
                
                <Button x:Name="btnGenerateReport" Grid.Column="2" Content="📄 Generate Report" 
                        Width="140" Height="35" Margin="0,0,10,0" IsEnabled="False"
                        FontWeight="Bold" Foreground="White">
                    <Button.Template>
                        <ControlTemplate TargetType="Button">
                            <Border CornerRadius="18">
                                <Border.Style>
                                    <Style TargetType="Border">
                                        <Setter Property="Background" Value="#9E9E9E"/>
                                        <Style.Triggers>
                                            <DataTrigger Binding="{Binding IsEnabled, RelativeSource={RelativeSource AncestorType=Button}}" Value="True">
                                                <Setter Property="Background" Value="#2196F3"/>
                                            </DataTrigger>
                                        </Style.Triggers>
                                    </Style>
                                </Border.Style>
                                <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
                            </Border>
                        </ControlTemplate>
                    </Button.Template>
                </Button>
                
                <Button x:Name="btnSchedule" Grid.Column="3" Content="🕒 Schedule" 
                        Width="100" Height="35" Margin="0,0,10,0" IsEnabled="False"
                        FontWeight="Bold" Foreground="White">
                    <Button.Template>
                        <ControlTemplate TargetType="Button">
                            <Border CornerRadius="18">
                                <Border.Style>
                                    <Style TargetType="Border">
                                        <Setter Property="Background" Value="#9E9E9E"/>
                                        <Style.Triggers>
                                            <DataTrigger Binding="{Binding IsEnabled, RelativeSource={RelativeSource AncestorType=Button}}" Value="True">
                                                <Setter Property="Background" Value="#FF9800"/>
                                            </DataTrigger>
                                        </Style.Triggers>
                                    </Style>
                                </Border.Style>
                                <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
                            </Border>
                        </ControlTemplate>
                    </Button.Template>
                </Button>
                
                <Button x:Name="btnClose" Grid.Column="4" Content="❌ Close" 
                        Width="100" Height="35"
                        FontWeight="Bold" Foreground="White">
                    <Button.Template>
                        <ControlTemplate TargetType="Button">
                            <Border CornerRadius="18" Background="#F44336">
                                <Border.Effect>
                                    <DropShadowEffect Color="#F44336" Opacity="0.4" ShadowDepth="3" BlurRadius="10"/>
                                </Border.Effect>
                                <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
                            </Border>
                        </ControlTemplate>
                    </Button.Template>
                </Button>
            </Grid>
        </Border>
    </Grid>
</Window>
"@

# Function to log messages
function Write-Log {
    param(
        [string]$Message,
        [string]$Level = "INFO"
    )
    
    # Convert text levels to emojis
    $levelIcon = switch ($Level) {
        "INFO" { "ℹ️" }
        "STATUS" { "📋" }
        "ERROR" { "❌" }
        "WARNING" { "⚠️" }
        "SUCCESS" { "✅" }
        default { "ℹ️" }
    }
    
    $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $logEntry = "$timestamp $levelIcon $Message"
    
    if ($script:txtScanLog) {
        $script:txtScanLog.AppendText("$logEntry`r`n")
        $script:txtScanLog.ScrollToEnd()
    }
    
    # Also update summary for important messages
    if ($Level -eq "STATUS" -and $script:txtSummary) {
        $script:txtSummary.Text = $Message
    }
}

# Create the window
$reader = New-Object System.Xml.XmlNodeReader $xaml
$window = [Windows.Markup.XamlReader]::Load($reader)
$window.Tag = $script:UNCPath

# Get controls with null checking
$script:btnScanNow = $window.FindName("btnScanNow")
$script:txtScanLog = $window.FindName("txtScanLog")
$script:tabControl = $window.FindName("tabControl")
$script:treeBackups = $window.FindName("treeBackups")
# Storage Analysis tab removed
$script:txtSummary = $window.FindName("txtSummary")
$script:btnGenerateReport = $window.FindName("btnGenerateReport")
$script:btnSchedule = $window.FindName("btnSchedule")
$script:btnClose = $window.FindName("btnClose")
$script:runServerName = $window.FindName("runServerName")


# Log control initialization status
Write-Log "Initializing UI controls..."
if (-not $script:txtScanLog) { Write-Log "Warning: txtScanLog control not found" }
if (-not $script:runServerName) { Write-Log "Warning: runServerName control not found" }
if (-not $script:txtSummary) { Write-Log "Warning: txtSummary control not found" }

# Set the server name in the header and window title
if ($script:runServerName) {
    $script:runServerName.Text = $script:ServerName
}
$window.Title = "Veeam Report Generator - $script:ServerName"

# Update initial status to include server context
if ($script:txtSummary) {
    $script:txtSummary.Text = "Ready to scan backup repository on $script:ServerName"
}

# Function to find ALL backup locations on the drive (repositories + ADHOC)
function Find-AllBackupLocations {
    param([string]$RootPath)
    
    Write-Log "🔍 Starting comprehensive Veeam backup discovery on $RootPath" -Level "STATUS"
    
    # Validate that the root path exists
    if (-not (Test-Path $RootPath)) {
        Write-Log "❌ Error: Root path '$RootPath' does not exist or is not accessible" -Level "ERROR"
        return @{
            Repositories = @()
            AdhocBackups = @()
            TotalBackupFiles = 0
        }
    }
    
    $result = @{
        Repositories = @()
        AdhocBackups = @()
        TotalBackupFiles = 0
    }
    
    Write-Log "🔍 Scanning entire drive for VIB and VBK files..." -Level "STATUS"
    
    try {
        # First, find ALL VIB and VBK files on the drive
        $allBackupFiles = Get-ChildItem -Path $RootPath -Recurse -Include "*.vbk", "*.vib" -ErrorAction SilentlyContinue
        $result.TotalBackupFiles = $allBackupFiles.Count
        
        Write-Log "📊 Found $($allBackupFiles.Count) total backup files (.vbk/.vib) on the drive"
        
        if ($allBackupFiles.Count -eq 0) {
            Write-Log "⚠️ No Veeam backup files found on the drive" -Level "WARNING"
            return $result
        }
        
        # Group backup files by their parent directory
        $directoryGroups = $allBackupFiles | Group-Object { $_.Directory.FullName }
        
        Write-Log "📁 Backup files found in $($directoryGroups.Count) different directories"
        
        # First pass: Group all directories by their parent directory to identify potential repositories
        $parentDirectoryGroups = @{}
        
        foreach ($dirGroup in $directoryGroups) {
            $directory = $dirGroup.Name
            $parentPath = Split-Path $directory -Parent
            
            if (-not $parentDirectoryGroups.ContainsKey($parentPath)) {
                $parentDirectoryGroups[$parentPath] = @()
            }
            $parentDirectoryGroups[$parentPath] += $dirGroup
        }
        
        Write-Log "🔍 Analyzing $($parentDirectoryGroups.Count) potential repository locations..."
        
        # Analyze each parent directory to determine repositories vs ADHOC
        foreach ($parentPath in $parentDirectoryGroups.Keys) {
            $machineDirectoriesInParent = $parentDirectoryGroups[$parentPath]
            
            Write-Log "🔍 Checking parent: $parentPath ($($machineDirectoriesInParent.Count) machine directories)"
            
            # Check if this is the root drive (e.g., "V:\")
            $isRootDrive = $parentPath -match '^[A-Za-z]:\\?$'
            
            # If parent contains multiple machine directories with backups AND it's not the root drive, it's a repository
            if ($machineDirectoriesInParent.Count -gt 1 -and -not $isRootDrive) {
                # This is a repository
                $repositoryName = Split-Path $parentPath -Leaf
                if ([string]::IsNullOrEmpty($repositoryName)) {
                    $repositoryName = "Root-Repository"
                }
                
                Write-Log "✅ Repository detected: '$repositoryName' with $($machineDirectoriesInParent.Count) machines"
                
                # Create repository entry
                $newRepo = @{
                    Name = $repositoryName
                    Path = $parentPath
                    Type = "Repository"
                    Machines = @{}
                    TotalFiles = 0
                    TotalSizeGB = 0
                }
                $result.Repositories += $newRepo
                
                # Process each machine in this repository
                foreach ($dirGroup in $machineDirectoriesInParent) {
                    $directory = $dirGroup.Name
                    $filesInDir = $dirGroup.Group
                    $currentDirName = Split-Path $directory -Leaf
                    
                    Write-Log "  📦 Processing repository machine: $currentDirName ($($filesInDir.Count) files)"
                    
                    # Add machine to repository
                    $newRepo.Machines[$currentDirName] = @{
                        Name = $currentDirName
                        Path = $directory
                        FullBackups = @()
                        IncrementalBackups = @()
                        TotalSize = 0
                        LastBackupDate = $null
                    }
                    
                    $machineData = $newRepo.Machines[$currentDirName]
                    
                    # Process files for this machine
                    foreach ($file in $filesInDir) {
                        $backupInfo = @{
                            FileName = $file.Name
                            Size = $file.Length
                            SizeGB = [math]::Round($file.Length / 1GB, 2)
                            CreationTime = $file.CreationTime
                            LastWriteTime = $file.LastWriteTime
                            FullPath = $file.FullName
                        }
                        
                        if ($file.Extension -eq ".vbk") {
                            $machineData.FullBackups += $backupInfo
                            Write-Log "    📦 Repository Full: $($file.Name) ($($backupInfo.SizeGB) GB)"
                        }
                        else {
                            $machineData.IncrementalBackups += $backupInfo
                            Write-Log "    📈 Repository Incremental: $($file.Name) ($($backupInfo.SizeGB) GB)"
                        }
                        
                        $machineData.TotalSize += $file.Length
                        $newRepo.TotalFiles++
                        $newRepo.TotalSizeGB += $backupInfo.SizeGB
                    }
                    
                    # Update machine metrics
                    $machineData.TotalSizeGB = [math]::Round($machineData.TotalSize / 1GB, 2)
                    $allBackups = $machineData.FullBackups + $machineData.IncrementalBackups
                    if ($allBackups.Count -gt 0) {
                        $machineData.LastBackupDate = ($allBackups | Sort-Object LastWriteTime -Descending | Select-Object -First 1).LastWriteTime
                    }
                }
            }
            else {
                # Single machine directory OR root drive machines - these are ADHOC backups
                if ($isRootDrive) {
                    Write-Log "🎯 Root drive machines detected - treating as ADHOC: $parentPath ($($machineDirectoriesInParent.Count) directories)"
                } else {
                    Write-Log "🎯 Single machine directory detected - treating as ADHOC: $parentPath"
                }
                
                # Process all machine directories in this parent as ADHOC
                foreach ($dirGroup in $machineDirectoriesInParent) {
                    $directory = $dirGroup.Name
                    $filesInDir = $dirGroup.Group
                    
                    Write-Log "🎯 ADHOC backup location: $directory ($($filesInDir.Count) files)"
                    
                    foreach ($file in $filesInDir) {
                        $backupInfo = @{
                            FileName = $file.Name
                            Size = $file.Length
                            SizeGB = [math]::Round($file.Length / 1GB, 2)
                            CreationTime = $file.CreationTime
                            LastWriteTime = $file.LastWriteTime
                            FullPath = $file.FullName
                            Directory = $directory
                            Type = if ($file.Extension -eq ".vbk") { "Full" } else { "Incremental" }
                            BackupType = "ADHOC"
                        }
                        
                        $result.AdhocBackups += $backupInfo
                        Write-Log "    🎯 ADHOC $($backupInfo.Type): $($file.Name) ($($backupInfo.SizeGB) GB)"
                    }
                }
            }
        }
        
        # Summary logging
        Write-Log "📊 Discovery Summary:" -Level "STATUS"
        Write-Log "  📦 Repositories found: $($result.Repositories.Count) (excluding root drive)"
        foreach ($repo in $result.Repositories) {
            Write-Log "    🏢 $($repo.Name): $($repo.Machines.Count) machines, $($repo.TotalFiles) files, $([math]::Round($repo.TotalSizeGB, 1)) GB"
        }
        Write-Log "  🎯 ADHOC backups found: $($result.AdhocBackups.Count) files (individual files + root drive machines)"
        
        if ($result.AdhocBackups.Count -gt 0) {
            $adhocSizeGB = ($result.AdhocBackups | Measure-Object -Property SizeGB -Sum).Sum
            Write-Log "    💾 ADHOC total size: $([math]::Round($adhocSizeGB, 1)) GB"
        }
        
        return $result
    }
    catch {
        Write-Log "❌ Error during backup discovery: $_" -Level "ERROR"
        return $result
    }
}

# Function to process ALL backup locations and build inventory (replaces single repository scan)
function Invoke-AllBackupLocationsProcessing {
    param([string]$RootPath)
    
    Write-Log "🚀 Starting comprehensive backup scan on $RootPath" -Level "STATUS"
    
    # Clear existing inventory
    $script:BackupInventory = @{}
    $script:BackupLocations = $null
    
    try {
        # Discover all backup locations
        $script:BackupLocations = Find-AllBackupLocations -RootPath $RootPath
        
        if ($script:BackupLocations.TotalBackupFiles -eq 0) {
            Write-Log "❌ No Veeam backup files found on the drive" -Level "ERROR"
            return $false
        }
        
        # Process repository backups
        foreach ($repository in $script:BackupLocations.Repositories) {
            Write-Log "📦 Processing repository: $($repository.Name)"
            
            foreach ($machineName in $repository.Machines.Keys) {
                $machineData = $repository.Machines[$machineName]
                
                # Add repository information to machine data
                $machineData.RepositoryName = $repository.Name
                $machineData.RepositoryPath = $repository.Path
                $machineData.BackupType = "Repository"
                
                # Add to main inventory with unique key
                $inventoryKey = "$($repository.Name)::$machineName"
                $script:BackupInventory[$inventoryKey] = $machineData
                
                Write-Log "  ✅ Added repository machine: $inventoryKey ($($machineData.TotalSizeGB) GB)"
            }
        }
        
        # Process ADHOC backups - create "Ad-Hoc Backups" repository only if there are ADHOC backups
        if ($script:BackupLocations.AdhocBackups.Count -gt 0) {
            Write-Log "🎯 Processing ADHOC backups..."
            
            # Create a virtual "Ad-Hoc Backups" repository
            $adhocRepository = @{
                Name = "Ad-Hoc Backups"
                Path = "Various Locations"
                Type = "Repository"
                Machines = @{}
                TotalFiles = 0
                TotalSizeGB = 0
            }
            $script:BackupLocations.Repositories += $adhocRepository
            
            # Group ADHOC backups by extracted machine name or directory
            $adhocGroups = @{}
            
            foreach ($adhocBackup in $script:BackupLocations.AdhocBackups) {
                # Try to extract machine name from filename
                $machineName = $null
                $fileName = $adhocBackup.FileName
                
                # Common Veeam filename patterns
                if ($fileName -match '^(.+?)(\d{4}-\d{2}-\d{2}T\d{6})\.v[bi][kb]$') {
                    $machineName = $matches[1] -replace '[DWM]$', ''  # Remove schedule suffixes
                }
                elseif ($fileName -match '^(.+?)\.v[bi][kb]$') {
                    $machineName = $matches[1]
                }
                else {
                    # Fallback to directory name
                    $machineName = Split-Path $adhocBackup.Directory -Leaf
                }
                
                # Clean machine name
                $machineName = $machineName.Trim()
                if ([string]::IsNullOrEmpty($machineName)) {
                    $machineName = "Unknown-ADHOC"
                }
                
                # Group key includes directory to avoid conflicts - use unique identifier for ADHOC
                $uniqueKey = "$machineName-$(Split-Path $adhocBackup.Directory -Leaf)"
                
                if (-not $adhocGroups.ContainsKey($uniqueKey)) {
                    $adhocGroups[$uniqueKey] = @{
                        Name = $uniqueKey
                        Path = $adhocBackup.Directory
                FullBackups = @()
                IncrementalBackups = @()
                TotalSize = 0
                LastBackupDate = $null
                    }
                    $adhocRepository.Machines[$uniqueKey] = $adhocGroups[$uniqueKey]
                }
                
                $groupData = $adhocGroups[$uniqueKey]
                
                # Add backup to appropriate collection
                if ($adhocBackup.Type -eq "Full") {
                    $groupData.FullBackups += $adhocBackup
                }
                else {
                    $groupData.IncrementalBackups += $adhocBackup
                }
                
                $groupData.TotalSize += $adhocBackup.Size
                $adhocRepository.TotalFiles++
                $adhocRepository.TotalSizeGB += $adhocBackup.SizeGB
            }
            
            # Add ADHOC machines to inventory under "Ad-Hoc Backups" repository
            foreach ($uniqueKey in $adhocGroups.Keys) {
                $groupData = $adhocGroups[$uniqueKey]
                $groupData.TotalSizeGB = [math]::Round($groupData.TotalSize / 1GB, 2)
                
                # Find latest backup date
                $allBackups = $groupData.FullBackups + $groupData.IncrementalBackups
            if ($allBackups.Count -gt 0) {
                    $groupData.LastBackupDate = ($allBackups | Sort-Object LastWriteTime -Descending | Select-Object -First 1).LastWriteTime
                }
                
                # Add machine data with repository info
                $groupData.RepositoryName = "Ad-Hoc Backups"
                $groupData.RepositoryPath = "Various Locations"
                $groupData.BackupType = "Repository"
                
                # Add to main inventory with repository key format
                $inventoryKey = "Ad-Hoc Backups::$uniqueKey"
                $script:BackupInventory[$inventoryKey] = $groupData
                
                Write-Log "  🎯 Added ADHOC machine: $inventoryKey ($($groupData.TotalSizeGB) GB, $($allBackups.Count) files)"
            }
        }
        
        $totalMachines = $script:BackupInventory.Count
        $totalRepositories = $script:BackupLocations.Repositories.Count
        $totalAdhocGroups = ($script:BackupInventory.Keys | Where-Object { $_ -like "Ad-Hoc Backups::*" }).Count
        
        Write-Log "✅ Comprehensive scan completed successfully" -Level "STATUS"
        if ($totalAdhocGroups -gt 0) {
            Write-Log "📊 Total entities: $totalMachines ($($totalRepositories - 1) standard repositories, 1 ADHOC repository with $totalAdhocGroups groups)"
        } else {
            Write-Log "📊 Total entities: $totalMachines ($totalRepositories repositories, no ADHOC backups found)"
        }
        
        # Validate scan results
        if ($totalMachines -eq 0) {
            Write-Log "❌ No machines found during scan" -Level "ERROR"
            return $false
        }
        
        if ($totalRepositories -eq 0) {
            Write-Log "❌ No repositories were created during scan" -Level "ERROR"
            return $false
        }
        
        Write-Log "✅ Scan validation passed: $totalMachines machines in $totalRepositories repositories"
        return $true
    }
    catch {
        Write-Log "❌ Error during comprehensive backup scan: $_" -Level "ERROR"
        return $false
    }
}

# Button click handlers
$script:btnScanNow.Add_Click({
    if ($script:IsInitialScan) {
        Write-Log "🚀 Starting initial repository scan..." -Level "STATUS"
    } else {
        Write-Log "🔄 Starting repository rescan..." -Level "STATUS"
    }
    
    $script:btnScanNow.IsEnabled = $false
    $script:btnScanNow.Content = "⏳ Scanning..."
    
    # Clear previous results to ensure fresh scan
    $script:BackupInventory = @{}
    $script:StorageMetrics = $null
    
    # Clear UI elements
    if ($script:treeBackups) {
        $script:treeBackups.Items.Clear()
        $script:treeBackups.Visibility = "Collapsed"
    }
    # Storage Analysis panel removed
    
    # Disable other buttons during scan
    $script:btnGenerateReport.IsEnabled = $false
    $script:btnSchedule.IsEnabled = $false
    
    try {
        # Process all backup locations
        $scanSuccess = Invoke-AllBackupLocationsProcessing -RootPath $script:MappedDrive
            
            if ($scanSuccess) {
                # Update UI with results
                Update-UIWithResults
                
                # Enable report generation
                $script:btnGenerateReport.IsEnabled = $true
                $script:btnSchedule.IsEnabled = $true
                
                $totalMachines = $script:BackupInventory.Count
                $totalSize = ($script:BackupInventory.Values | Measure-Object -Property TotalSizeGB -Sum).Sum
                
                # Update summary text based on scan type
                if ($script:IsInitialScan) {
                    $script:txtSummary.Text = "Repository Initial Scan Completed Successfully"
                    Write-Log "Repository Initial Scan Completed Successfully - $totalMachines machines, $([math]::Round($totalSize, 2)) GB total" -Level "STATUS"
                    $script:IsInitialScan = $false  # Mark that initial scan is done
                } else {
                    $script:txtSummary.Text = "Repository Re-Scan Completed Successfully"
                    Write-Log "Repository Re-Scan Completed Successfully - $totalMachines machines, $([math]::Round($totalSize, 2)) GB total" -Level "STATUS"
                }
        }
    }
    finally {
        $script:btnScanNow.IsEnabled = $true
        $script:btnScanNow.Content = "🔄 Rescan"
    }
})

$script:btnGenerateReport.Add_Click({
    Write-Log "Generating HTML report..." -Level "STATUS"
    
    try {
        $reportPath = New-HTMLReport -BackupInventory $script:BackupInventory -StorageMetrics $script:StorageMetrics -BackupLocations $script:BackupLocations -ServerName $script:ServerName
        if ($reportPath -and (Test-Path $reportPath)) {
                    Write-Log "✅ Report generated successfully for $script:ServerName`: $reportPath" -Level "STATUS"
        
        # Automatically launch the report
        try {
            Start-Process $reportPath
            Write-Log "🚀 HTML report opened in default browser" -Level "STATUS"
            }
            catch {
                Write-Log "⚠️ Failed to open report automatically: $_" -Level "WARNING"
                Write-Log "Report location: $reportPath" -Level "STATUS"
            }
        }
    }
    catch {
        Write-Log "❌ Error generating report: $_" -Level "ERROR"
        [System.Windows.MessageBox]::Show(
            "Failed to generate report: $_",
            "Error",
            [System.Windows.MessageBoxButton]::OK,
            [System.Windows.MessageBoxImage]::Error
        )
    }
})

$script:btnSchedule.Add_Click({
    Write-Log "Opening schedule configuration..." -Level "STATUS"
    # This will be implemented in the next phase
    [System.Windows.MessageBox]::Show(
        "Schedule configuration will be implemented in the next phase.",
        "Coming Soon",
        [System.Windows.MessageBoxButton]::OK,
        [System.Windows.MessageBoxImage]::Information
    )
})

$script:btnClose.Add_Click({
    $window.Close()
})

# Function to disconnect drive safely
function Disconnect-Drive {
    param([string]$DriveLetter)
    
    if ([string]::IsNullOrEmpty($DriveLetter)) {
        return
    }
    
    Write-Log "Attempting to disconnect drive $DriveLetter"
    
    try {
        # Method 1: Use net use command
        $unmapCmd = "net use $DriveLetter /delete /yes"
        $result = Invoke-Expression $unmapCmd 2>&1
        
        if ($LASTEXITCODE -eq 0) {
            Write-Log "Successfully disconnected $DriveLetter using net use"
        }
        else {
            Write-Log "net use disconnect failed: $result"
            
            # Method 2: Try WScript.Network as fallback
            try {
                $net = New-Object -ComObject WScript.Network
                $net.RemoveNetworkDrive($DriveLetter, $true, $true)
                Write-Log "Successfully disconnected $DriveLetter using WScript.Network"
            }
            catch {
                Write-Log "WScript.Network disconnect also failed: $_"
            }
        }
    }
    catch {
        Write-Log "Error during drive disconnection: $_"
    }
}

# Window closing event handler to cleanup mapped drive
$window.Add_Closing({
    param($source, $eventData)
    
    try {
        Write-Log "Report Generator closing - performing cleanup..."
        
        # Disconnect the drive that was mapped by VeeamBackupExplorer
        if ($script:MappedDrive) {
            Write-Log "Disconnecting drive $($script:MappedDrive) before exit"
            Disconnect-Drive -DriveLetter $script:MappedDrive
        }
        else {
            Write-Log "No drive to disconnect"
        }
        
        Write-Log "Report Generator cleanup completed"
    }
    catch {
        Write-Log "Error during Report Generator cleanup: $_"
    }
})

# Function to update UI with scan results
function Update-UIWithResults {
    Write-Log "Updating UI with scan results..." -Level "STATUS"
    
    # Calculate storage metrics
            $script:StorageMetrics = Measure-StorageMetrics -BackupInventory $script:BackupInventory
    
    # Update Repository Overview tab
    Update-RepositoryTreeView
    
    # Storage Analysis tab removed
    
    # Get recommendations
    $recommendations = Get-StorageRecommendations -StorageMetrics $script:StorageMetrics
    
    # Log recommendations
    if ($recommendations.Count -gt 0) {
        Write-Log "=== Storage Recommendations ===" -Level "STATUS"
        foreach ($rec in $recommendations) {
            $prefix = switch ($rec.Severity) {
                "High" { "❗" }
                "Medium" { "⚠️" }
                "Low" { "ℹ️" }
                default { "•" }
            }
            Write-Log "$prefix [$($rec.Machine)] $($rec.Message)"
        }
    }
}

# Function to update the repository tree view
function Update-RepositoryTreeView {
    $script:treeBackups.Items.Clear()
    $script:treeBackups.Visibility = "Visible"
    
    # Create root node showing drive overview
    $rootNode = New-Object System.Windows.Controls.TreeViewItem
    $totalRepositories = $script:BackupLocations.Repositories.Count
    $rootNode.Header = "📁 $($script:MappedDrive) - $($script:StorageMetrics.TotalMachines) machines in $totalRepositories repositories - $([math]::Round($script:StorageMetrics.TotalStorageGB, 2)) GB"
    $rootNode.IsExpanded = $true
    
    # Add repository sections
    foreach ($repository in $script:BackupLocations.Repositories) {
        # Create repository node
        $repoNode = New-Object System.Windows.Controls.TreeViewItem
        if ($repository.Name -eq "Ad-Hoc Backups") {
            $repoNode.Header = "🎯 Repository: $($repository.Name) ($($repository.Machines.Count) machines, $([math]::Round($repository.TotalSizeGB, 2)) GB) [Individual files + Root drive machines]"
        } else {
            $repoNode.Header = "📦 Repository: $($repository.Name) ($($repository.Machines.Count) machines, $([math]::Round($repository.TotalSizeGB, 2)) GB)"
        }
        $repoNode.IsExpanded = $true
        
        # Add machines under repository
        foreach ($machineName in ($repository.Machines.Keys | Sort-Object)) {
            $inventoryKey = "$($repository.Name)::$machineName"
            $machineData = $script:BackupInventory[$inventoryKey]
            $machineMetric = $script:StorageMetrics.MachineMetrics[$inventoryKey]
        
        # Create machine node
        $machineNode = New-Object System.Windows.Controls.TreeViewItem
        $statusIcon = if ($machineMetric.LastBackupAge -and $machineMetric.LastBackupAge.Days -gt 7) { "⚠️" } else { "✅" }
        $lastBackupText = if ($machineData.LastBackupDate) { $machineData.LastBackupDate.ToString('yyyy-MM-dd') } else { "No backups" }
        $machineNode.Header = "$statusIcon $machineName ($($machineMetric.TotalSizeGB) GB, Last: $lastBackupText)"
        $machineNode.IsExpanded = $false
        
        # Add summary node
        $summaryNode = New-Object System.Windows.Controls.TreeViewItem
        $summaryNode.Header = "📊 Summary: $($machineMetric.FullBackupCount) full, $($machineMetric.IncrementalBackupCount) incremental backups"
        $machineNode.Items.Add($summaryNode)
        
        # Add retention info
        $retentionNode = New-Object System.Windows.Controls.TreeViewItem
        $retentionNode.Header = "📅 Retention: $($machineMetric.RetentionAnalysis.RetentionPoints) backup points ($($machineMetric.RetentionAnalysis.EstimatedSchedule) schedule)"
        $machineNode.Items.Add($retentionNode)
        
        # Add full backups folder
        if ($machineData.FullBackups.Count -gt 0) {
            $fullBackupsNode = New-Object System.Windows.Controls.TreeViewItem
            $fullBackupsNode.Header = "💾 Full Backups ($($machineData.FullBackups.Count) files, $([math]::Round($machineMetric.FullBackupSizeGB, 2)) GB)"
            
            foreach ($backup in ($machineData.FullBackups | Sort-Object LastWriteTime -Descending)) {
                $backupNode = New-Object System.Windows.Controls.TreeViewItem
                $backupNode.Header = "• $($backup.FileName) ($($backup.SizeGB) GB) - $($backup.LastWriteTime.ToString('yyyy-MM-dd HH:mm'))"
                $fullBackupsNode.Items.Add($backupNode)
            }
            
            $machineNode.Items.Add($fullBackupsNode)
        }
        
        # Add incremental backups folder
        if ($machineData.IncrementalBackups.Count -gt 0) {
            $incrementalNode = New-Object System.Windows.Controls.TreeViewItem
            $incrementalNode.Header = "📈 Incremental Backups ($($machineData.IncrementalBackups.Count) files, $([math]::Round($machineMetric.IncrementalBackupSizeGB, 2)) GB)"
            
            foreach ($backup in ($machineData.IncrementalBackups | Sort-Object LastWriteTime -Descending)) {
                $backupNode = New-Object System.Windows.Controls.TreeViewItem
                $backupNode.Header = "• $($backup.FileName) ($($backup.SizeGB) GB) - $($backup.LastWriteTime.ToString('yyyy-MM-dd HH:mm'))"
                $incrementalNode.Items.Add($backupNode)
            }
            
            $machineNode.Items.Add($incrementalNode)
        }
        
            $repoNode.Items.Add($machineNode)
    }
        
        $rootNode.Items.Add($repoNode)
    }
    

    
    $script:treeBackups.Items.Add($rootNode)
}

# Function to update storage analysis panel - REMOVED
# Storage Analysis tab and functionality removed per user request

# Initialize
Write-Log "Veeam Report Generator initialized"
Write-Log "Backup path: $script:UNCPath on drive $script:MappedDrive"

# Automatically perform the first scan
Write-Log "🚀 Starting initial backup repository scan..." -Level "STATUS"

# Start auto-scan in background using a timer to let UI load first
$autoScanTimer = New-Object System.Windows.Threading.DispatcherTimer
$autoScanTimer.Interval = [TimeSpan]::FromMilliseconds(500)  # Wait 500ms for UI to be ready
$autoScanTimer.Add_Tick({
    $autoScanTimer.Stop()
    
    # Trigger the scan button click event
    try {
        $script:btnScanNow.RaiseEvent([System.Windows.RoutedEventArgs]::new([System.Windows.Controls.Primitives.ButtonBase]::ClickEvent))
    }
    catch {
        Write-Log "Auto-scan failed to trigger: $_" -Level "ERROR"
    }
})
$autoScanTimer.Start()

# Show the window
$window.ShowDialog()
