# Backup Analyzer Module for Veeam Backup Explorer

# Function to get Veeam backup filename information and extract metadata
function Get-VeeamBackupFileInfo {
    param([string]$FileName)
    
    # Typical Veeam filename patterns:
    # VM_Name2025-01-15T010000.vbk (Full backup)
    # VM_Name2025-01-16T010000.vib (Incremental backup)
    # VM_NameD2025-01-15T010000.vbk (Full backup with D for Daily)
    
    $result = @{
        VMName = ""
        BackupType = ""
        BackupDate = $null
        IsFullBackup = $false
        IsIncremental = $false
        BackupSchedule = ""
    }
    
    # Determine backup type by extension
    if ($FileName -match '\.vbk$') {
        $result.IsFullBackup = $true
        $result.BackupType = "Full"
    }
    elseif ($FileName -match '\.vib$') {
        $result.IsIncremental = $true
        $result.BackupType = "Incremental"
    }
    
    # Extract VM name and date
    if ($FileName -match '^(.+?)(\d{4}-\d{2}-\d{2}T\d{6})\.v[bi][kb]$') {
        $vmNamePart = $matches[1]
        $datePart = $matches[2]
        
        # Clean up VM name (remove trailing schedule indicators)
        $result.VMName = $vmNamePart -replace '[DWM]$', ''
        
        # Detect schedule type
        if ($vmNamePart -match 'D$') {
            $result.BackupSchedule = "Daily"
        }
        elseif ($vmNamePart -match 'W$') {
            $result.BackupSchedule = "Weekly"
        }
        elseif ($vmNamePart -match 'M$') {
            $result.BackupSchedule = "Monthly"
        }
        
        # Parse date
        try {
            $result.BackupDate = [DateTime]::ParseExact($datePart, "yyyy-MM-ddTHHmmss", $null)
        }
        catch {
            # Fallback to file creation time
        }
    }
    
    return $result
}

# Function to analyze backup retention and patterns
function Analyze-BackupRetention {
    param([array]$BackupFiles)
    
    $analysis = @{
        TotalBackups = $BackupFiles.Count
        FullBackups = 0
        IncrementalBackups = 0
        OldestBackup = $null
        NewestBackup = $null
        RetentionPoints = 0
        RetentionDays = 0  # Keep for backward compatibility
        BackupFrequency = @{
            Daily = 0
            Weekly = 0
            Monthly = 0
        }
        BackupCalendar = @{}
        EstimatedSchedule = ""
        MissingBackupDates = @()
    }
    
    if ($BackupFiles.Count -eq 0) {
        return $analysis
    }
    
    # Sort by date
    $sortedBackups = $BackupFiles | Sort-Object LastWriteTime
    
    # Count backup types
    $analysis.FullBackups = ($BackupFiles | Where-Object { $_.Name -match '\.vbk$' }).Count
    $analysis.IncrementalBackups = ($BackupFiles | Where-Object { $_.Name -match '\.vib$' }).Count
    
    # Get date range and calculate retention
    if ($sortedBackups -and $sortedBackups.Count -gt 0) {
        $analysis.OldestBackup = $sortedBackups[0].LastWriteTime
        $analysis.NewestBackup = $sortedBackups[-1].LastWriteTime
        $analysis.RetentionDays = ($analysis.NewestBackup - $analysis.OldestBackup).Days
    }
    $analysis.RetentionPoints = $BackupFiles.Count  # Total backup points in retention
    
    # Build calendar of backups
    foreach ($backup in $BackupFiles) {
        if ($backup -and $backup.LastWriteTime) {
            $dateKey = $backup.LastWriteTime.ToString("yyyy-MM-dd")
            if (-not $analysis.BackupCalendar.ContainsKey($dateKey)) {
                $analysis.BackupCalendar[$dateKey] = @{
                    FullBackups = @()
                    IncrementalBackups = @()
                }
            }
            
            $parsed = Get-VeeamBackupFileInfo -FileName $backup.Name
            if ($parsed.IsFullBackup) {
                $analysis.BackupCalendar[$dateKey].FullBackups += $backup
            }
            else {
                $analysis.BackupCalendar[$dateKey].IncrementalBackups += $backup
            }
        }
    }
    
    # Analyze backup frequency
    if ($analysis.NewestBackup -and $analysis.OldestBackup) {
        $daysSinceOldest = ($analysis.NewestBackup - $analysis.OldestBackup).Days
        if ($daysSinceOldest -gt 0) {
            $backupsPerDay = $analysis.TotalBackups / $daysSinceOldest
            
            if ($backupsPerDay -ge 0.8) {
                $analysis.EstimatedSchedule = "Daily"
            }
            elseif ($backupsPerDay -ge 0.1) {
                $analysis.EstimatedSchedule = "Weekly"
            }
            else {
                $analysis.EstimatedSchedule = "Monthly"
            }
        }
        
        # Find missing backup dates (gaps in daily backups)
        if ($analysis.EstimatedSchedule -eq "Daily" -and $daysSinceOldest -gt 1) {
            $currentDate = $analysis.OldestBackup.Date
            while ($currentDate -le $analysis.NewestBackup.Date) {
                $dateKey = $currentDate.ToString("yyyy-MM-dd")
                if (-not $analysis.BackupCalendar.ContainsKey($dateKey)) {
                    $analysis.MissingBackupDates += $currentDate
                }
                $currentDate = $currentDate.AddDays(1)
            }
        }
    }
    
    return $analysis
}

# Helper function to calculate standard deviation
function Calculate-StandardDeviation {
    param(
        [array]$Values
    )
    
    if ($Values.Count -le 1) {
        return 0
    }
    
    $mean = ($Values | Measure-Object -Average).Average
    $sumOfSquaredDifferences = ($Values | ForEach-Object { [math]::Pow($_ - $mean, 2) } | Measure-Object -Sum).Sum
    $variance = $sumOfSquaredDifferences / ($Values.Count - 1)
    $standardDeviation = [math]::Sqrt($variance)
    
    return [math]::Round($standardDeviation, 2)
}

# Function to measure storage metrics
function Measure-StorageMetrics {
    param([hashtable]$BackupInventory)
    
    $metrics = @{
        TotalMachines = $BackupInventory.Count
        TotalStorageGB = 0
        TotalFullBackupsGB = 0
        TotalIncrementalBackupsGB = 0
        AverageBackupSizeGB = 0
        LargestMachine = @{ Name = ""; SizeGB = 0 }
        SmallestMachine = @{ Name = ""; SizeGB = [double]::MaxValue }
        MachineMetrics = @{}
    }
    
    foreach ($machine in $BackupInventory.Keys) {
        $machineData = $BackupInventory[$machine]
        
        # Calculate standard deviations for backup sizes
        $fullBackupSizes = $machineData.FullBackups | ForEach-Object { $_.SizeGB }
        $incrementalBackupSizes = $machineData.IncrementalBackups | ForEach-Object { $_.SizeGB }
        
        # Calculate machine-specific metrics
        $machineMetric = @{
            Name = $machine
            TotalSizeGB = $machineData.TotalSizeGB
            FullBackupCount = $machineData.FullBackups.Count
            IncrementalBackupCount = $machineData.IncrementalBackups.Count
            FullBackupSizeGB = ($machineData.FullBackups | Measure-Object -Property SizeGB -Sum).Sum
            IncrementalBackupSizeGB = ($machineData.IncrementalBackups | Measure-Object -Property SizeGB -Sum).Sum
            FullBackupStdDev = Calculate-StandardDeviation -Values $fullBackupSizes
            IncrementalBackupStdDev = Calculate-StandardDeviation -Values $incrementalBackupSizes
            AverageBackupSizeGB = 0
            LastBackupAge = $null
            RetentionAnalysis = $null
        }
        
        # Calculate average backup size
        $totalBackups = $machineMetric.FullBackupCount + $machineMetric.IncrementalBackupCount
        if ($totalBackups -gt 0) {
            $machineMetric.AverageBackupSizeGB = [math]::Round($machineMetric.TotalSizeGB / $totalBackups, 2)
        }
        
        # Calculate backup age
        if ($machineData.LastBackupDate) {
            $machineMetric.LastBackupAge = (Get-Date) - $machineData.LastBackupDate
        }
        
        # Perform retention analysis
        $allBackupFiles = @()
        foreach ($backup in $machineData.FullBackups) {
            $allBackupFiles += [PSCustomObject]@{
                Name = $backup.FileName
                LastWriteTime = $backup.LastWriteTime
            }
        }
        foreach ($backup in $machineData.IncrementalBackups) {
            $allBackupFiles += [PSCustomObject]@{
                Name = $backup.FileName
                LastWriteTime = $backup.LastWriteTime
            }
        }
        
        $machineMetric.RetentionAnalysis = Analyze-BackupRetention -BackupFiles $allBackupFiles
        
        # Update global metrics
        $metrics.TotalStorageGB += $machineMetric.TotalSizeGB
        $metrics.TotalFullBackupsGB += $machineMetric.FullBackupSizeGB
        $metrics.TotalIncrementalBackupsGB += $machineMetric.IncrementalBackupSizeGB
        
        # Track largest/smallest
        if ($machineMetric.TotalSizeGB -gt $metrics.LargestMachine.SizeGB) {
            $metrics.LargestMachine = @{ Name = $machine; SizeGB = $machineMetric.TotalSizeGB }
        }
        if ($machineMetric.TotalSizeGB -lt $metrics.SmallestMachine.SizeGB -and $machineMetric.TotalSizeGB -gt 0) {
            $metrics.SmallestMachine = @{ Name = $machine; SizeGB = $machineMetric.TotalSizeGB }
        }
        
        $metrics.MachineMetrics[$machine] = $machineMetric
    }
    
    # Calculate average
    if ($metrics.TotalMachines -gt 0) {
        $metrics.AverageBackupSizeGB = [math]::Round($metrics.TotalStorageGB / $metrics.TotalMachines, 2)
    }
    
    return $metrics
}

# Function to generate comprehensive storage recommendations
function Get-StorageRecommendations {
    param([hashtable]$StorageMetrics)
    
    $recommendations = @()
    
    # Global storage analysis
    $totalStorageGB = $StorageMetrics.TotalStorageGB
    $avgMachineSize = $StorageMetrics.AverageBackupSizeGB
    $machineCount = $StorageMetrics.TotalMachines
    
    # Repository capacity analysis (if available)
    $repoInfo = $StorageMetrics.RepositoryInfo
    if ($repoInfo) {
        $usagePercent = $repoInfo.UsagePercent
        $freeSpaceTB = $repoInfo.FreeSpaceTB
        $totalCapacityTB = $repoInfo.TotalCapacityTB
        $backupDataTB = $repoInfo.BackupDataTB
        
        # Color-coded capacity warnings based on free space
        $freeSpacePercent = [math]::Round(100 - $usagePercent, 1)
        
        if ($usagePercent -gt 85) {  # <15% Free - RED/CRITICAL
            $recommendations += @{
                Machine = "Repository"
                Type = "Warning"
                Message = "🔴 CRITICAL STATUS: Repository at $usagePercent% capacity ($freeSpacePercent% free) - immediate expansion or cleanup required"
                Severity = "High"
                Category = "Capacity Management"
            }
        }
        elseif ($usagePercent -gt 70) {  # 15-30% Free - YELLOW/WARNING
            $recommendations += @{
                Machine = "Repository"
                Type = "Warning"
                Message = "🟡 WARNING STATUS: Repository at $usagePercent% capacity ($freeSpacePercent% free) - plan storage expansion soon"
                Severity = "Medium"
                Category = "Capacity Management"
            }
        }
        elseif ($usagePercent -gt 50) {  # >30% Free but worth monitoring - GREEN/HEALTHY
            $recommendations += @{
                Machine = "Repository"
                Type = "Info"
                Message = "🟢 HEALTHY STATUS: Repository at $usagePercent% capacity ($freeSpacePercent% free) - monitoring recommended"
                Severity = "Low"
                Category = "Capacity Planning"
            }
        }
        
        # Growth projection based on actual capacity with color-coded urgency
        $monthlyGrowthGB = $totalStorageGB * 0.15  # 15% monthly growth
        $monthsUntilFull = if ($monthlyGrowthGB -gt 0) { 
            [math]::Max(0, [math]::Floor(($freeSpaceTB * 1024) / $monthlyGrowthGB))
        } else { 999 }
        
        $statusColor = if ($usagePercent -gt 85) { "🔴" } elseif ($usagePercent -gt 70) { "🟡" } else { "🟢" }
        
        if ($monthsUntilFull -lt 3) {
            $recommendations += @{
                Machine = "Repository"
                Type = "Warning"
                Message = "$statusColor Growth projection: At current rate ($([math]::Round($monthlyGrowthGB, 1)) GB/month), repository will be full in ~$monthsUntilFull months"
                Severity = "High"
                Category = "Capacity Planning"
            }
        }
        elseif ($monthsUntilFull -lt 6) {
            $recommendations += @{
                Machine = "Repository"
                Type = "Info"
                Message = "$statusColor Growth projection: At current rate ($([math]::Round($monthlyGrowthGB, 1)) GB/month), repository will be full in ~$monthsUntilFull months"
                Severity = "Medium"
                Category = "Capacity Planning"
            }
        }
        elseif ($monthsUntilFull -lt 12 -and $usagePercent -gt 50) {
            $recommendations += @{
                Machine = "Repository"
                Type = "Info"
                Message = "$statusColor Growth projection: Repository should be monitored - projected full in ~$monthsUntilFull months at current growth rate"
                Severity = "Low"
                Category = "Capacity Planning"
            }
        }
        
        # Repository efficiency insights
        $otherDataTB = $repoInfo.UsedSpaceTB - $backupDataTB
        if ($otherDataTB -gt ($backupDataTB * 0.2)) {
            $recommendations += @{
                Machine = "Repository"
                Type = "Info"
                Message = "💾 Non-backup data consuming $([math]::Round($otherDataTB, 1)) TB of repository space - consider cleanup or separate storage"
                Severity = "Low"
                Category = "Storage Optimization"
            }
        }
        
        # Large repository insights
        if ($totalCapacityTB -gt 10) {
            $recommendations += @{
                Machine = "Repository"
                Type = "Info"
                Message = "🏢 Enterprise-scale repository ($totalCapacityTB TB) - consider implementing automated storage tiering and monitoring alerts"
                Severity = "Low"
                Category = "Infrastructure"
            }
        }
    }
    else {
        # Fallback recommendations when repository info is not available
        if ($totalStorageGB -gt 500) {
            $recommendations += @{
                Machine = "Repository"
                Type = "Info"
                Message = "Large backup dataset ($([math]::Round($totalStorageGB, 1)) GB) - recommend monitoring repository capacity and implementing storage tiering"
                Severity = "Low"
                Category = "Capacity Management"
            }
        }
        
        # Basic growth prediction
        $monthlyGrowthEstimate = $totalStorageGB * 0.15
        $recommendations += @{
            Machine = "Repository"
            Type = "Info"
            Message = "Estimated monthly growth: ~$([math]::Round($monthlyGrowthEstimate, 1)) GB - monitor repository capacity regularly"
            Severity = "Low"
            Category = "Capacity Planning"
        }
    }
    
    # Per-machine analysis
    foreach ($machine in $StorageMetrics.MachineMetrics.Keys) {
        $metric = $StorageMetrics.MachineMetrics[$machine]
        
        # === BACKUP HEALTH ANALYSIS ===
        
        # Check for old backups (Critical)
        if ($metric.LastBackupAge -and $metric.LastBackupAge.Days -gt 7) {
            $recommendations += @{
                Machine = $machine
                Type = "Warning"
                Message = "⚠️ Backup is stale ($($metric.LastBackupAge.Days) days old) - immediate attention required"
                Severity = "High"
                Category = "Backup Health"
            }
        }
        elseif ($metric.LastBackupAge -and $metric.LastBackupAge.Days -gt 3) {
            $recommendations += @{
                Machine = $machine
                Type = "Warning"
                Message = "⏰ Backup is $($metric.LastBackupAge.Days) days old - monitor backup schedule"
                Severity = "Medium"
                Category = "Backup Health"
            }
        }
        
        # === RETENTION POLICY ANALYSIS ===
        
        $retentionPoints = $metric.RetentionAnalysis.RetentionPoints
        
        # Adjust retention recommendations based on repository capacity (matching color-coded thresholds)
        $repoCapacityFactor = if ($repoInfo -and $repoInfo.UsagePercent -gt 85) { "Critical" }  # <15% Free - RED
                             elseif ($repoInfo -and $repoInfo.UsagePercent -gt 70) { "Warning" }   # 15-30% Free - YELLOW
                             else { "Healthy" }  # >30% Free - GREEN
        
        if ($retentionPoints -gt 45) {
            $savingsGB = ($retentionPoints - 30) * $metric.AverageBackupSizeGB
            $severity = if ($repoCapacityFactor -eq "Critical") { "Medium" } else { "Low" }
            $statusIcon = if ($repoCapacityFactor -eq "Critical") { "🔴" } elseif ($repoCapacityFactor -eq "Warning") { "🟡" } else { "🟢" }
            $urgencyText = if ($repoCapacityFactor -eq "Critical") { " - 🔴 URGENT due to critical repository capacity" } 
                          elseif ($repoCapacityFactor -eq "Warning") { " - 🟡 PRIORITY due to repository capacity" } 
                          else { "" }
            
            $recommendations += @{
                Machine = $machine
                Type = "Info"
                Message = "$statusIcon High retention ($retentionPoints points) - reducing to 30 points could save ~$([math]::Round($savingsGB, 1)) GB storage$urgencyText"
                Severity = $severity
                Category = "Storage Optimization"
            }
        }
        elseif ($retentionPoints -gt 30 -and ($repoCapacityFactor -eq "Critical" -or $repoCapacityFactor -eq "Warning")) {
            $savingsGB = ($retentionPoints - 20) * $metric.AverageBackupSizeGB
            $statusIcon = if ($repoCapacityFactor -eq "Critical") { "🔴" } else { "🟡" }
            $urgencyLevel = if ($repoCapacityFactor -eq "Critical") { "CRITICAL" } else { "HIGH" }
            
            $recommendations += @{
                Machine = $machine
                Type = "Warning"
                Message = "$statusIcon $urgencyLevel PRIORITY: Repository capacity at risk - reduce retention from $retentionPoints to 20 points (saves ~$([math]::Round($savingsGB, 1)) GB)"
                Severity = "Medium"
                Category = "Storage Optimization"
            }
        }
        elseif ($retentionPoints -lt 7) {
            $recommendations += @{
                Machine = $machine
                Type = "Warning"
                Message = "⚠️ Low retention ($retentionPoints points) - insufficient for disaster recovery. Consider 14-30 points"
                Severity = "Medium"
                Category = "Risk Management"
            }
        }
        
        # === BACKUP CHAIN ANALYSIS ===
        
        $fullBackupRatio = if ($metric.FullBackupCount + $metric.IncrementalBackupCount -gt 0) {
            $metric.FullBackupCount / ($metric.FullBackupCount + $metric.IncrementalBackupCount)
        } else { 0 }
        
        if ($fullBackupRatio -lt 0.1 -and $metric.IncrementalBackupCount -gt 10) {
            $recommendations += @{
                Machine = $machine
                Type = "Warning"
                Message = "📊 Long incremental chain ($($metric.IncrementalBackupCount) incrementals, only $($metric.FullBackupCount) fulls) - consider more frequent full backups for faster recovery"
                Severity = "Medium"
                Category = "Performance"
            }
        }
        elseif ($fullBackupRatio -gt 0.5) {
            $storageWaste = $metric.FullBackupSizeGB * 0.3  # Estimate 30% waste from too many fulls
            $recommendations += @{
                Machine = $machine
                Type = "Info"
                Message = "💾 High full backup ratio ($([math]::Round($fullBackupRatio * 100, 0))%) - could reduce storage by ~$([math]::Round($storageWaste, 1)) GB with more incrementals"
                Severity = "Low"
                Category = "Storage Optimization"
            }
        }
        
        # === STORAGE EFFICIENCY ANALYSIS ===
        
        if ($metric.FullBackupCount -gt 1 -and $metric.FullBackupStdDev -gt ($metric.FullBackupSizeGB / $metric.FullBackupCount * 0.3)) {
            $recommendations += @{
                Machine = $machine
                Type = "Info"
                Message = "📈 High backup size variance (StdDev: $($metric.FullBackupStdDev) GB) - indicates data growth or inconsistent backup content"
                Severity = "Low"
                Category = "Data Analysis"
            }
        }
        
        # === BACKUP SIZE ANALYSIS ===
        
        if ($metric.FullBackupCount -gt 1 -and $metric.IncrementalBackupCount -gt 1) {
            $avgFullSize = $metric.FullBackupSizeGB / $metric.FullBackupCount
            $avgIncrementalSize = $metric.IncrementalBackupSizeGB / $metric.IncrementalBackupCount
            
            # Large incremental analysis
            if ($avgIncrementalSize -gt ($avgFullSize * 0.4)) {
                $recommendations += @{
                    Machine = $machine
                    Type = "Warning"
                    Message = "📊 Large incremental backups ($([math]::Round($avgIncrementalSize, 1)) GB avg) suggest high data churn - consider daily full backups or investigate data changes"
                    Severity = "Medium"
                    Category = "Performance"
                }
            }
            
            # Very small incremental analysis
            if ($avgIncrementalSize -lt 0.1 -and $avgFullSize -gt 10) {
                $recommendations += @{
                    Machine = $machine
                    Type = "Info"
                    Message = "✅ Excellent incremental efficiency ($([math]::Round($avgIncrementalSize, 2)) GB avg) - data change rate is low and well-optimized"
                    Severity = "Low"
                    Category = "Performance"
                }
            }
        }
        
        # === MISSING BACKUP ANALYSIS ===
        
        $missingDays = $metric.RetentionAnalysis.MissingBackupDates.Count
        if ($missingDays -gt 0) {
            $severity = if ($missingDays -gt 7) { "High" } elseif ($missingDays -gt 3) { "Medium" } else { "Low" }
            $recommendations += @{
                Machine = $machine
                Type = "Warning"
                Message = "⚠️ Missing backups on $missingDays days - check backup job schedule and failures"
                Severity = $severity
                Category = "Backup Health"
            }
        }
        
        # === STORAGE SIZE INSIGHTS ===
        
        if ($metric.TotalSizeGB -gt ($avgMachineSize * 3)) {
            $repoImpact = [math]::Round(($metric.TotalSizeGB / ($StorageMetrics.TotalStorageGB)) * 100, 1)
            $severity = if (($repoCapacityFactor -eq "Critical" -or $repoCapacityFactor -eq "Warning") -and $repoImpact -gt 10) { "Medium" } else { "Low" }
            $statusIcon = if ($repoCapacityFactor -eq "Critical") { "🔴" } elseif ($repoCapacityFactor -eq "Warning") { "🟡" } else { "🟢" }
            $impactText = if ($repoImpact -gt 15) { " ($repoImpact% of repository)" } else { "" }
            $priorityText = if ($repoCapacityFactor -eq "Critical") { " - URGENT optimization needed" } 
                           elseif ($repoCapacityFactor -eq "Warning") { " - HIGH priority for optimization" } 
                           else { " - monitor for optimization opportunities" }
            
            $recommendations += @{
                Machine = $machine
                Type = "Info"
                Message = "$statusIcon Large storage consumer ($([math]::Round($metric.TotalSizeGB, 1)) GB vs $([math]::Round($avgMachineSize, 1)) GB avg)$impactText$priorityText"
                Severity = $severity
                Category = "Storage Analysis"
            }
        }
        elseif ($metric.TotalSizeGB -gt 0 -and $metric.TotalSizeGB -lt ($avgMachineSize * 0.3)) {
            $statusIcon = if ($repoCapacityFactor -eq "Critical") { "🔴" } elseif ($repoCapacityFactor -eq "Warning") { "🟡" } else { "🟢" }
            $extendedRetention = if ($repoCapacityFactor -eq "Healthy") { " or extended retention" } else { "" }
            $recommendations += @{
                Machine = $machine
                Type = "Info"
                Message = "$statusIcon Small footprint ($([math]::Round($metric.TotalSizeGB, 1)) GB) - good candidate for cloud storage$extendedRetention"
                Severity = "Low"
                Category = "Cost Optimization"
            }
        }
        
        # === SCHEDULE OPTIMIZATION ===
        
        $schedule = $metric.RetentionAnalysis.EstimatedSchedule
        if ($schedule -eq "Daily" -and $metric.TotalSizeGB -lt 5) {
            $recommendations += @{
                Machine = $machine
                Type = "Info"
                Message = "⏰ Small VM with daily backups - consider weekly schedule to reduce storage overhead"
                Severity = "Low"
                Category = "Schedule Optimization"
            }
        }
        elseif ($schedule -eq "Weekly" -and $metric.TotalSizeGB -gt 50) {
            $recommendations += @{
                Machine = $machine
                Type = "Info"
                Message = "⏰ Large VM with weekly backups - consider daily backups for better RPO"
                Severity = "Low"
                Category = "Schedule Optimization"
            }
        }
        
        # === DEDUPLICATION INSIGHTS ===
        
        if ($metric.FullBackupCount -gt 2) {
            $avgFullSize = $metric.FullBackupSizeGB / $metric.FullBackupCount
            $compressionRatio = if ($avgFullSize -gt 0) { 
                # Estimate potential deduplication savings (typical 40-60% for VMs)
                $estimatedSavings = $avgFullSize * 0.5
                $estimatedSavings
            } else { 0 }
            
            if ($compressionRatio -gt 2) {
                $recommendations += @{
                    Machine = $machine
                    Type = "Info"
                    Message = "💾 Potential deduplication savings: ~$([math]::Round($compressionRatio, 1)) GB through storage optimization technologies"
                    Severity = "Low"
                    Category = "Storage Optimization"
                }
            }
        }
    }
    
    # === GLOBAL OPTIMIZATION RECOMMENDATIONS ===
    
    # Repository-wide insights
    $largeVMs = $StorageMetrics.MachineMetrics.Values | Where-Object { $_.TotalSizeGB -gt $avgMachineSize * 2 }
    if ($largeVMs.Count -gt ($machineCount * 0.2)) {
        $recommendations += @{
            Machine = "Repository"
            Type = "Info"
            Message = "📊 $($largeVMs.Count) large VMs consuming $([math]::Round(($largeVMs | Measure-Object -Property TotalSizeGB -Sum).Sum, 1)) GB - prioritize these for storage optimization"
            Severity = "Low"
            Category = "Storage Analysis"
        }
    }
    
    # Add capacity management insight
    if ($totalStorageGB -gt 1000) {
        $recommendations += @{
            Machine = "Repository"
            Type = "Info"
            Message = "🏢 Enterprise-scale repository - consider implementing automated storage tiering and monitoring alerts"
            Severity = "Low"
            Category = "Infrastructure"
        }
    }
    
    return $recommendations
}

# Export functions
Export-ModuleMember -Function Get-VeeamBackupFileInfo, Analyze-BackupRetention, Measure-StorageMetrics, Get-StorageRecommendations 