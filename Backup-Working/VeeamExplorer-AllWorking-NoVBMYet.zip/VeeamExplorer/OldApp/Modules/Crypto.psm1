# Crypto Module for secure data handling

# Generate a unique key based on the machine and user
function Get-EncryptionKey {
    $computerName = $env:COMPUTERNAME
    $userName = $env:USERNAME
    $userSID = ([System.Security.Principal.WindowsIdentity]::GetCurrent()).User.Value
    
    # Combine these values to create a unique but consistent key
    $combinedString = "$computerName|$userName|$userSID"
    $keyBytes = [System.Text.Encoding]::UTF8.GetBytes($combinedString)
    
    # Use SHA256 to get a consistent key length
    $sha256 = [System.Security.Cryptography.SHA256]::Create()
    $hashBytes = $sha256.ComputeHash($keyBytes)
    $sha256.Dispose()
    
    return $hashBytes
}

function ConvertTo-EncryptedString {
    param(
        [Parameter(Mandatory=$true)]
        [string]$PlainText
    )
    
    try {
        # Convert the string to bytes
        $textBytes = [System.Text.Encoding]::UTF8.GetBytes($PlainText)
        
        # Get the encryption key
        $keyBytes = Get-EncryptionKey
        
        # Create AES encryption object
        $aes = [System.Security.Cryptography.Aes]::Create()
        $aes.Key = $keyBytes
        $aes.GenerateIV()
        
        # Create encryptor
        $encryptor = $aes.CreateEncryptor()
        
        # Encrypt the data
        $encryptedBytes = $encryptor.TransformFinalBlock($textBytes, 0, $textBytes.Length)
        
        # Combine IV and encrypted data
        $combinedBytes = $aes.IV + $encryptedBytes
        
        # Convert to Base64 string
        $encryptedString = [Convert]::ToBase64String($combinedBytes)
        
        $aes.Dispose()
        return $encryptedString
    }
    catch {
        Write-Error "Encryption failed: $_"
        throw
    }
}

function ConvertFrom-EncryptedString {
    param(
        [Parameter(Mandatory=$true)]
        [string]$EncryptedText
    )
    
    try {
        # Convert from Base64
        $combinedBytes = [Convert]::FromBase64String($EncryptedText)
        
        # Get the encryption key
        $keyBytes = Get-EncryptionKey
        
        # Create AES decryption object
        $aes = [System.Security.Cryptography.Aes]::Create()
        $aes.Key = $keyBytes
        
        # Extract IV (first 16 bytes)
        $iv = $combinedBytes[0..15]
        $aes.IV = $iv
        
        # Extract encrypted data (remaining bytes)
        $encryptedBytes = $combinedBytes[16..$combinedBytes.Length]
        
        # Create decryptor
        $decryptor = $aes.CreateDecryptor()
        
        # Decrypt the data
        $decryptedBytes = $decryptor.TransformFinalBlock($encryptedBytes, 0, $encryptedBytes.Length)
        
        # Convert back to string
        $decryptedString = [System.Text.Encoding]::UTF8.GetString($decryptedBytes)
        
        $aes.Dispose()
        return $decryptedString
    }
    catch {
        Write-Error "Decryption failed: $_"
        throw
    }
}

Export-ModuleMember -Function ConvertTo-EncryptedString, ConvertFrom-EncryptedString 